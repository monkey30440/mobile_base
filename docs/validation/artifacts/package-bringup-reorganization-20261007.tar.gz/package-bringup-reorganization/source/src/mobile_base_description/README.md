# mobile_base_description

Build-time extraction of the supplied RWF_V2.0_QA_release.urdf base subtree.
The repository's reference platform folder is required at build time; installed
URDF and base meshes are self-contained and use package URIs. Upper-body geometry
is excluded. Source geometry, inertials and movable joints are retained.
BASE_FOOTPRINT is normalized/rerooted as base_footprint; wheel joint names map to
the canonical left_wheel_joint/right_wheel_joint used by M1.

Native robot_state_publisher is the sole model TF owner. The supplied URDF
now defines the operator-confirmed mounting poses directly on
base_lidar_joint_FL/BR: roll=180 degrees, pitch=0, yaw=+45 degrees (FL)
and -135 degrees (BR). base_imu_joint has yaw=+90 degrees, roll/pitch=0,
with its source translation retained. The native base_lidar_link_FL_1/BR_1 scan children
are identity transforms, so mounting rotation is applied exactly once.
No extra CAD links or scan rewriting are used. Visual and inertial origins
remain unchanged; meshes rotate with their source links. Translations retain
the source mount positions pending precise extrinsic calibration.

No joint_state_publisher or fabricated wheel/suspension/caster states are started.
Movable branches require real appropriate joint feedback; absence of that feedback
is not a complete dynamic-model acceptance. All sensor/base_footprint paths are
fixed and can be verified without motor operation. odom->base_footprint remains
robot_localization's responsibility; this model-only launch does not fabricate it.
Use the installed Bringup model entry for model-only Operator verification.
Do not run it alongside control/local_base/base entries: those already start
the sole RSP with the native control fragment/profile.

```bash
ros2 launch mobile_base_bringup model.launch.py
```

Foxglove 3D Scene → Mesh up-axis must be Z-up for the supplied STL geometry.
The default Y-up introduces a display-only mesh rotation; do not compensate
by rotating base TF or changing authoritative visual origins.

## Nominal drive-seat posture

V1 spec32 reconciliation (2026-10-07) uses the original design origins at zero
displacement for `driving_slide_joint_L/R`. The build-time deployment model
expresses only these two as fixed joints; source URDF and origin geometry remain
unchanged. Native RSP publishes the nominal base-to-drive-seat transforms. This
is not measured suspension travel, and no fake JointState or extra TF publisher
is introduced. Wheel rotation remains continuous and comes from real M1 position
feedback. Other passive caster/suspension joints are not implicitly fixed or
declared hardware-verified by this choice.
