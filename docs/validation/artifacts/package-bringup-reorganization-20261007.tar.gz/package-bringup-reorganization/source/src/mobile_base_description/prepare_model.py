"""Build-time extraction of the authoritative base subtree; no runtime publisher."""
import copy
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

source, output = map(Path, sys.argv[1:])
original = ET.parse(source).getroot()
robot = ET.Element('robot', name='mobile_base', attrib={'xmlns:xacro':'http://www.ros.org/wiki/xacro'})
links = {'base_link'}
joints = []
while True:
    found = [j for j in original.findall('joint') if j not in joints
             and j.find('parent').attrib['link'] in links and j.attrib['name'] != 'J_L_TORSO_J1']
    if not found:break
    joints.extend(found)
    links.update(j.find('child').attrib['link'] for j in found)
for link in original.findall('link'):
    if link.attrib['name'] not in links:continue
    link=copy.deepcopy(link)
    if link.attrib['name']=='BASE_FOOTPRINT':link.attrib['name']='base_footprint'
    for mesh in link.findall('.//mesh'):
        mesh.attrib['filename']='package://mobile_base_description/meshes/'+Path(mesh.attrib['filename']).name
    robot.append(link)
for joint in joints:
    joint=copy.deepcopy(joint)
    if joint.attrib['name']=='J_BASE_FOOTPRINT':
        joint.find('parent').attrib['link']='base_footprint'
        joint.find('child').attrib['link']='base_link'
        joint.find('origin').attrib['xyz']='0 0 0.256'
    for side,short in [('L','left'),('R','right')]:
        if joint.attrib['name']=='driving_wheel_joint_'+side:joint.attrib['name']=short+'_wheel_joint'
    # Confirmed V1 nominal drive-seat posture, not measured suspension state.
    # Keep source geometry/origin; native RSP publishes these two fixed edges.
    if joint.attrib['name'] in ('driving_slide_joint_L', 'driving_slide_joint_R'):
        joint.attrib['type'] = 'fixed'
        for tag in ('axis', 'limit'):
            element = joint.find(tag)
            if element is not None:
                joint.remove(element)
    robot.append(joint)
for side in ('FL','BR'):
    mounting = 'base_lidar_link_' + side
    scan = mounting + '_1'
    ET.SubElement(robot, 'link', name=scan)
    joint = ET.SubElement(robot, 'joint', name='lidar_scan_joint_' + side, type='fixed')
    ET.SubElement(joint, 'parent', link=mounting)
    ET.SubElement(joint, 'child', link=scan)
    ET.SubElement(joint, 'origin', xyz='0 0 0', rpy='0 0 0')
ET.indent(robot)
output.parent.mkdir(parents=True,exist_ok=True)
ET.ElementTree(robot).write(output,encoding='unicode',xml_declaration=True)
