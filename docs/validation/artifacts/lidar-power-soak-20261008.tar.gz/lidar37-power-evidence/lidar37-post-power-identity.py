import json,rclpy
from pathlib import Path
from sick_scan_xd.srv import ColaMsgSrv
rclpy.init();node=rclpy.create_node('post_power_identity_readback');result={}
try:
 for source,expected in [('fl','25350157'),('br','25450354')]:
  client=node.create_client(ColaMsgSrv,'/lidar/'+source+'/ColaMsg')
  assert client.wait_for_service(timeout_sec=5)
  request=ColaMsgSrv.Request();request.request='sRN SerialNumber'
  future=client.call_async(request)
  rclpy.spin_until_future_complete(node,future,timeout_sec=5)
  assert future.done() and future.result() is not None
  result[source]=future.result().response
  assert expected in result[source]
  node.destroy_client(client)
finally:
 node.destroy_node();rclpy.shutdown()
Path('/tmp/lidar37-power/post-power-identity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
