"""Summarize raw phase-tagged observations, not a runtime health monitor."""
import json,re,statistics
from pathlib import Path
root=Path('/tmp/lidar37-power-evidence')
records=json.loads((root/'messages.json').read_text())
start=json.loads((root/'soak-start.json').read_text())['start_monotonic']
report={'scope':'one shared two-device power-cycle, 900s bounded soak; no precise calibration or production durability claim','sources':{}}
for source,rows in records.items():
 samples=[r for r in rows if r['phase']=='soak' and r['arrival_monotonic']>=start+5]
 times=[r['arrival_monotonic'] for r in samples]
 gaps=[b-a for a,b in zip(times,times[1:])]
 total_gaps=[b['arrival_monotonic']-a['arrival_monotonic'] for a,b in zip(rows,rows[1:])]
 report['sources'][source]={'soak_samples':len(samples),'soak_observed_s':times[-1]-times[0],
  'soak_hz':(len(samples)-1)/(times[-1]-times[0]),'soak_max_gap_s':max(gaps),
  'whole_capture_largest_gap_s':max(total_gaps),'soak_frames':sorted(set(r['frame'] for r in samples)),
  'soak_timestamp_backsteps':sum(b['stamp']<=a['stamp'] for a,b in zip(samples,samples[1:])),
  'soak_tf_ok':sum(r['tf_at_stamp'] for r in samples),
  'soak_age_min_s':min(r['age_s'] for r in samples),'soak_age_max_s':max(r['age_s'] for r in samples),
  'soak_valid_ranges_min':min(r['valid_ranges'] for r in samples),
  'soak_valid_ranges_max':max(r['valid_ranges'] for r in samples)}
 assert times[-1]-times[0]>=890
 assert report['sources'][source]['soak_frames']==['base_lidar_link_'+source.upper()+'_1']
 assert report['sources'][source]['soak_timestamp_backsteps']==0
 assert report['sources'][source]['soak_tf_ok']==len(samples)
 assert report['sources'][source]['soak_valid_ranges_min']>0
 assert max(total_gaps)>20 # Physical loss is independently confirmed by operator.
summary=json.loads((root/'summary.json').read_text())
log=(root/'lidar.log').read_text()
assert 'process has died' not in log
assert sorted(re.findall(r'\[(picoscan_(?:fl|br))-\d+\]: process has finished cleanly',log))==['picoscan_br','picoscan_fl']
assert all(value==0 for value in summary['shutdown'].values())
report['shutdown']=summary['shutdown']
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
