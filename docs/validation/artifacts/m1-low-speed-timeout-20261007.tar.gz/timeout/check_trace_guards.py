import copy
from timeout_evidence import native_transition, wheel_transition

def header(value):
    sec=int(value)
    return {'header':{'stamp':{'sec':sec,'nanosec':round((value-sec)*1e9)}}}
def output(mono,ros,value):
    m=header(ros);m['twist']={'linear':{'x':value}}
    return {'topic':'cmd_vel_out','time_monotonic':mono,'message':m}
def wheels(mono,ros,values):
    m=header(ros);m.update(name=['left_wheel_joint','right_wheel_joint'],velocity=values)
    return {'topic':'joints','time_monotonic':mono,'message':m}
window={'quiet_start':10.,'quiet_start_ros':1010.,'last_nonzero':9.9,'last_nonzero_ros':1009.9}
valid=[output(9.96,1009.95,.1),wheels(9.96,1009.95,[1.25,1.25]),output(10.21,1010.2,0.),wheels(10.26,1010.25,[0.,0.]),output(10.3,1010.3,0.)]
first=native_transition(valid,window,13.);assert first['time_monotonic']==10.21
assert wheel_transition(valid,first,13.,1013.)['time_monotonic']==10.26
cases=[]
a=copy.deepcopy(valid);a[2]=output(10.21,1008.,0.);a[4]=output(10.3,1008.1,0.);cases.append(a)
a=copy.deepcopy(valid);a[2]=output(12.8,1012.8,0.);a[4]=output(12.9,1012.9,0.);cases.append(a)
a=copy.deepcopy(valid);a[0]=output(9.96,1009.95,0.);cases.append(a)
a=copy.deepcopy(valid);a[1]=wheels(9.96,1009.95,[0.,0.]);cases.append(a)
a=copy.deepcopy(valid);a[4]=output(10.3,1010.3,.1);cases.append(a)
for i,events in enumerate(cases):
    try:native_transition(events,window,13.)
    except RuntimeError:continue
    raise AssertionError(f'false native transition accepted: {i}')
for bad in ([wheels(13.01,1013.01,[0.,0.])],[wheels(10.26,1008.,[0.,0.])],[wheels(10.26,1010.25,[0.,1.25])]):
    try:wheel_transition(bad,first,13.,1013.)
    except RuntimeError:continue
    raise AssertionError('false wheel stop accepted')
print('Trace guards: valid transition accepted; 8 stale/late/no-prior-motion/restart/after-cleanup/incomplete-stop cases rejected; no hardware access.')
