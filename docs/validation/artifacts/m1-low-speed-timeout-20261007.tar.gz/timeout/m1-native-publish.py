import json,time
from pathlib import Path
import rclpy
from geometry_msgs.msg import TwistStamped
root=Path('/evidence/timeout');commands=[];complete=False
rclpy.init();node=rclpy.create_node('m1_bounded_timeout_publisher');pub=node.create_publisher(TwistStamped,'/base_controller/cmd_vel',10)
def emit(value):
 msg=TwistStamped();msg.header.stamp=node.get_clock().now().to_msg();msg.twist.linear.x=value
 pub.publish(msg);commands.append({'time_monotonic':time.monotonic(),'linear_x':value,'angular_z':0.0,'ros_stamp':msg.header.stamp.sec+msg.header.stamp.nanosec/1e9})
try:
 deadline=time.monotonic()+3
 while pub.get_subscription_count()==0:
  rclpy.spin_once(node,timeout_sec=.02)
  if time.monotonic()>deadline:raise RuntimeError('no native subscriber; no motion')
 start=time.monotonic()
 for i in range(100):
  if (root/'m1-observation-abort').exists():raise RuntimeError('observer aborted')
  if time.monotonic()-start>=10:break
  emit(.1)
  end=start+(i+1)*.1
  while time.monotonic()<end:rclpy.spin_once(node,timeout_sec=min(.02,end-time.monotonic()))
 quiet_start=time.monotonic()
 (root/'timeout-window.json').write_text(json.dumps({'quiet_start':quiet_start,'last_nonzero':commands[-1]['time_monotonic'],'last_nonzero_ros':commands[-1]['ros_stamp'],'quiet_start_ros':node.get_clock().now().nanoseconds/1e9}))
 print('NONZERO_PUBLICATION_ENDED; NO ZERO FOR THREE-SECOND OBSERVATION',flush=True)
 end=quiet_start+3
 while time.monotonic()<end:
  if (root/'m1-observation-abort').exists():raise RuntimeError('observer aborted during timeout window')
  rclpy.spin_once(node,timeout_sec=.02)
 complete=True
finally:
 # Normal-run cleanup zero is only AFTER the independent timeout observation.
 # Any failure requests immediate zero; that case cannot pass timeout acceptance.
 emit(0.0)
 (root/'m1-native-commands.json').write_text(json.dumps(commands,indent=2))
 (root/'publisher-outcome.json').write_text(json.dumps({'completed_timeout_window':complete}))
 end=time.monotonic()+.7
 while time.monotonic()<end:rclpy.spin_once(node,timeout_sec=.02)
 (root/'finish-m1-observation').write_text('publisher ended; timeout window precedes cleanup zero')
 node.destroy_node();rclpy.shutdown()
