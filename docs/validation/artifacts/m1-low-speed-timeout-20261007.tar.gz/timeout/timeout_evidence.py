"""Public ROS trace checks for this supervised commissioning test only."""
import math


def ros_stamp(message):
    stamp = message['header']['stamp']
    return stamp['sec'] + stamp['nanosec'] / 1e9


def wheel_values(message):
    names, velocities = message['name'], message['velocity']
    if len(names) != len(velocities):
        raise RuntimeError('incomplete timeout wheel feedback')
    values = []
    for wheel in ('left_wheel_joint', 'right_wheel_joint'):
        if names.count(wheel) != 1:
            raise RuntimeError('missing/duplicate timeout wheel feedback')
        value = velocities[names.index(wheel)]
        if not math.isfinite(value):
            raise RuntimeError('nonfinite timeout wheel feedback')
        values.append(value)
    return values


def native_transition(events, window, cutoff):
    """Require recent movement and one native zero transition, not queued zeros."""
    quiet, quiet_ros = window['quiet_start'], window['quiet_start_ros']
    recent = [e for e in events if quiet - .2 <= e.get('time_monotonic', -1) <= quiet
              and e.get('topic') in ('cmd_vel_out', 'joints')
              and quiet_ros - .2 <= ros_stamp(e['message']) <= quiet_ros]
    positive = [e for e in recent if e['topic'] == 'cmd_vel_out'
                and abs(e['message']['twist']['linear']['x'] - .1) < 1e-9]
    moving = [e for e in recent if e['topic'] == 'joints'
              and all(v > .8 for v in wheel_values(e['message']))]
    if not positive or not moving:
        raise RuntimeError('no fresh nonzero native output/both moving wheels before silence')
    outputs = [e for e in events if e.get('topic') == 'cmd_vel_out'
               and quiet <= e['time_monotonic'] < cutoff
               and ros_stamp(e['message']) >= quiet_ros]
    zeros = [e for e in outputs if abs(e['message']['twist']['linear']['x']) < 1e-9]
    if not zeros:
        raise RuntimeError('no new native zero in quiet window')
    first = min(zeros, key=lambda e: ros_stamp(e['message']))
    stamp = ros_stamp(first['message'])
    generated_delay = stamp - window['last_nonzero_ros']
    receipt_delay = first['time_monotonic'] - window['last_nonzero']
    # Engineering gate: configured .3s, nominal .05s period, .2s margin.
    # Lower bound rejects an unrelated early zero transition.
    if not .25 <= generated_delay <= .5 or not 0 <= receipt_delay <= .5:
        raise RuntimeError('native zero transition outside commissioning timing gate')
    if any(abs(e['message']['twist']['linear']['x']) > 1e-9
           for e in outputs if ros_stamp(e['message']) >= stamp):
        raise RuntimeError('nonzero native output resumed during quiet window')
    return first


def wheel_transition(events, first_zero, cleanup_mono, cleanup_ros):
    samples = [e for e in events if e.get('topic') == 'joints'
               and first_zero['time_monotonic'] <= e['time_monotonic'] < cleanup_mono
               and ros_stamp(first_zero['message']) <= ros_stamp(e['message']) < cleanup_ros]
    stopped = [e for e in samples if all(abs(v) <= .03 for v in wheel_values(e['message']))]
    if not stopped:
        raise RuntimeError('no new complete wheel-stop feedback before cleanup zero')
    first = min(stopped, key=lambda e: ros_stamp(e['message']))
    if any(any(abs(v) > .03 for v in wheel_values(e['message']))
           for e in samples if ros_stamp(e['message']) >= ros_stamp(first['message'])):
        raise RuntimeError('wheel motion resumed during quiet window')
    return first
