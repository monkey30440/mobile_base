import json,math,signal,subprocess,time
from pathlib import Path
import rclpy
from sensor_msgs.msg import Imu
from diagnostic_msgs.msg import DiagnosticArray
from rosidl_runtime_py.convert import message_to_ordereddict
root=Path('/tmp/mobile-base-36-live');root.mkdir(exist_ok=True)
rclpy.init();node=rclpy.create_node('imu_acceptance_observer');samples=[];diags=[]
node.create_subscription(Imu,'/imu/data_raw',lambda m:samples.append({'receipt':time.monotonic(),'data':message_to_ordereddict(m)}),10)
node.create_subscription(DiagnosticArray,'/diagnostics',lambda m:diags.append(message_to_ordereddict(m)),10)
log=open(root/'launch.log','w');p=subprocess.Popen(['ros2','launch','mobile_base_perception','imu.launch.py'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
try:
 end=time.monotonic()+12
 while time.monotonic()<end:
  rclpy.spin_once(node,timeout_sec=.02)
  if p.poll() is not None:raise RuntimeError('IMU launch exited')
 assert len(samples)>1000,len(samples)
 stamps=[s['data']['header']['stamp']['sec']+s['data']['header']['stamp']['nanosec']/1e9 for s in samples]
 assert all(b>=a for a,b in zip(stamps,stamps[1:]))
 for s in samples:
  m=s['data'];assert m['header']['frame_id']=='base_imu_link'
  assert m['orientation_covariance'][0]==-1
  assert m['angular_velocity_covariance']==[0.0]*9 and m['linear_acceleration_covariance']==[0.0]*9
  assert all(math.isfinite(m[k][a]) for k in ('angular_velocity','linear_acceleration') for a in ('x','y','z'))
 states=[s for m in diags for s in m['status'] if s['name']=='usb_imu: USB IMU']
 assert states and states[-1]['level'] in (0, bytes([0]), '\x00'),states[-1] if states else 'no status'
 summary={'samples':len(samples),'rate':(len(samples)-1)/(samples[-1]['receipt']-samples[0]['receipt']),'last_diagnostic':states[-1], 'monotonic_stamps':True}
 print(json.dumps(summary,default=lambda v:list(v)),flush=True)
finally:
 if p.poll() is None:p.send_signal(signal.SIGINT)
 try:p.wait(timeout=10)
 except subprocess.TimeoutExpired:p.kill();p.wait()
 log.close();node.destroy_node();rclpy.try_shutdown()
 (root/'samples.json').write_text(json.dumps(samples))
 (root/'diagnostics.json').write_text(json.dumps(diags,default=lambda v:list(v)))
 print('launch_exit',p.returncode,flush=True)
 assert p.returncode==0
