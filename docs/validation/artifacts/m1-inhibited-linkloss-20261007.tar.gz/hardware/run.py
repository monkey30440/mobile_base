import os,sys,time,json,signal,subprocess,importlib.util,xml.etree.ElementTree as ET
from pathlib import Path
import yaml,rclpy
from diagnostic_msgs.msg import DiagnosticArray
from controller_manager_msgs.srv import ListHardwareComponents,ListControllers
root=Path('/evidence'); mode=sys.argv[1]; peer=None
if mode not in ('software','hardware'):raise ValueError('explicit software/hardware mode required')
config=yaml.safe_load(Path('/workspace/src/mobile_base_m1/config/rwf.commissioning.yaml').read_text())
if mode=='software':
 spec=importlib.util.spec_from_file_location('workflow','/workspace/src/mobile_base_m1/test/test_workflow.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 peer=mod.Peer(require_enable=True);config['hardware']['serial_port']=peer.path
robot=ET.fromstring((root/'model.urdf').read_text());ctl=ET.SubElement(robot,'ros2_control',name='M1',type='system'); hw=ET.SubElement(ctl,'hardware');ET.SubElement(hw,'plugin').text='mobile_base_m1/M1System'
for key,value in config['hardware'].items():ET.SubElement(hw,'param',name=key).text=str(value).lower() if isinstance(value,bool) else str(value)
for name in ('left_wheel_joint','right_wheel_joint'):
 j=ET.SubElement(ctl,'joint',name=name);ET.SubElement(j,'command_interface',name='velocity');ET.SubElement(j,'state_interface',name='velocity')
desc=ET.tostring(robot,encoding='unicode')
(root/'rsp.yaml').write_text(yaml.safe_dump({'robot_state_publisher':{'ros__parameters':{'robot_description':desc}}}))
(root/'manager.yaml').write_text(yaml.safe_dump({'controller_manager':{'ros__parameters':{'update_rate':20,'hardware_components_initial_state':{'inactive':['M1']}}}}))
rclpy.init();node=rclpy.create_node('inactive_linkloss_observer');records=[];processes=[];logs=[];outcome=None;healthy_until=0
def callback(msg):
 records.append({'mono':time.monotonic(),'stamp_ns':msg.header.stamp.sec*1000000000+msg.header.stamp.nanosec,'statuses':[{'name':s.name,'level':int.from_bytes(s.level,'little') if isinstance(s.level,bytes) else int(s.level),'message':s.message,'hardware_id':s.hardware_id,'values':{v.key:v.value for v in s.values}} for s in msg.status]})
node.create_subscription(DiagnosticArray,'/diagnostics',callback,20)
def statuses():
 latest={}
 for r in records:
  for s in r['statuses']:
   if any(v in s['name'] for v in ('left_wheel_joint','right_wheel_joint')):latest[s['name']]=(r,s)
 return [s for r,s in latest.values() if time.monotonic()-r['mono']<1.5 and r['stamp_ns']>=healthy_until]
def call(service,kind):
 client=node.create_client(kind,service)
 if not client.wait_for_service(timeout_sec=5):raise RuntimeError('native service unavailable '+service)
 future=client.call_async(kind.Request());rclpy.spin_until_future_complete(node,future,timeout_sec=5)
 if not future.done() or future.result() is None:raise RuntimeError('native service failed '+service)
 answer=future.result();node.destroy_client(client);return answer

def wait(condition,seconds):
 until=time.monotonic()+seconds
 while time.monotonic()<until:
  rclpy.spin_once(node,timeout_sec=.05)
  if any(p.poll() is not None for p in processes):raise RuntimeError('native process exited')
  if condition():return
 raise RuntimeError('bounded observation deadline exceeded')
try:
 for name,cmd in [('rsp',['ros2','run','robot_state_publisher','robot_state_publisher','--ros-args','--params-file',str(root/'rsp.yaml')]),('manager',['ros2','run','controller_manager','ros2_control_node','--ros-args','--params-file',str(root/'manager.yaml')])]:
  log=open(root/(name+'.log'),'w');logs.append(log);processes.append(subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True))
 wait(lambda:all(any(n in s['name'] and s['values'].get('feedback_valid')=='True' and s['values'].get('motor_status')=='6' and s['values'].get('alarm_code')=='0' for s in statuses()) for n in ('left_wheel_joint','right_wheel_joint')),20)
 hardware=call('/controller_manager/list_hardware_components',ListHardwareComponents)
 controllers=call('/controller_manager/list_controllers',ListControllers)
 if len(hardware.component)!=1 or hardware.component[0].name!='M1' or hardware.component[0].state.id!=2 or controllers.controller:raise RuntimeError('expected sole INACTIVE M1 and no controllers')
 wait(lambda:all(any(n in s['name'] and s['values'].get('feedback_valid')=='True' and s['values'].get('motor_status')=='6' and s['values'].get('alarm_code')=='0' for s in statuses()) for n in ('left_wheel_joint','right_wheel_joint')),20)
 if peer and peer.lifecycle_commands:raise RuntimeError('inactive hardware unexpectedly wrote command')
 (root/'ready.json').write_text(json.dumps({'mono':time.monotonic(),'mode':mode,'state':'native inactive, inhibited feedback valid'}))
 if peer:peer.silent=True
 else:wait(lambda:(root/'disconnect-window').exists(),180)
 started=time.monotonic();healthy_until=node.get_clock().now().nanoseconds
 wait(lambda:all(any(n in s['name'] and s['level']==2 and s['values'].get('feedback_valid')=='False' and 'failed/timeout' in s['message'] for s in statuses()) for n in ('left_wheel_joint','right_wheel_joint')),8)
 outcome={'mode':mode,'result':'both source diagnostics ERROR, feedback invalid','observation_seconds':time.monotonic()-started,'no_servo_on':None if peer is None else 6 not in peer.lifecycle_commands,'no_nonzero':None if peer is None else all(a==0 and b==0 for a,b in peer.commands)}
 if peer and (6 in peer.lifecycle_commands or any(a or b for a,b in peer.commands)):raise RuntimeError('unexpected motion request')
except Exception as e:
 (root/'failure.json').write_text(json.dumps({'error':str(e)}));raise
finally:
 for p in reversed(processes):
  if p.poll() is None:os.killpg(p.pid,signal.SIGINT)
 for p in processes:
  try:p.wait(timeout=8)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 (root/'diagnostics.json').write_text(json.dumps(records,indent=2))
 if peer:
  (root/'wire.json').write_text(json.dumps({'requests':[r.hex() for r in peer.requests],'lifecycle_commands':peer.lifecycle_commands,'commands':peer.commands},indent=2))
  if 6 in peer.lifecycle_commands or any(a or b for a,b in peer.commands):
   outcome=None;(root/'failure.json').write_text(json.dumps({'error':'unexpected final trace motion request'}))
  peer.close()
 for f in logs:f.close()
 node.destroy_node();rclpy.shutdown()

if outcome is not None:(root/'result.json').write_text(json.dumps(outcome,indent=2))
else:raise RuntimeError('acceptance failed')
