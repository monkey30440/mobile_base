"""Temporary actual ROS observer: no velocity publisher; Operator moves only."""
import json,os,signal,subprocess,time,math
from pathlib import Path
import rclpy
from sensor_msgs.msg import Imu
from nav_msgs.msg import Odometry
from tf2_msgs.msg import TFMessage
from rclpy.qos import qos_profile_sensor_data
out=Path('/tmp/imu50-integrated-live');out.mkdir(exist_ok=True)
(out/'pid').write_text(str(os.getpid()))
stopping=False

def stop(sig,frame):
 global stopping
 stopping=True

rclpy.init();signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)
node=rclpy.create_node('imu50_integrated_observer');latest={};counts={};edges={};processes=[];logs=[]
stream=(out/'samples.jsonl').open('w')

def observe(topic):
 def callback(m):
  counts[topic]=counts.get(topic,0)+1
  row={'t':time.monotonic(),'stamp':m.header.stamp.sec+m.header.stamp.nanosec/1e9,'frame':m.header.frame_id}
  if isinstance(m,Imu):row.update(gyro=[m.angular_velocity.x,m.angular_velocity.y,m.angular_velocity.z],covariance=list(m.angular_velocity_covariance))
  else:
   q=m.pose.pose.orientation
   row.update(vx=m.twist.twist.linear.x,wz=m.twist.twist.angular.z,x=m.pose.pose.position.x,y=m.pose.pose.position.y,yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z)))
  latest[topic]=row;stream.write(json.dumps({'topic':topic,**row})+'\n')
 return callback
for topic,kind in [('/imu/data_raw',Imu),('/imu/data',Imu),('/base_controller/odom',Odometry),('/odometry/filtered',Odometry)]:node.create_subscription(kind,topic,observe(topic),qos_profile_sensor_data)

def tf(m):
 for t in m.transforms:edges[t.header.frame_id+' -> '+t.child_frame_id]=time.monotonic()
node.create_subscription(TFMessage,'/tf',tf,100)
try:
 for name,command in [('description',['ros2','launch','mobile_base_description','description.launch.py']),('imu',['ros2','launch','mobile_base_perception','imu.launch.py']),('control',['ros2','launch','mobile_base_control','m1.launch.py']),('odometry',['ros2','launch','mobile_base_odometry','odometry.launch.py'])]:
  log=(out/(name+'.log')).open('w');logs.append(log)
  processes.append(subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True))
 start=time.monotonic();last=start
 print('Installed components started; NO velocity publisher. Awaiting Operator zero initialization.',flush=True)
 while not stopping and time.monotonic()-start<900:
  assert all(p.poll() is None for p in processes),'component exited'
  rclpy.spin_once(node,timeout_sec=.02)
  if time.monotonic()-last>5:
   last=time.monotonic();stream.flush();(out/'latest.json').write_text(json.dumps({'elapsed':last-start,'counts':counts,'latest':latest,'edges':edges},indent=2))
finally:
 for p in reversed(processes):
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGINT)
   try:p.wait(timeout=12)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 stream.close();node.destroy_node();rclpy.shutdown()
 for log in logs:log.close()
