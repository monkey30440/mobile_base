"""Temporary commissioning harness: IMU only, no Control or velocity commands."""
import json,signal,subprocess,time
from pathlib import Path
import rclpy
from sensor_msgs.msg import Imu
from rclpy.qos import qos_profile_sensor_data

out=Path('/tmp/imu50-calibration-live');out.mkdir(exist_ok=True)
rclpy.init();node=rclpy.create_node('imu50_calibration_observer');samples=[]
def sample(m):
 samples.append({'stamp':m.header.stamp.sec+m.header.stamp.nanosec/1e9,'frame':m.header.frame_id,'gyro':[m.angular_velocity.x,m.angular_velocity.y,m.angular_velocity.z],'covariance':list(m.angular_velocity_covariance)})
node.create_subscription(Imu,'/imu/data_raw',sample,qos_profile_sensor_data)
processes=[];logs=[]
try:
 for name,args in [('imu',['ros2','launch','mobile_base_perception','imu.launch.py']),('calibrate',['ros2','run','mobile_base_perception','calibrate_imu','--stationary','--output','/workspace/src/mobile_base_perception/config/imu_calibration.yaml'])]:
  log=(out/(name+'.log')).open('w');logs.append(log)
  processes.append(subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True))
 start=time.monotonic();last=start
 while processes[1].poll() is None:
  assert processes[0].poll() is None,(out/'imu.log').read_text()
  assert time.monotonic()-start<80,'calibration deadline exceeded'
  rclpy.spin_once(node,timeout_sec=.02)
  if time.monotonic()-last>5:
   last=time.monotonic();(out/'latest.json').write_text(json.dumps({'elapsed_s':last-start,'raw_samples':len(samples)},indent=2))
 assert processes[1].returncode==0,(out/'calibrate.log').read_text()
 print((out/'calibrate.log').read_text(),flush=True)
finally:
 for p in reversed(processes):
  if p.poll() is None:
   p.send_signal(signal.SIGINT)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait()
 (out/'samples.json').write_text(json.dumps(samples));node.destroy_node();rclpy.shutdown()
 for log in logs:log.close()
