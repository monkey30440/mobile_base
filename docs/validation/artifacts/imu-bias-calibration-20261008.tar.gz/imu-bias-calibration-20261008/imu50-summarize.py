import json,math,statistics,sys
from pathlib import Path
rows=[json.loads(line) for line in Path(sys.argv[1]).read_text().splitlines()]
start=float(sys.argv[2]) if len(sys.argv)>2 else min(r['t'] for r in rows if r['topic']=='/base_controller/odom')+5
end=float(sys.argv[3]) if len(sys.argv)>3 else max(r['t'] for r in rows)
result={'start_monotonic':start,'end_monotonic':end,'duration_s':end-start}
for topic in ['/imu/data_raw','/imu/data','/base_controller/odom','/odometry/filtered']:
 data=[r for r in rows if r['topic']==topic and start<=r['t']<=end]
 if not data:continue
 rates=[r['gyro'][2] if 'gyro' in r else r['wz'] for r in data]
 report={'samples':len(data),'mean_wz':statistics.mean(rates),'std_wz':statistics.stdev(rates),'max_abs_wz':max(map(abs,rates)),'max_receipt_gap_s':max(b['t']-a['t'] for a,b in zip(data,data[1:]))}
 if 'yaw' in data[0]:
  delta=sum(math.atan2(math.sin(b['yaw']-a['yaw']),math.cos(b['yaw']-a['yaw'])) for a,b in zip(data,data[1:]))
  report.update(yaw_delta_rad=delta,yaw_delta_deg=math.degrees(delta),xy_delta_m=math.hypot(data[-1]['x']-data[0]['x'],data[-1]['y']-data[0]['y']),max_abs_vx=max(abs(r['vx']) for r in data))
 result[topic]=report
print(json.dumps(result,indent=2))
