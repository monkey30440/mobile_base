"""IMU-only node restart acceptance. No Control or velocity publisher."""
import json,os,signal,subprocess,time,statistics
from pathlib import Path
import rclpy
from sensor_msgs.msg import Imu
from rclpy.qos import qos_profile_sensor_data
import yaml
out=Path('/tmp/imu50-restart-live');out.mkdir(exist_ok=True)
cal=yaml.safe_load(Path('/workspace/src/mobile_base_perception/config/imu_calibration.yaml').read_text())
rclpy.init();node=rclpy.create_node('imu50_restart_observer');raw={};corrected=[];samples=[]
def source(m):raw[(m.header.stamp.sec,m.header.stamp.nanosec)]=m
node.create_subscription(Imu,'/imu/data_raw',source,qos_profile_sensor_data)
node.create_subscription(Imu,'/imu/data',corrected.append,qos_profile_sensor_data)
with (out/'imu.log').open('w') as log:
 p=subprocess.Popen(['ros2','launch','mobile_base_perception','imu.launch.py'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  start=time.monotonic()
  while time.monotonic()-start<65:
   assert p.poll() is None,(out/'imu.log').read_text()
   rclpy.spin_once(node,timeout_sec=.01)
   while corrected:
    m=corrected.pop(0);key=(m.header.stamp.sec,m.header.stamp.nanosec)
    if key not in raw:corrected.insert(0,m);break
    original=raw.pop(key)
    rates=[m.angular_velocity.x,m.angular_velocity.y,m.angular_velocity.z];uncompensated=[original.angular_velocity.x,original.angular_velocity.y,original.angular_velocity.z]
    assert all(abs((uncompensated[i]-rates[i])-cal['angular_velocity_bias'][i])<1e-12 for i in range(3))
    assert m.header.frame_id==original.header.frame_id=='base_imu_link'
    samples.append({'elapsed':time.monotonic()-start,'stamp':key,'raw':uncompensated,'corrected':rates})
  heldout=[s for s in samples if s['elapsed']>=5];assert len(heldout)>5000,'insufficient restart data'
  report={'restart_boundary':'IMU ROS node stop/start, no device or host power cycle','matched_samples':len(heldout),'duration_s':heldout[-1]['elapsed']-heldout[0]['elapsed'],'bias_file':cal,'raw_mean':[statistics.mean(s['raw'][i] for s in heldout) for i in range(3)],'corrected_mean':[statistics.mean(s['corrected'][i] for s in heldout) for i in range(3)]}
  (out/'summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
 finally:
  os.killpg(p.pid,signal.SIGINT)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  (out/'samples.json').write_text(json.dumps(samples));node.destroy_node();rclpy.shutdown()
