## Destination

建立 Cleared V1 Wayfinder Map：五項 V1 能力的架構決策已透過 research 與真人 decision tickets 釐清，原生能力完整性、confirmed gaps、最小 custom responsibilities 與後續硬體驗證／標定項目可追溯，足供下一階段 `/to-spec #<map_issue>` 使用。

Status: **REOPENED — V1 IMU bias calibration gap research**。

2026-10-08 限定修訂：Operator 已將人工靜止 IMU 零偏標定、保存／套用補償與靜止／慢速旋轉驗證納入 V1，取代「本項標定全部留後續」的先前界線。先處理新 research／真人 decision，更新適當 spec，再按已授權順序實作；不重做其他已確認 decisions。既有 dataset 清理結果保留。

歷史狀態：**CLEARED — dataset specification gap resolved**。本輪補足 occupancy map／route graph dataset contract，全部 15 張 research／decision 子 tickets 已結案，最新 V1 Specification 已限定修正。無新增 runtime／implementation planning；下一階段需使用者明確啟動 `/to-tickets #32`。

## Notes

本輪以使用者 2026-10-02 提供且再次確認的 V1 Requirements / Hardware Facts 為唯一需求與硬體起點；完全忽略現行 spec 與舊 Wayfinder map，不讀取或沿用其決策。GitHub decision tickets 是本輪決策的唯一保存位置，map 僅索引；不變更 production baseline。

V1：Mapping、Localization、Navigation、Diagnostics、Bringup。Mapping：Mapping Bringup → Teleop → 建圖 → 儲存 → 供定位與導航使用。Localization：Navigation Bringup 後可尚未定位，允許從地圖外 Teleop 進入地圖，Operator 提供 Initial Pose，建立定位後導航。Bringup readiness 與 localization established 分開。

Navigation：NavigateToPose(x,y,yaw)，正常行駛必須經既定路網；從目前位置進入路網，沿路網前往目標方向，接近目標後離開路網到達目標。路網被障礙物阻擋時可必要局部避障、暫時偏離並回到路網；無法符合需求則任務失敗。路網由 Operator 人工準備。Navigation／Teleop 互斥由 Operator 操作流程負責：開始導航前結束 Teleop，開始 Teleop 前取消導航並等待任務結束。初版不要求系統強制互斥、衝突請求攔截或自動切換；零速度／timeout 不等同操作結束。Route Server、First/Last Mile、MPPI 均非預選方案。

Diagnostics：涵蓋移動底座核心硬體／軟體（使用者已排除 V1 Compute 診斷），顯示影響核心 workflow 的重要異常、元件來源、基本原因／狀態與必要故障排查資訊。Bringup：Mapping 與 Navigation 兩種情境，核心元件達到功能可使用狀態。

硬體：Jetson AGX Orin；使用者已指定原始 RWF_V2.0_QA_release.urdf（本機 src/mobile_base_description/ref/FIH_AMR_ROBOT_V2.0_0731/urdf/，SHA256 b49ef5cc66217ff5fb527a4d10a1d63b5f941dbd024bb30bb6704442c39e08fc）；M1 / RS485 / Modbus / Multi-drive 2.0，USB→RS485；IIM-42652，USB；SICK picoScan150，Ethernet。提供的 URDF 與硬體規格為權威；若檔案缺失，記錄 UNRESOLVED，不從既有 project-owned model 補猜。

版本：Ubuntu 24.04、ROS 2 Jazzy；Nav2、slam_toolbox 等採研究當時適用 Jazzy 的當前穩定版本。版本、tag/commit、查核日期與 Jetson 相容性需有證據，不把 latest main 等同穩定版。

架構推導：Requirement → Capability → Responsibility → upstream/native capability → completeness → confirmed gap → minimal custom responsibility。MVP / YAGNI / native-first / clear responsibility / ownership / state semantics / evidence-based；最少 project-owned runtime code。現有 project-owned implementation 禁作架構參考，僅 src/tdk_ros2_imu 可作經驗／驗證 reference，仍需獨立推導。

每次遵循已安裝 mattpocock skills：wayfinder、grilling、domain-modeling；research ticket 由 /research subagent 解決。先 claim，再研究；decision ticket 需真人交換與明確確認，單 session 最多解決一張非 research ticket。研究分 CONFIRMED / UNRESOLVED / REQUIRES HARDWARE VALIDATION / REQUIRES CALIBRATION；硬體驗證與標定留後續，不將軟體 evidence 說成硬體驗證。必要 software verification 使用 repository Docker 工作流，先檢查可重用 evidence。

本次 destination/frontier 訪談已由使用者確認上述五能力範圍、版本基準、人工路網與取消後 Teleop。已確認架構決策見 Decisions so far；未決內容依 frontier tickets 處理。不要讀現行 spec／舊 map；repository inspection 限硬體資料、工具／container 機制與明確允許的 IMU reference。使用 GitNexus 進行允許的 code exploration；不修改 runtime code。


## Decisions so far

Research resolutions 記錄證據；architecture decisions 的真人確認與詳細 resolution 保存在各 decision ticket。

- [Jazzy 平台、硬體接入與本地運動原生能力](https://github.com/monkey30440/mobile_base/issues/19#issuecomment-5943453206) — Orin Ubuntu24.04 與原生硬體接入邊界已查證；原始 URDF 已補充分析，實機設定／標定仍需後續 evidence

- [Diagnostics / Bringup native boundaries](https://github.com/monkey30440/mobile_base/issues/21#issuecomment-5943430424) — Native expected/stale diagnostics and staged lifecycle primitives confirmed; map-frame navigation activation needs global TF; ownership/coverage 已由 Diagnostics 與 Bringup decisions 解決。

- [Mapping、Localization 與路網 NavigateToPose 原生完整性研究](https://github.com/monkey30440/mobile_base/issues/20#issuecomment-5943438208) — Jazzy 1.3.13 原生 route primitives 已確認；端點銜接原生候選已查證，選擇見 Navigation decision；沿網／避障回網留實機驗收。

- [Navigation／Teleop operator procedure and native boundaries](https://github.com/monkey30440/mobile_base/issues/28#issuecomment-5943717534) — Final V1 exclusion is Operator procedure; native cancel terminal evidence and explicit Teleop end support it; automatic admission enforcement is out of scope.

- [V1 Decision — 平台、硬體接入與本地運動責任](https://github.com/monkey30440/mobile_base/issues/22#issuecomment-5943788571) — 已確認原生平台／控制／感測與本地估測、footprint TF ownership、最小裝置 adapter 邊界及 Operator 交接；frame 大小寫留實作統一，硬體驗證／標定待後續。

- [V1 Research — 雙 picoScan150 的原生 Mapping 輸入能力](https://github.com/monkey30440/mobile_base/issues/29#issuecomment-5943893379) — slam_toolbox2.8.5同topic雙frame仍有Karto sensor-name覆寫缺口；單台原生Mapping可行，upstream merger有ray/time近似，選擇見 Mapping decision。

- [V1 Decision — Mapping 與地圖儲存重用責任](https://github.com/monkey30440/mobile_base/issues/23#issuecomment-5943908909) — 原生 slam_toolbox 使用前左單雷射建圖並發布 map→odom；交付 map.pgm + map.yaml，以原生能力儲存重用；無新增 Mapping custom runtime，實機品質待驗證。

- [V1 Decision — Initial Pose 定位與導航使用邊界](https://github.com/monkey30440/mobile_base/issues/24#issuecomment-5943964561) — map_server + AMCL 使用前左 LiDAR；每次等待 Operator Initial Pose，由 Operator 確認定位可用；AMCL 唯一 map→odom owner，不新增 Localization custom runtime。

- [V1 Research — 路網 NavigateToPose 原生組合與避障回網完整性](https://github.com/monkey30440/mobile_base/issues/30#issuecomment-5944066381) — 穩定Jazzy route／connectors／BT與MPPI或DWB原生責任候選已查證；無已確認custom runtime gap，真實沿網／避障回網及失敗留後續驗證。

- [V1 Decision — 路網 NavigateToPose 與必要避障責任](https://github.com/monkey30440/mobile_base/issues/25#issuecomment-5944111772) — Route Server + NavFn + 原生 BT + MPPI，雙獨立 obstacle sources；允許替代合法路線，保留回網／failure 驗收，無預新增 custom Navigation runtime。

- [Selected V1 Diagnostics coverage and minimal gaps](https://github.com/monkey30440/mobile_base/issues/31#issuecomment-5944228424) — picoScan generic updater excluded; native transport/action/log/consumer/tool evidence available; smallest device checks belong to required M1/IMU adapters.

- [V1 Decision — 核心 Diagnostics 覆蓋與狀態 ownership](https://github.com/monkey30440/mobile_base/issues/26#issuecomment-5944271743) — 原生 diagnostics／rqt 配合 native logs/results；最小裝置診斷由 M1／USB IMU adapters 擁有，Compute 診斷排除，無全域 health manager。

- [V1 Decision — 兩種 Bringup 與定位分離的 readiness 語意](https://github.com/monkey30440/mobile_base/issues/27#issuecomment-5944312692) — 情境 launch/configuration；Navigation 先 configure/inactive，未定位可完成 Bringup 且 Teleop 可用，Operator 確認定位後原生啟用，無 custom readiness runtime。

- [V1 Research — Occupancy map 與 Route Server graph 的原生資料契約](https://github.com/monkey30440/mobile_base/issues/33#issuecomment-5944563912) — 已確認原生 GeoJSON／graph_filepath、独立 map/graph loaders、無自動配對驗證與非原子 reload；dataset 操作 contract 留真人決策。

- [V1 Decision — Navigation map dataset 配對與人工準備流程](https://github.com/monkey30440/mobile_base/issues/34#issuecomment-5944616227) — 單一 dataset directory／固定三檔／缺一報錯；人工 graph、Mapping 不加 map檢查，原生 loading，目錄命名留實作。

## Not yet specified

Dataset architecture/spec gap 已解決。新限定 gap：人工靜止標定的有效前提、持久補償資料、來源 ownership 與失效語意，依新 research 結果形成一張真人 decision ticket。具體 launch arguments／root與folder naming／path resolution 留 implementation；實機／calibration evidence 仍待後續。

## Out of scope

Specification、implementation ticket planning、implementation、migration、production baseline 更新、實機驗證與 calibration 執行；NavigateToStation、Docking 與未確認的額外產品能力；上半身控制／姿態管理與其 joint-state ownership（其他團隊負責）；系統強制 Navigation／Teleop 互斥（初版由 Operator 管理）。

V1 初版 Compute 診斷（CPU／memory／disk／Orin temperature／throttling／其他 host monitoring）由使用者明確排除；範圍決策見 [核心 Diagnostics 覆蓋與狀態 ownership](https://github.com/monkey30440/mobile_base/issues/26#issuecomment-5944271743)。

本輪經使用者明確授權檢視最新 V1 Specification，並僅在相關真人 decision 確認後修正該 gap；先前不產生 spec 的 Wayfinder 範圍限制於此限定修正例外，runtime／implementation planning 仍排除。
