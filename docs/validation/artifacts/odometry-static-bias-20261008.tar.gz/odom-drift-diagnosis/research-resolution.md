## Resolution — native capability confirmed, minimal gap identified

研究筆記：`docs/research/imu-bias-native-20261008.md`，research branch `research/imu-bias-native`，commit `d239177`（尚未 push）。

已核對 Jazzy imu_tools 2.1.6-1 與 robot_localization 3.8.3：RL 無 gyro bias state；complementary filter online .2 rad/s steady-state gate 有把合法 .10 rad/s 等速轉動吸收為 bias 的條件，且沒有人工 calibration/save/load offset 完整介面。板端 USB trigger/readback/persistence 仍 UNRESOLVED，不從晶片 offset registers 推論 USB firmware 支援。

Confirmed gap：Operator 明確靜止採集、產生可審查 bias、保存／啟動重用，且運行時不把慢速旋轉判為零。最小候選是 offline 人工標定＋既有必要 IMU adapter 明確 SI 常量減法；EKF 保留融合責任，原始來源可追溯、不新增 orientation filter/deadband/adaptive bias。候選待真人 decision，尚未實作。

父流程 heldout native EKF test：相同後段實測資料，現設定 slope −0.000325429 rad/s，添加輪端 yaw-rate −0.000325454，扣前段估得的 bias 後 −0.0000226462（約93%改善）。這只是短期診斷／因果 evidence；正式標定、長期靜止與慢速旋轉／重啟驗證待後續。詳見 `docs/validation/odometry-static-bias-20261008.md`。
