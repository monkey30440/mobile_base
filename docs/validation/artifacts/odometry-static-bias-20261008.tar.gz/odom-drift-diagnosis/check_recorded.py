import json, math, statistics
from pathlib import Path
rows=[json.loads(s) for s in Path('/tmp/mapping39-motion-evidence.jsonl').read_text().splitlines()]
run=[]
for row in reversed(rows):
    if not all(k in row for k in ('/base_controller/odom','/odometry/filtered','imu_wz')):
        break
    w=row['/base_controller/odom']
    if abs(w['vx'])>1e-7 or abs(w['wz'])>1e-7:
        break
    run.append(row)
run.reverse()
assert len(run)>20, 'no continuous stationary segment'
def dyaw(topic):
    return math.atan2(math.sin(run[-1][topic]['yaw']-run[0][topic]['yaw']),math.cos(run[-1][topic]['yaw']-run[0][topic]['yaw']))
duration=run[-1]['time_utc_epoch']-run[0]['time_utc_epoch']
report={'duration_s':duration,'samples':len(run),'wheel_yaw_delta_rad':dyaw('/base_controller/odom'),'filtered_yaw_delta_rad':dyaw('/odometry/filtered'),'imu_mean_wz_rad_s':statistics.mean(r['imu_wz'] for r in run),'filtered_mean_wz_rad_s':statistics.mean(r['/odometry/filtered']['wz'] for r in run),'filtered_xy_delta_m':math.hypot(run[-1]['/odometry/filtered']['x']-run[0]['/odometry/filtered']['x'],run[-1]['/odometry/filtered']['y']-run[0]['/odometry/filtered']['y'])}
Path('/tmp/odom-drift-diagnosis/recorded-result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
# Reproduction detector, NOT an accepted accuracy specification.
assert abs(report['filtered_yaw_delta_rad'])<0.001, 'REPRODUCED: fused yaw changes while measured wheel motion is zero'
