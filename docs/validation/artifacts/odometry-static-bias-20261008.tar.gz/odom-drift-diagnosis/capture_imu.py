import json,signal,subprocess,time
from pathlib import Path
import rclpy
from sensor_msgs.msg import Imu
from rclpy.qos import qos_profile_sensor_data
out=Path('/tmp/odom-drift-live');out.mkdir(exist_ok=True)
rclpy.init();node=rclpy.create_node('stationary_imu_observer');rows=[]
def capture(m):
 rows.append({'stamp':m.header.stamp.sec+m.header.stamp.nanosec/1e9,'frame':m.header.frame_id,'gyro':[m.angular_velocity.x,m.angular_velocity.y,m.angular_velocity.z],'covariance':list(m.angular_velocity_covariance)})
node.create_subscription(Imu,'/imu/data_raw',capture,qos_profile_sensor_data)
with (out/'imu.log').open('w') as log:
 p=subprocess.Popen(['ros2','launch','mobile_base_perception','imu.launch.py'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  deadline=time.monotonic()+35
  while time.monotonic()<deadline:
   assert p.poll() is None,(out/'imu.log').read_text()
   rclpy.spin_once(node,timeout_sec=.05)
 finally:
  p.send_signal(signal.SIGINT)
  p.wait(timeout=10)
  (out/'samples.json').write_text(json.dumps(rows));node.destroy_node();rclpy.shutdown()
assert len(rows)>1000,len(rows)
print('captured',len(rows),'samples; IMU only, no Control or velocity publisher')
