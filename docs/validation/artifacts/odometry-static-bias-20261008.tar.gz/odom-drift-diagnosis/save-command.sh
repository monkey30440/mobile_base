
map_dir="./maps/$(date +%Y%m%d_%H%M%S)"
mkdir -p ./maps &&
mkdir "$map_dir" &&
ros2 run nav2_map_server map_saver_cli -t /map \
  -f "$map_dir/map" --fmt pgm
