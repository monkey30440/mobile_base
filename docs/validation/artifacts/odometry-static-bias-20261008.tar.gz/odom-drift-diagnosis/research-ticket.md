## Question

對 V1 實測的靜止 IMU yaw-rate 零偏及原生 EKF 長期 yaw 漂移，板端 IIM-42652／HandBoard USB firmware 與 Jazzy 適用成熟 upstream 能否提供「Operator 人工靜止標定、保存及套用零偏補償，且不吞掉合法慢速旋轉」的完整能力？若不能，confirmed gap 與最小責任為何？

## Confirmed requirement / evidence

Operator 已確認現在將人工靜止標定、保存及套用零偏補償，以及靜止／慢速旋轉驗證納入 V1；先完成 native research / decision，再實作。不把本次臨時平均值寫成正式標定值。

實車靜止 135.6 s 輪端 yaw 不變，融合 yaw 改變 −0.050884 rad；新靜止採集 gyro yaw 平均 −0.0003131 rad/s。實際版本 robot_localization 3.8.3；目前 only wheel vx/vy + IMU yaw-rate。只添加 wheel yaw-rate 融合不能充分去偏，實驗只有約 0.2% 改善；只扣本次均值顯著改善，僅因果驗證，非量產標定。

## Research boundary

Native-first，官方文件/source/tests；查核 Jazzy 穩定版本，不把 rolling 等同部署基準。允許參考已授權 IMU reference 的協定／驗證經驗；不沿用舊設計。分析 IMU firmware 是否已自校正、能否明確觸發／讀回／保存，不從晶片 registers 推論 USB firmware 支援。

研究 robot_localization 是否有 gyro bias state／設定；成熟 imu_tools 的 bias estimation／輸出及低速轉動適用性；若最小 manual offline calibration + explicit SI offset 是 gap 補足候選，清楚劃分 raw input、corrected input、frame/units、covariance 與 ownership。

產物：一份 repo research note，區分 CONFIRMED／UNRESOLVED／REQUIRES HARDWARE VALIDATION／REQUIRES CALIBRATION；不寫 runtime、不操作馬達、不直接宣稱任一新方案已量產驗證。
