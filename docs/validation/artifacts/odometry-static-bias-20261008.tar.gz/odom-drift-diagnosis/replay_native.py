import json,math,os,signal,subprocess,time
from pathlib import Path
import yaml
import rclpy
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from ament_index_python.packages import get_package_share_directory
from rclpy.qos import qos_profile_sensor_data

os.environ['ROS_DOMAIN_ID']='151'
root=Path('/tmp/odom-drift-replay');root.mkdir(exist_ok=True)
rows=json.loads(Path('/tmp/odom-drift-live/samples.json').read_text())
# Exclude startup; replay actual stationary samples at the original mean rate.
rows=rows[-3000:]
bias=sum(r['gyro'][2] for r in rows)/len(rows)
base=yaml.safe_load((Path(get_package_share_directory('mobile_base_odometry'))/'config/ekf.yaml').read_text())
model=(Path(get_package_share_directory('mobile_base_description'))/'urdf/mobile_base.urdf').read_text()
(root/'model.yaml').write_text(yaml.safe_dump({'robot_state_publisher':{'ros__parameters':{'robot_description':model}}}))
reports=[]
for variant in ['current','wheel_yaw_rate','subtract_measured_bias']:
 config=yaml.safe_load(yaml.safe_dump(base))
 if variant=='wheel_yaw_rate':config['ekf_filter_node']['ros__parameters']['odom0_config'][11]=True
 profile=root/(variant+'.yaml');profile.write_text(yaml.safe_dump(config))
 context=rclpy.context.Context();rclpy.init(context=context,domain_id=151)
 node=rclpy.create_node('stationary_replay',context=context)
 executor=rclpy.executors.SingleThreadedExecutor(context=context);executor.add_node(node)
 wheel=node.create_publisher(Odometry,'/base_controller/odom',10)
 gyro=node.create_publisher(Imu,'/imu/data_raw',10)
 samples=[];node.create_subscription(Odometry,'/odometry/filtered',lambda m:samples.append(m),10)
 ps=[];logs=[]
 try:
  for name,args in [('model',['ros2','run','robot_state_publisher','robot_state_publisher','--ros-args','--params-file',str(root/'model.yaml')]),('ekf',['ros2','launch','mobile_base_odometry','odometry.launch.py','filter_config:='+str(profile)])]:
   log=(root/(variant+'-'+name+'.log')).open('w');logs.append(log)
   ps.append(subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True))
  start=time.monotonic();index=0
  while time.monotonic()-start<12:
   assert all(p.poll() is None for p in ps)
   stamp=node.get_clock().now().to_msg()
   odom=Odometry();odom.header.stamp=stamp;odom.header.frame_id='odom';odom.child_frame_id='base_footprint'
   for i,v in zip([0,7,14,21,28,35],[.001,.001,.001,.001,.001,.01]):odom.twist.covariance[i]=v
   wheel.publish(odom)
   # Replay captured angular data through real model and native EKF.
   for _ in range(8):
    row=rows[index%len(rows)];index+=1
    imu=Imu();imu.header.stamp=node.get_clock().now().to_msg();imu.header.frame_id=row['frame'];imu.orientation_covariance[0]=-1.
    imu.angular_velocity.x,imu.angular_velocity.y,imu.angular_velocity.z=row['gyro']
    if variant=='subtract_measured_bias':imu.angular_velocity.z-=bias
    imu.angular_velocity_covariance=row['covariance'];gyro.publish(imu)
    executor.spin_once(timeout_sec=.005)
  assert len(samples)>100,len(samples)
  chosen=samples[len(samples)//3:]
  def yaw(m):return 2*math.atan2(m.pose.pose.orientation.z,m.pose.pose.orientation.w)
  duration=(chosen[-1].header.stamp.sec+chosen[-1].header.stamp.nanosec/1e9)-(chosen[0].header.stamp.sec+chosen[0].header.stamp.nanosec/1e9)
  change=math.atan2(math.sin(yaw(chosen[-1])-yaw(chosen[0])),math.cos(yaw(chosen[-1])-yaw(chosen[0])))
  reports.append({'variant':variant,'seconds':duration,'yaw_delta_rad':change,'yaw_slope_rad_s':change/duration,'input_bias_rad_s':bias,'samples':len(samples)})
 finally:
  for p in reversed(ps):
   p.send_signal(signal.SIGINT)
   try:p.wait(timeout=8)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  executor.shutdown();node.destroy_node();rclpy.shutdown(context=context)
  for log in logs:log.close()
 print(json.dumps(reports[-1]),flush=True)
(root/'results.json').write_text(json.dumps(reports,indent=2))
assert abs(reports[0]['yaw_slope_rad_s'])>1e-4, 'must reproduce actual stationary drift'
assert abs(reports[2]['yaw_slope_rad_s'])<abs(reports[0]['yaw_slope_rad_s'])*.15, 'offset-only change must suppress drift'
print('CONFIRMED: measured gyro offset explains stationary yaw drift; diagnostic compensation not deployment calibration',flush=True)
