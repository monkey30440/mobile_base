## Resolution — Operator confirmed both frontier decisions

2026-10-08 Operator 對責任／資料契約與驗證範圍各回覆「採用」。

- Operator 負責確保實體靜止，離線標定未套 host offset 的三軸 SI rate，審查並保存零偏。
- Perception 擁有輸入轉換與固定零偏補償；保留原始 `/imu/data_raw`，提供固定補償後 `/imu/data` 給原生 EKF。不新增 orientation filter、runtime adaptive bias、deadband 或低速歸零。
- 零偏在相同 IMU frame／rad/s 下減除；安裝旋轉仍由 model TF 單一負責。不將診斷臨時均值直接寫死，也不把 bias 當成 noise variance。
- 缺少有效補償設定時 raw 仍供標定／排查，但 Mapping／Navigation 不得 fallback 到未補償輸入或假定零 bias；有節點不等於功能 ready。原生 EKF 保留融合與唯一 odom TF ownership。
- 用獨立於標定的資料量測較長靜止漂移，驗證正／負慢速旋轉方向尺度、重新啟動重用。記錄數值與有效條件；跨溫度／長期精度尚未驗證。裝置／firmware／安裝或殘差改變後人工重新標定。

Native capability／confirmed gap 詳見已結案的 [IMU 零偏標定與慢速旋轉的原生能力](https://github.com/monkey30440/mobile_base/issues/48)。最小補足為 offline 工具＋既有必要 IMU adapter 的固定 SI 補償，沒有新的 fusion engine／TF owner。

具體檔名、CLI、初始採集長度與測試數值留 implementation，需按 evidence 記錄，不捏造量產漂移／精度保證。此 resolution 是 architecture contract，並非已完成 implementation／hardware acceptance。
