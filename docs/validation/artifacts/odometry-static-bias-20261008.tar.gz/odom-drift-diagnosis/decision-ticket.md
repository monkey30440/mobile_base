## Question

在 Operator 已確認「人工靜止標定、保存／套用 gyro bias、驗證靜止與慢速旋轉」納入 V1 的前提下，如何劃分標定工具、Perception adapter 與原生 EKF 的最小責任？raw／corrected 資料、缺少有效標定時的使用語意、固定補償與後續驗收如何定義？

## Prerequisite

[IMU 零偏標定與慢速旋轉的原生能力](https://github.com/monkey30440/mobile_base/issues/48)，已完成 primary-source 研究；研究筆記 docs/research/imu-bias-native-20261008.md。

## Confirmed requirement

2026-10-08 Operator 採用「納入 V1，現在處理」。先完成 native research / decision、限定 spec reconciliation，再按既定流程實作，不把診斷均值直接寫死。不重做其他 V1 功能。

## Proposed frontier for human decision

1. Operator 對實體靜止負責；offline 標定只讀 raw SI 三軸角速度並產出可審查 bias／樣本時間與 dispersion。Operator 審查保存，Perception adapter 在相同 IMU frame 固定減法；EKF 僅融合，不做自動 bias estimator／deadband／低速歸零。
2. 保留原始 /imu/data_raw；明確 corrected source 提供 EKF，來源缺有效補償設定不得自動以 raw 或零 bias 冒充已標定。raw 仍供標定／排查；Mapping／Navigation 需有效 corrected input 才可使用。
3. 保存標定後，用未參與估計的資料做较長靜止觀察、正／負慢速旋轉与重新啟動重用驗證；報告 drift 數值與有效條件，不宣稱跨溫度或長期精度已標定。若平台／firmware／安裝或殘差改變，由 Operator 重新標定。

這些是建議，尚未真人確認，不能當成已採用設計。具體檔名、CLI、window 初始值与數值容差待 evidence 與 implementation；產品若要求絕對漂移上限需明確確認，不以此短期診斷捏造。
