import importlib.util,subprocess,signal,time,json
from pathlib import Path
import rclpy,yaml
from tf2_ros import Buffer,TransformListener
from sensor_msgs.msg import JointState
spec=importlib.util.spec_from_file_location('workflow','/workspace/src/mobile_base_m1/test/test_workflow.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
peer=module.Peer(require_enable=True);root=Path('/evidence');profile=yaml.safe_load(Path('/workspace/src/mobile_base_m1/config/rwf.commissioning.yaml').read_text());profile['hardware']['serial_port']=peer.path
(root/'model-peer.yaml').write_text(yaml.safe_dump(profile));log=open(root/'model-chain-native.log','w');p=None
rclpy.init();node=rclpy.create_node('actual_model_chain_observer');buffer=Buffer();listener=TransformListener(buffer,node);joints=[];node.create_subscription(JointState,'/joint_states',joints.append,10)
try:
 p=subprocess.Popen(['ros2','launch','mobile_base_m1','m1.launch.py','hardware_config:=/evidence/model-peer.yaml','model_file:=/evidence/model.urdf'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 end=time.monotonic()+8
 while time.monotonic()<end:
  rclpy.spin_once(node,timeout_sec=.03)
  if p.poll() is not None:raise RuntimeError('native launch exited')
 result={'hardware':'PTY only; no devices','joint_names':list(joints[-1].name),'position':list(joints[-1].position)}
 for parent,child in [('base_footprint','base_imu_link'),('base_footprint','driving_wheel_link_L'),('base_footprint','driving_wheel_link_R'),('driving_suspension_link_L','driving_wheel_link_L'),('driving_suspension_link_R','driving_wheel_link_R')]:result[parent+' -> '+child]=buffer.can_transform(parent,child,rclpy.time.Time())
 (root/'model-chain-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
finally:
 if p is not None and p.poll() is None:subprocess.os.killpg(p.pid,signal.SIGINT);p.wait(timeout=8)
 node.destroy_node();rclpy.shutdown();peer.close();log.close()
