import json,struct,time
from datetime import datetime,timezone
import serial

def crc(data):
 value=0xffff
 for byte in data:
  value^=byte
  for _ in range(8):value=(value>>1)^(0xa001 if value&1 else 0)
 return value
records=[]
with serial.Serial('/dev/fihRobotBaseMotor',230400,bytesize=8,parity='N',stopbits=1,timeout=.25,write_timeout=.25,exclusive=True) as bus:
 def read(index,n):
  time.sleep(.002)
  body=struct.pack('>BBHH',0x65,3,0xf003+(index<<8),n)
  request=body+struct.pack('<H',crc(body));bus.write(request);reply=bus.read(5+2*n)
  records.append({'time_utc':datetime.now(timezone.utc).isoformat(),'request_hex':request.hex(),'reply_hex':reply.hex()})
  if len(reply)!=5+2*n or reply[:3]!=bytes((0x65,3,2*n)) or crc(reply[:-2])!=int.from_bytes(reply[-2:],'little'):raise RuntimeError('invalid finalframe')
  words=struct.unpack('>'+str(n)+'H',reply[3:-2]);stride=n//2
  for slot in range(2):
   i=(slot+1)*stride-1
   if words[i]!=crc(reply[:3+2*i]):raise RuntimeError('invalid perdrivecheck')
  return words
 words=read(0,8);targets=read(12,4);positions=read(5,6)
 states=[{'id':i+1,'status':words[i*4],'alarm':words[i*4+1],'rpm':struct.unpack('>h',struct.pack('>H',words[i*4+2]))[0]} for i in range(2)]
 report={'raw_position_words':list(positions),'signed32_interpretation_candidate':[struct.unpack('>i',struct.pack('>HH',positions[0],positions[1]))[0],struct.unpack('>i',struct.pack('>HH',positions[3],positions[4]))[0]],'position_scale':'UNRESOLVED; not converted to radians','state':states,'targets':[targets[0],targets[2]],'transactions':records}
 print(json.dumps(report,indent=2))
 if any(d['status']!=6 or d['alarm']!=0 or d['rpm']!=0 for d in states) or targets[0]!=0 or targets[2]!=0:raise SystemExit(1)
