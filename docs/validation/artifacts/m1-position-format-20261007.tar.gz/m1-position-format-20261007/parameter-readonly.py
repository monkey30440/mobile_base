import json,struct,time,serial
from datetime import datetime,timezone
from pathlib import Path
from importlib.util import spec_from_file_location,module_from_spec
# Standard FC03 read only. Addresses are M1 manual communication parameter table.
def crc(data):
 value=0xffff
 for b in data:
  value^=b
  for _ in range(8):value=(value>>1)^(0xa001 if value&1 else 0)
 return value
records=[]
with serial.Serial('/dev/fihRobotBaseMotor',230400,parity='N',timeout=.25,write_timeout=.25,exclusive=True) as bus:
 for slave in (1,2):
  for name,address in [('01-06',0x0105),('02-14',0x020d),('current-position-index',0x4615),('current-position-pulse',0x4616)]:
   time.sleep(.002);body=struct.pack('>BBHH',slave,3,address,1);request=body+struct.pack('<H',crc(body));bus.reset_input_buffer();bus.write(request);reply=bus.read(7)
   row={'time_utc':datetime.now(timezone.utc).isoformat(),'slave':slave,'parameter':name,'address':address,'request_hex':request.hex(),'reply_hex':reply.hex()}
   if len(reply)==7 and reply[:3]==bytes((slave,3,2)) and crc(reply[:-2])==int.from_bytes(reply[-2:],'little'):row['value']=int.from_bytes(reply[3:5],'big')
   else:row['result']='UNRESOLVED: no valid standard FC03 response'
   records.append(row)
print(json.dumps(records,indent=2))
