import json, math, signal, subprocess, time
from pathlib import Path
from datetime import datetime,timezone
import rclpy
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
p=Path('/capture'); rclpy.init(); node=rclpy.create_node('lidar_tf_preflight_observer')
counts={};latest={};received={}
def scan(source,msg):
 key=source+':'+msg.header.frame_id; counts[key]=counts.get(key,0)+1; received[key]=time.time()
 latest[key]=msg
for source in ('fl','br'):
 node.create_subscription(LaserScan,'/lidar/'+source+'/scan',lambda msg,s=source:scan(s,msg),qos_profile_sensor_data)
log=open(p/'drivers.log','w')
args=['ros2','launch','mobile_base_lidar','dual_picoscan.launch.py','fl_hostname:=192.168.0.52','br_hostname:=192.168.0.53','udp_receiver_ip:=192.168.0.51','fl_udp_port:=2115','br_udp_port:=2117','fl_check_udp_port:=2116','br_check_udp_port:=2118','ros_qos:=4','set_echo_filter:=False','tick_to_timestamp_mode:=1']
started=datetime.now(timezone.utc).isoformat(); proc=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
try:
 deadline=time.monotonic()+25
 while time.monotonic()<deadline:
  rclpy.spin_once(node,timeout_sec=.1)
  if counts and min(counts.values())>=125 and len(counts)>=4:break
 result={'start_utc':started,'counts':counts,'frames':{},'motor_devices_mapped':False,'echo_filter_changed':False}
 snapshots={}
 for key,msg in latest.items():
  stamp=msg.header.stamp.sec+msg.header.stamp.nanosec*1e-9
  result['frames'][key]={'angle_min':msg.angle_min,'angle_max':msg.angle_max,'angle_increment':msg.angle_increment,'ranges_count':len(msg.ranges),'finite_ranges':sum(math.isfinite(r) for r in msg.ranges),'arrival_stamp_age_s':received[key]-stamp,'range_min':msg.range_min,'range_max':msg.range_max}
  snapshots[key]={'stamp':stamp,'angle_min':msg.angle_min,'angle_increment':msg.angle_increment,'ranges':[float(r) if math.isfinite(r) else None for r in msg.ranges]}
 p.joinpath('scan-snapshots.json').write_text(json.dumps(snapshots,indent=2)+'\n')
 p.joinpath('summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
finally:
 osig=signal.SIGINT
 if proc.poll() is None:
  import os;os.killpg(proc.pid,osig)
  try:proc.wait(timeout=12)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 print('native launch shutdown return',proc.returncode,flush=True)
 node.destroy_node();rclpy.shutdown();log.close()
