import subprocess,signal,time,pathlib,json,sys,os
root=pathlib.Path('/tmp/native-source-results')/sys.argv[1];root.mkdir(parents=True,exist_ok=True)
results=[]
for i in range(3):
 with (root/f'{i}.log').open('w') as log:
  p=subprocess.Popen(['/tmp/sick-build/sick_generic_caller','/tmp/sick-upstream/launch/sick_picoscan.launch','hostname:=192.168.0.52','udp_receiver_ip:=192.168.0.51','udp_port:=2115','check_udp_receiver_port:=2116','imu_enable:=0','custom_pointclouds:=','host_set_FREchoFilter:=1','host_FREchoFilter:=2','tick_to_timestamp_mode:=1'],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'ROS_DOMAIN_ID':'197'})
  time.sleep(7)
  running=p.poll() is None
  if running:p.send_signal(signal.SIGINT)
  try:p.wait(timeout=12)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 results.append({'cycle':i,'started':running,'exit':p.returncode});print(results[-1],flush=True)
 time.sleep(1)
(root/'results.json').write_text(json.dumps(results,indent=2))
if not all(x['started'] and x['exit']==0 for x in results):sys.exit(1)
