#include <rclcpp/rclcpp.hpp>
#include <diagnostic_updater/diagnostic_updater.hpp>
#include <memory>
#include <string>
static std::shared_ptr<diagnostic_updater::Updater> held;
int main(int argc,char** argv){
 rclcpp::init(argc,argv);
 auto node=std::make_shared<rclcpp::Node>("lifecycle_probe");
 held=std::make_shared<diagnostic_updater::Updater>(node);
 if(argc>1 && std::string(argv[1])=="early") held.reset();
 rclcpp::shutdown();
 if(argc>1 && std::string(argv[1])=="after") held.reset();
 node.reset();
 return 0;
}
