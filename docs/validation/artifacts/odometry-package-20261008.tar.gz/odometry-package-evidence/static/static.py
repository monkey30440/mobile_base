import json,math,os,signal,subprocess,time
from pathlib import Path
import rclpy
from diagnostic_msgs.msg import DiagnosticArray
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu,JointState
from tf2_msgs.msg import TFMessage
from tf2_ros import Buffer,TransformListener
from rosidl_runtime_py.convert import message_to_ordereddict
from rcl_interfaces.srv import GetParameters
root=Path('/tmp/odometry-static');events=[];latest={};when={};statuses={};status_at={};tf_events=[];processes=[];logs=[];outcome='FAILED';summary={}
rclpy.init();node=rclpy.create_node('real_static_estimation_observer');buffer=Buffer();listener=TransformListener(buffer,node)
def capture(key,msg):
 now=time.monotonic();latest[key]=msg;when[key]=now
 if key=='diagnostics':
  for s in msg.status:statuses[s.name]=s;status_at[s.name]=now
 events.append({'mono':now,'topic':key,'message':message_to_ordereddict(msg)})
for topic,kind,key in [('/imu/data_raw',Imu,'imu'),('/base_controller/odom',Odometry,'wheel'),('/odometry/filtered',Odometry,'filtered'),('/joint_states',JointState,'joints'),('/diagnostics',DiagnosticArray,'diagnostics')]:
 def make_callback(k):
  def callback(msg):capture(k,msg)
  return callback
 node.create_subscription(kind,topic,make_callback(key),50)
def tf_capture(msg,info):
 now=time.monotonic()
 for t in msg.transforms:
  tf_events.append({'mono':now,'message_info_keys':list(info.keys()),'parent':t.header.frame_id,'child':t.child_frame_id,'stamp_ns':t.header.stamp.sec*1000000000+t.header.stamp.nanosec,'message':message_to_ordereddict(t)})
node.create_subscription(TFMessage,'/tf',tf_capture,100)
def alive(skip=None):
 if any(p is not skip and p.poll() is not None for p in processes):raise RuntimeError('native process exited')
def wait(condition,seconds):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  rclpy.spin_once(node,timeout_sec=.02);alive()
  if condition():return
 raise RuntimeError('bounded observation deadline')
def params(name,names):
 c=node.create_client(GetParameters,name+'/get_parameters')
 if not c.wait_for_service(timeout_sec=5):raise RuntimeError('parameter service unavailable')
 f=c.call_async(GetParameters.Request(names=names));rclpy.spin_until_future_complete(node,f,timeout_sec=5);alive()
 if not f.done() or f.result() is None:raise RuntimeError('parameter query failed')
 result=f.result().values;node.destroy_client(c);return result
def start(name,args):
 log=open(root/(name+'.log'),'w');logs.append(log);p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);processes.append(p);return p
def fresh(key,age=.5):return key in latest and time.monotonic()-when[key]<age
def health():
 for name in ('m1: left_wheel_joint','m1: right_wheel_joint','usb_imu: USB IMU'):
  s=statuses.get(name)
  if s is None or time.monotonic()-status_at[name]>2.5 or s.level not in (0,b'\x00'):return False
 return fresh('joints') and fresh('wheel') and fresh('imu')
def stationary():
 j=latest['joints']
 if len(j.name)!=len(j.velocity):raise RuntimeError('incomplete joint feedback')
 for name in ('left_wheel_joint','right_wheel_joint'):
  if list(j.name).count(name)!=1:raise RuntimeError('missing/duplicate wheel')
  v=j.velocity[list(j.name).index(name)]
  if not math.isfinite(v) or abs(v)>.03:raise RuntimeError('unexpected wheel motion')
try:
 start('description',['ros2','launch','mobile_base_description','description.launch.py'])
 start('m1',['ros2','launch','mobile_base_control','m1.launch.py'])
 start('imu',['ros2','launch','mobile_base_perception','imu.launch.py'])
 wait(lambda:fresh('imu') and fresh('joints'),25);stationary()
 from geometry_msgs.msg import TwistStamped
 zero_source=node.create_publisher(TwistStamped,'/base_controller/cmd_vel',10)
 wait(lambda:zero_source.get_subscription_count()==1,5)
 zero_messages=0
 def initialize_zero():
  global zero_messages
  msg=TwistStamped();msg.header.stamp=node.get_clock().now().to_msg()
  zero_source.publish(msg);zero_messages+=1
  return fresh('wheel')
 wait(initialize_zero,5)
 node.destroy_publisher(zero_source)
 summary['initialization_command']={'type':'TwistStamped','linear_x':0.0,'angular_z':0.0,'messages':zero_messages,'publisher_destroyed':True}
 wait(health,5);stationary()
 p=params('/base_controller',['enable_odom_tf','twist_covariance_diagonal'])
 if p[0].bool_value or list(p[1].double_array_value)!=[.001,.001,.001,.001,.001,.01]:raise RuntimeError('native wheel TF/covariance configuration mismatch')
 imu=latest['imu'];wheel=latest['wheel']
 expected=json.loads((root/'imu-statistics.json').read_text())['observed_gyro_second_moment_about_zero']
 if imu.header.frame_id!='base_imu_link' or imu.orientation_covariance[0]!=-1 or any(imu.angular_velocity_covariance[i]!=v for i,v in zip((0,4,8),expected)):raise RuntimeError('actual IMU covariance/frame mismatch')
 if wheel.header.frame_id!='odom' or wheel.child_frame_id!='base_footprint' or wheel.twist.covariance[0]!=.001 or wheel.twist.covariance[7]!=.001:raise RuntimeError('actual wheel covariance/frame mismatch')
 ekf=start('ekf',['ros2','launch','mobile_base_odometry','local_estimation.launch.py','filter_config:=/workspace/install/mobile_base_odometry/share/mobile_base_odometry/config/ekf.yaml'])
 wait(lambda:fresh('filtered') and buffer.can_transform('odom','base_imu_link',rclpy.time.Time()),20)
 for topic in ('/base_controller/odom','/imu/data_raw'):
  if 'ekf_filter_node' not in {i.node_name for i in node.get_subscriptions_info_by_topic(topic)}:raise RuntimeError('EKF input subscription missing '+topic)
 start_at=time.monotonic();end=start_at+15
 while time.monotonic()<end:
  rclpy.spin_once(node,timeout_sec=.02);alive()
  if not health() or not fresh('filtered'):raise RuntimeError('input/output freshness or source health lost')
  stationary();m=latest['filtered'];q=m.pose.pose.orientation
  values=[m.pose.pose.position.x,m.pose.pose.position.y,q.x,q.y,q.z,q.w,m.twist.twist.linear.x,m.twist.twist.angular.z]+list(m.pose.covariance)+list(m.twist.covariance)
  if not all(math.isfinite(v) for v in values) or abs(sum(v*v for v in (q.x,q.y,q.z,q.w))-1)>.001:raise RuntimeError('invalid filtered output')
  if m.header.frame_id!='odom' or m.child_frame_id!='base_footprint':raise RuntimeError('filtered frame mismatch')
 for child in ('base_link','base_imu_link','base_lidar_link_FL_1','base_lidar_link_BR_1'):
  buffer.lookup_transform('odom',child,rclpy.time.Time())
 pubinfo=node.get_publishers_info_by_topic('/tf')
 edges=[t for t in tf_events if t['mono']>=start_at and t['parent']=='odom' and t['child']=='base_footprint']
 if not edges or len(pubinfo)!=3 or {i.node_name for i in pubinfo}!={'robot_state_publisher','base_controller','ekf_filter_node'}:raise RuntimeError('unexpected native TF endpoint graph')
 import xml.etree.ElementTree as ET
 description=params('/robot_state_publisher',['robot_description'])[0].string_value
 robot=ET.fromstring(description)
 if robot.find("link[@name='odom']") is not None or any(e.attrib.get('link')=='odom' for e in robot.iter()):raise RuntimeError('model contains unexpected odom frame')
 static_pubs=node.get_publishers_info_by_topic('/tf_static')
 if len(static_pubs)!=1 or static_pubs[0].node_name!='robot_state_publisher':raise RuntimeError('model TF ownership mismatch')
 filtered_pubs=node.get_publishers_info_by_topic('/odometry/filtered')
 if len(filtered_pubs)!=1 or filtered_pubs[0].node_name!='ekf_filter_node':raise RuntimeError('filtered output ownership mismatch')
 summary.update({'base_sensor_estimation_chain':'PASS','controller_odom_tf':False,'odom_edge_owner':'ekf_filter_node (native graph and controlled shutdown attribution)', 'tf_endpoints':[{'node':i.node_name,'gid':list(i.endpoint_gid)} for i in pubinfo],'tf_static_owners':['robot_state_publisher'],'observation_seconds':15,'counts':{k:sum(e['topic']==k and e['mono']>=start_at for e in events) for k in ('wheel','imu','filtered')},'last_filtered':message_to_ordereddict(latest['filtered']),'limits':'Commissioning uncertainty only; no accuracy, calibrated covariance or dynamic IMU validation.'})
 ekf.send_signal(signal.SIGINT);deadline=time.monotonic()+8
 while ekf.poll() is None:
  rclpy.spin_once(node,timeout_sec=.02);alive(ekf)
  if not health():raise RuntimeError('source health lost during EKF shutdown')
  stationary()
  if time.monotonic()>deadline:raise RuntimeError('EKF shutdown deadline')
 processes.remove(ekf)
 drain=time.monotonic()+.3
 while time.monotonic()<drain:
  rclpy.spin_once(node,timeout_sec=.02);alive()
  if not health():raise RuntimeError('source health lost during drain')
  stationary()
 stopped=time.monotonic();until=stopped+.5
 while time.monotonic()<until:
  rclpy.spin_once(node,timeout_sec=.02);alive()
  if not health():raise RuntimeError('source health lost during edge stop check')
  stationary()
 if any(t['mono']>=stopped and t['parent']=='odom' and t['child']=='base_footprint' for t in tf_events):raise RuntimeError('odom edge continues after EKF shutdown')
 alive();buffer.lookup_transform('base_footprint','base_imu_link',rclpy.time.Time());summary['odom_edge_ceases_after_ekf_stop']=True
 invalid_model=[t for t in tf_events if not all(math.isfinite(v) for v in list(t['message']['transform']['translation'].values())+list(t['message']['transform']['rotation'].values()))]
 summary['invalid_model_tf_frames']=sorted({t['child'] for t in invalid_model})
 if any(t['child'] not in ('driving_wheel_link_L','driving_wheel_link_R') for t in invalid_model):
  summary['base_sensor_estimation_chain']='FAILED';raise RuntimeError('invalid TF outside known wheel gap')
 observed_wheels={t['child'] for t in tf_events if t['child'] in ('driving_wheel_link_L','driving_wheel_link_R')}
 summary['missing_model_wheel_tf_frames']=sorted({'driving_wheel_link_L','driving_wheel_link_R'}-observed_wheels)
 summary['model_wheel_tf_valid']=not invalid_model and len(observed_wheels)==2
 outcome='PASS' if summary['model_wheel_tf_valid'] else 'PARTIAL'
except Exception as e:summary['failure']=str(e)
finally:
 try:
  d=subprocess.run(['ros2','control','set_hardware_component_state','M1','inactive'],capture_output=True,text=True,timeout=8);summary['deactivate']={'returncode':d.returncode,'output':d.stdout+d.stderr}
  if d.returncode:outcome='FAILED'
 except Exception as e:summary['deactivate_failure']=str(e);outcome='FAILED'
 for p in reversed(processes):
  if p.poll() is None:p.send_signal(signal.SIGINT)
 for p in processes:
  try:p.wait(timeout=8)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();outcome='FAILED'
 summary['outcome']=outcome;(root/'static-summary.json').write_text(json.dumps(summary,indent=2)+'\n');(root/'ros-events.json').write_text(json.dumps({'events':events,'tf':tf_events},indent=2,default=lambda x:list(x) if isinstance(x,bytes) else str(x))+'\n')
 for log in logs:log.close()
 node.destroy_node();rclpy.shutdown()
print(json.dumps(summary,indent=2));raise SystemExit(0 if outcome=='PASS' else 1)
