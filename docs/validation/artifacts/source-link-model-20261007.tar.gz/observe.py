import rclpy,json,time,math,collections
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from rclpy.qos import qos_profile_sensor_data,QoSProfile,DurabilityPolicy
from rclpy.time import Time
from tf2_ros import Buffer,TransformListener
rclpy.init();n=rclpy.create_node('single_echo_model_acceptance');b=Buffer();l=TransformListener(b,n);data=collections.defaultdict(list);descriptions=[]
def cb(t,m):
 data[t].append({'frame':m.header.frame_id,'stamp':m.header.stamp.sec+m.header.stamp.nanosec/1e9,'received':time.time(),'valid':sum(math.isfinite(v)and m.range_min<=v<=m.range_max for v in m.ranges)})
subs=[n.create_subscription(LaserScan,t,lambda m,t=t:cb(t,m),qos_profile_sensor_data)for t in ['/lidar/fl/scan','/lidar/br/scan']]
sub=n.create_subscription(String,'/robot_description',lambda m:descriptions.append(m.data),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
end=time.monotonic()+10
while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.05)
result={'topics':{},'transforms':{},'robot_description_received':bool(descriptions)}
for side in ['fl','br']:
 t='/lidar/'+side+'/scan';ms=data[t];frame='base_lidar_link_'+side.upper()+'_1';assert len(ms)>200,(t,len(ms));assert set(m['frame']for m in ms)=={frame};assert min(m['valid']for m in ms)>1000
 gaps=[c['received']-a['received']for a,c in zip(ms,ms[1:])];rate=(len(ms)-1)/(ms[-1]['received']-ms[0]['received']);assert max(gaps)<.25
 pubs=n.get_publishers_info_by_topic(t);assert len(pubs)==1
 result['topics'][t]={'messages':len(ms),'frames':[frame],'rate_hz':rate,'max_arrival_gap_s':max(gaps),'valid_points_min_max':[min(m['valid']for m in ms),max(m['valid']for m in ms)],'max_stamp_age_s':max(m['received']-m['stamp']for m in ms),'publishers':len(pubs)}
 for f in [frame,'base_lidar_link_'+side.upper(),'base_imu_link']:
  tr=b.lookup_transform('base_footprint',f,Time()).transform
  if f == frame:
   assert abs((1-2*(tr.rotation.x**2+tr.rotation.y**2))+1)<1e-9
  result['transforms'][f]={'xyz':[tr.translation.x,tr.translation.y,tr.translation.z],'quaternion':[tr.rotation.x,tr.rotation.y,tr.rotation.z,tr.rotation.w]}
assert descriptions
assert "base_lidar_cad_link" not in descriptions[-1]
assert len(n.get_publishers_info_by_topic('/tf_static'))==1
assert not b.can_transform('odom','base_footprint',Time())
assert not n.get_publishers_info_by_topic('/lidar/br/view_echo0')
result['tf_static_publishers']=1;result['no_synthetic_odom']=True
open('/tmp/source-link-model-result.json','w').write(json.dumps(result,indent=2));open('/tmp/source-link-published-model.urdf','w').write(descriptions[-1]);print(json.dumps(result,indent=2));n.destroy_node();rclpy.shutdown()
