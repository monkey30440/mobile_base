## Parent

[V1 Specification — Mapping、Localization、路網 Navigation、Diagnostics 與 Bringup](https://github.com/monkey30440/mobile_base/issues/32)

## What to build

Operator 在目標平台以 Teleop 控制差速底座，透過原生 ros2_control/diff_drive_controller 與最小 M1 adapter 取得有效輪端回授、里程及裝置异常。

本 ticket 依新 V1 spec 與 confirmed decisions 執行；忽略舊 spec/map 及未授權 project runtime 設計。每項 custom runtime 必須追溯 confirmed gap。測試優先公開 ROS／Operator workflow seam與既有Docker/package機制；軟體與實體evidence分開，先判斷可重用證據。硬體或target facts缺失需明記，不能猜測或用software替代；本ticket發布不是自動授權實作。

## Acceptance criteria

- [ ] 在已確認 AGX Orin／Ubuntu24.04／Jazzy 平台與既有 container workflow 建立可重現的操作入口，記錄實際相容版本與裝置 target facts；未知 firmware/IDs/scales 不得猜測。
- [ ] USB→RS485／Modbus Multi-drive2.0 命令與有效回授由必要 M1 adapter 映射；原生 controller 擁有差速運動學、輪里程、限制與timeout，不新增重複引擎。
- [ ] 透過公開 command／feedback 介面驗證速度命令、方向／尺度、回授無效或失聯及命令timeout；native updater 回報 drive identity、基本原因與必要context。
- [ ] 提供 Teleop 結束與錯誤排查操作；零速度／timeout 不宣稱 session ended 或物理停止；輪端feedback、實體移動／停車另有適用硬體evidence。

## Blocked by

- [V1 Implementation — 最小開發容器與 build/test workflow](https://github.com/monkey30440/mobile_base/issues/47)

## Confirmed phased verification correction — 2026-10-07

Control 套件名稱保留 mobile_base_control。當前從此套件原有 m1 launch 與公開 command/feedback/diagnostics 入口完成裝置驗收，不先依賴 Bringup；public workflow tests 回到 Control。原測量輪角／fault latch／停用責任與未完成 hardware acceptance 保留。

Authority: [spec32 phased verification](https://github.com/monkey30440/mobile_base/issues/32)。此修訂取代「核心驗收現在一律從 Bringup 啟動」的先前解讀；保留 Perception／Control 套件命名與現有未完成 acceptance/dependencies。

## Confirmed independent component launches — 2026-10-07

Operator manually launches each owning package. Remove Perception sensor_model composition and its Description dependency. Description alone starts native RSP and publishes complete robot_description/model TF. Its optional explicit hardware_config adds the existing M1 ros2_control declaration to the model without opening a device or starting Control. Control starts only native controller_manager/spawners and consumes the Description-published native robot_description topic; it no longer starts RSP or takes model_file. For Control verification use the same explicit hardware profile in both launches, start Description with that profile then Control; geometry-only Description remains supported for passive model/perception verification. No second publisher, fake state, custom topic bridge, product Bringup or automatic motion is introduced. Control activation may Servo ON at zero command and retains existing safety/lifecycle semantics. Model override is explicit model_file on Description for controlled fixtures. No runtime profile switching is supported; mismatch/invalid setup must be corrected by ending/restarting the selected test configuration. Public ROS/component-launch tests and docs must reflect this responsibility split; hardware/calibration acceptance and issue dependencies remain unchanged.
