import subprocess, time, math, json
from pathlib import Path
import rclpy
from rclpy.node import Node
from tf2_ros import Buffer,TransformListener
rclpy.init(); node=Node('model_preflight_observer'); buffer=Buffer(); listener=TransformListener(buffer,node)
log=open('/tmp/model-rsp.log','w')
p=subprocess.Popen(['ros2','run','robot_state_publisher','robot_state_publisher','--ros-args','--params-file','/preflight/rsp.yaml'],stdout=log,stderr=subprocess.STDOUT)
try:
 deadline=time.monotonic()+8
 expected={'base_link':(0,0,.256),'base_imu_link':(.04375,-.008,.24141),'base_lidar_link_FL':(.28771,.26721,.19589),'base_lidar_link_BR':(-.24671,-.26721,.19589)}
 while time.monotonic()<deadline:
  rclpy.spin_once(node,timeout_sec=.05)
  if all(buffer.can_transform('base_footprint',c,rclpy.time.Time()) for c in expected):break
 results={}
 for child,values in expected.items():
  t=buffer.lookup_transform('base_footprint',child,rclpy.time.Time()).transform
  actual=(t.translation.x,t.translation.y,t.translation.z)
  assert all(math.isclose(a,b,abs_tol=1e-8) for a,b in zip(actual,values)),(child,actual)
  assert abs(t.rotation.x)+abs(t.rotation.y)+abs(t.rotation.z)<1e-8 and abs(t.rotation.w-1)<1e-8
  results[child]=actual
 owners=[i.node_name for i in node.get_publishers_info_by_topic('/tf_static')]
 assert owners==['robot_state_publisher'],owners
 assert not buffer.can_transform('odom','base_footprint',rclpy.time.Time())
 result={'native_static_tf_pass':True,'static_owners':owners,'transforms_from_base_footprint':results,'odom_absent':True,'hardware_connected_to_container':False,'lidar_scan_children_not_yet_defined':True}
 print(json.dumps(result,indent=2));Path('/preflight/result.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
 p.terminate()
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();p.wait()
 node.destroy_node();rclpy.shutdown();log.close()
