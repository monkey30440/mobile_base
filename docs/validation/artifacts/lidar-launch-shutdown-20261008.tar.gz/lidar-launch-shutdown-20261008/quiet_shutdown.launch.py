from launch import LaunchDescription
from launch.actions import ExecuteProcess

def generate_launch_description():
    code='import time; [print("startup diagnostic "+str(i)+" x"*100,flush=True) for i in range(1000)]; print("READY",flush=True); time.sleep(60)'
    return LaunchDescription([ExecuteProcess(cmd=['python3','-u','-c',code],output='screen'),ExecuteProcess(cmd=['python3','-u','-c',code],output='screen')])
