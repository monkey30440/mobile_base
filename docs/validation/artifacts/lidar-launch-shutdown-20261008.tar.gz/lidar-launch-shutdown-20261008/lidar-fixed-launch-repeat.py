from pathlib import Path
import subprocess,time
out=Path('/tmp/lidar-shutdown-repeat');out.mkdir(exist_ok=True)
for attempt in range(200):
 log=out/f'attempt-{attempt:02d}.log'
 with log.open('w') as stream:
  result=subprocess.run(['python3','-m','pytest','src/mobile_base_perception/test/test_operator_launch.py::test_native_children_exit_cleanly_on_sigint','-q','-p','no:cacheprovider','--basetemp',str(out/f'pytest-{attempt:02d}')],stdout=stream,stderr=subprocess.STDOUT,timeout=50)
 print({'attempt':attempt,'exit':result.returncode},flush=True)
 if result.returncode:
  print(log.read_text()[-3000:],flush=True);raise SystemExit(1)
print('600 native dual-launch shutdown cases passed',flush=True)
