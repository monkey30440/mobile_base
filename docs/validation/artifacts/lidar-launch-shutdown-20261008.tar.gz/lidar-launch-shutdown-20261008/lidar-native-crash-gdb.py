from pathlib import Path
import os,signal,subprocess,time,json,re,shlex
out=Path('/tmp/lidar-native-crash-gdb');out.mkdir(exist_ok=True)
exe='/opt/mobile_base/sick_scan_xd/sick_scan_xd/lib/sick_scan_xd/sick_generic_caller'
xml='/opt/mobile_base/sick_scan_xd/sick_scan_xd/share/sick_scan_xd/launch/sick_picoscan.launch'
for cycle in range(200):
 env={**os.environ,'ROS_DOMAIN_ID':str(100+os.getpid()%80)}
 processes=[]
 try:
  for side,host,port,check in [('fl','127.0.0.2',32115,32117),('br','127.0.0.3',32116,32118)]:
   logpath=out/f'{cycle:03}-{side}.log';f=logpath.open('w')
   args=[exe,xml,f'hostname:={host}','udp_receiver_ip:=127.0.0.1',f'udp_port:={port}',f'check_udp_receiver_port:={check}',f'publish_frame_id:=base_lidar_link_{side.upper()}',f'publish_laserscan_fullframe_topic:=/lidar/{side}/scan',f'publish_laserscan_segment_topic:=/lidar/{side}/scan_segment','tf_publish_rate:=0.0','custom_pointclouds:=','host_FREchoFilter:=2','ros_qos:=4','tick_to_timestamp_mode:=1','laserscan_range_min:=0.0','laserscan_range_max:=0.0','listen_only_mode:=1','host_set_FREchoFilter:=1','imu_enable:=0','--ros-args','-r',f'__node:=picoscan_{side}','-r',f'__ns:=/lidar/{side}']
   p=subprocess.Popen(['gdb','--batch','--return-child-result','-ex','handle SIGINT nostop noprint pass','-ex','run','-ex','thread apply all bt','--args',*args],stdout=f,stderr=subprocess.STDOUT,env=env,start_new_session=True)
   processes.append((side,p,logpath,f))
  deadline=time.monotonic()+15
  while not all(f'"/lidar/{s}/scan"' in l.read_text() for s,p,l,f in processes):
   assert time.monotonic()<deadline,'startup timeout'
   assert all(p.poll() is None for s,p,l,f in processes),'early gdb exit'
   time.sleep(.005)
  time.sleep([0,.001,.01,.05,.1,.2][cycle%6])
  inferiors=[]
  for s,p,l,f in processes:
   children=subprocess.check_output(['ps','-o','pid=','--ppid',str(p.pid)],text=True).split()
   assert len(children)==1,children
   native=int(children[0]);command=Path(f'/proc/{native}/cmdline').read_bytes()
   print('TARGET',s,p.pid,native,command[:100],flush=True)
   assert b'sick_generic_caller' in command,command
   inferiors.append(native)
  for native in inferiors:os.kill(native,signal.SIGINT)
  for s,p,l,f in processes:
   p.wait(timeout=8);f.close()
  if any('SIGSEGV' in l.read_text() or p.returncode!=0 for s,p,l,f in processes):
   print('FAIL',cycle,[(s,p.returncode,str(l)) for s,p,l,f in processes],flush=True)
   raise SystemExit(1)
  print('PASS',cycle,flush=True)
 finally:
  for s,p,l,f in processes:
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGKILL);p.wait()
   f.close()
