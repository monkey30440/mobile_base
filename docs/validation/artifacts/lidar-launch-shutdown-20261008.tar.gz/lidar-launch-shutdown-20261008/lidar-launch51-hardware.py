import json, math, os, re, signal, subprocess, time
from pathlib import Path
import rclpy
from sensor_msgs.msg import LaserScan
from rclpy.qos import qos_profile_sensor_data

out=Path('/tmp/lidar-launch51-hardware');out.mkdir(exist_ok=True)
os.environ['ROS_DOMAIN_ID']='94'
rclpy.init()
node=rclpy.create_node('launch51_scan_verification')
data={}
subs=[]
def receive(side,msg):
 d=data[side]; now=time.monotonic(); stamp=msg.header.stamp.sec+msg.header.stamp.nanosec*1e-9
 if d['last'] is not None:d['max_gap']=max(d['max_gap'],now-d['last'])
 if d['stamp'] is not None and stamp<=d['stamp']:d['nonmonotonic']+=1
 d['count']+=1;d['last']=now;d['stamp']=stamp
 d['frames'].add(msg.header.frame_id)
 if not any(math.isfinite(x) and msg.range_min<=x<=msg.range_max for x in msg.ranges):d['empty']+=1
for side in ('fl','br'):
 subs.append(node.create_subscription(LaserScan,f'/lidar/{side}/scan',lambda m,s=side:receive(s,m),qos_profile_sensor_data))
results=[]
try:
 for cycle in range(3):
  data={s:dict(count=0,last=None,stamp=None,max_gap=0.,nonmonotonic=0,empty=0,frames=set()) for s in ('fl','br')}
  logpath=out/f'cycle-{cycle}.log'
  with logpath.open('w') as log:
   p=subprocess.Popen(['ros2','launch','mobile_base_perception','dual_picoscan.launch.py'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:
    deadline=time.monotonic()+40
    while min(d['count'] for d in data.values())<20:
     assert p.poll() is None,'driver exited during startup'
     assert time.monotonic()<deadline,'scan startup timeout'
     rclpy.spin_once(node,timeout_sec=.1)
    baseline={s:d['count'] for s,d in data.items()}
    begin=time.monotonic();deadline=begin+30
    while time.monotonic()<deadline:
     assert p.poll() is None,'driver exited during capture'
     rclpy.spin_once(node,timeout_sec=.05)
    duration=time.monotonic()-begin
    result={'cycle':cycle,'duration':duration,'sources':{s:{**d,'frames':sorted(d['frames']),'rate':(d['count']-baseline[s])/duration} for s,d in data.items()}}
   finally:
    stop_begin=time.monotonic()
    if p.poll() is None:p.send_signal(signal.SIGINT)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:
     os.killpg(p.pid,signal.SIGKILL);p.wait();raise AssertionError('hardware shutdown timed out')
  text=logpath.read_text()
  assert p.returncode==0,text[-2000:]
  assert 'process has died' not in text,text[-2000:]
  assert len(re.findall(r'\[picoscan_(?:fl|br)-\d+\]: process has finished cleanly',text))==2,text[-2000:]
  result['shutdown_seconds']=time.monotonic()-stop_begin
  for side,d in result['sources'].items():
   assert d['frames']==[f'base_lidar_link_{side.upper()}_1'],d
   assert d['empty']==0 and d['nonmonotonic']==0 and d['rate']>20,d
  results.append(result);(out/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(result),flush=True)
  time.sleep(1)
finally:
 node.destroy_node();rclpy.shutdown()
