import subprocess,os,time,signal
from pathlib import Path
out=Path('/tmp/quiet-launch-loop');out.mkdir(exist_ok=True)
for i in range(100):
 with (out/f'{i}.log').open('w') as f:
  p=subprocess.Popen(['ros2','launch','-n','/tmp/quiet_shutdown.launch.py'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  while 'READY' not in (out/f'{i}.log').read_text():
   if p.poll() is not None:raise RuntimeError('startup failed')
   time.sleep(.001)
  p.send_signal(signal.SIGINT)
  try:p.wait(timeout=2)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);p.wait();print('TIMEOUT',i,flush=True);raise SystemExit(1)
 print(i,p.returncode,flush=True)
