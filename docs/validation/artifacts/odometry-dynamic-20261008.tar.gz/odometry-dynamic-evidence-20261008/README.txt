#38 dynamic validation on baseline bb265bf, no product source/config changes.
AGX Thor/Jazzy/Fast DDS, image566d8ff74d6b, actual installed independent Description/Control/Perception IMU/Odometry entrypoints, domain197.
Raised: native keyboard0.03m/s forward/reverse5s command windows, stop3s between; operator confirmed directions and stops.
Ground: native keyboard0.10rad/s left/right1.75s command windows, stop3s between; operator visually confirmed directions/approx10deg and stops. Zero warmup2s precedes rotation; no automatic motion before readiness gate release.
Observations counters are repeated observer checks, not independent topic messages. Raw events support independent message statistics. Ground stopped_mono for left includes3s intermediate hold; seconds1.75 is commanded window, not all-inclusive observation duration.
static-summary.last_filtered/counts/limits describe15s pre-motion stationary phase; dynamic result fields and dynamic_scope describe later moving phase. Inherited static limits no-dynamic-validation is not an overall statement about ground motion. Operator-observation.json captures actual later replies; no precision calibration claim.
Independent final FC03 readbacks: bothstate6/alarm0/currentRPM0/targetRPM0; all hardware worker processes stopped.
Reuse unmodified native/software/model/sensor evidence from earlier tickets; calibration/covariance/IMUbias/displacement accuracy/passive caster state not accepted by these trials.
