import serial, time, struct, statistics, json, math
from pathlib import Path
from datetime import datetime, timezone
p=Path('/tmp/mobile-base-imu-20261007')
started=datetime.now(timezone.utc).isoformat()
raw=bytearray()
with serial.Serial('/dev/fihRobotBaseIMU',115200,timeout=.05,exclusive=True) as s:
 t=time.monotonic()
 while time.monotonic()-t<5:
  raw.extend(s.read(4096))
 duration=time.monotonic()-t
p.joinpath('capture.bin').write_bytes(raw)
buf=bytes(raw); samples=[]; bad=0
while True:
 i=buf.find(b'\xaa\x55')
 if i<0 or len(buf)-i<59: break
 buf=buf[i:]; packet=buf[:59]
 checksum=0
 for b in packet[:-1]: checksum^=b
 if checksum!=packet[-1]: bad+=1; buf=buf[1:]; continue
 v=struct.unpack('<14f',packet[2:58])
 if all(math.isfinite(x) for x in v): samples.append(v)
 else: bad+=1
 buf=buf[59:]
result={'start_utc':started,'port':'/dev/fihRobotBaseIMU','baud':115200,'duration_s':duration,'raw_bytes':len(raw),'valid_packets':len(samples),'invalid_candidates':bad,'received_packets_per_s':len(samples)/duration,'configuration':'read only; no serial payload commands; scale/axes validation and calibration not claimed'}
if samples:
 result['accel_wire_mean']=[statistics.mean(v[i] for v in samples) for i in range(3)]
 result['gyro_wire_mean']=[statistics.mean(v[i] for v in samples) for i in range(5,8)]
 result['accel_wire_std']=[statistics.stdev(v[i] for v in samples) for i in range(3)] if len(samples)>1 else None
p.joinpath('summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
