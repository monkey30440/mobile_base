import json,math,os,signal,subprocess,time
from pathlib import Path
import rclpy
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState
from diagnostic_msgs.msg import DiagnosticArray
from geometry_msgs.msg import TwistStamped
from std_msgs.msg import String
from rclpy.qos import QoSProfile, DurabilityPolicy
import xml.etree.ElementTree as ET
from rosidl_runtime_py.convert import message_to_ordereddict
root=Path('/evidence');events=[];latest={};received={};statuses={};status_at={};outcome='FAILED'
log=open(root/'m1-native-launch.log','w')
process=subprocess.Popen(['ros2','launch','mobile_base_m1','m1.launch.py','hardware_config:=/evidence/rwf.trial.yaml','model_file:=/evidence/m1-commissioning.urdf'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
rclpy.init();node=rclpy.create_node('m1_commissioning_observer')
def capture(key,msg):
 now=time.monotonic();latest[key]=msg;received[key]=now
 if key=='diagnostics':
  for status in msg.status:statuses[status.name]=status;status_at[status.name]=now
 events.append({'time_monotonic':now,'topic':key,'message':message_to_ordereddict(msg)})
node.create_subscription(Odometry,'/base_controller/odom',lambda m:capture('odom',m),10)
node.create_subscription(JointState,'/joint_states',lambda m:capture('joints',m),10)
node.create_subscription(DiagnosticArray,'/diagnostics',lambda m:capture('diagnostics',m),10)
node.create_subscription(TwistStamped,'/base_controller/cmd_vel_out',lambda m:capture('cmd_vel_out',m),10)
node.create_subscription(String,'/robot_description',lambda m:capture('description',m),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
def spin(seconds):
 end=time.monotonic()+seconds
 while time.monotonic()<end:rclpy.spin_once(node,timeout_sec=min(.02,max(0,end-time.monotonic())))
def health():
 now=time.monotonic()
 if any(now-received.get(k,0)>.5 for k in ('joints','odom')):return False
 names=['m1: left_wheel_joint','m1: right_wheel_joint','controller_manager: Hardware Components Activity','controller_manager: Controller Manager Activity']
 for name in names:
  s=statuses.get(name)
  if s is None or now-status_at[name]>2.5 or s.level not in (0,b'\x00'):return False
  if 'wheel_joint' in name and dict((v.key,v.value) for v in s.values).get('motion_available')!='True':return False
 return True

def wheel_safe():
 msg=latest.get('joints')
 if msg:
  for name,value in zip(msg.name,msg.velocity):
   if name in ('left_wheel_joint','right_wheel_joint') and (not math.isfinite(value) or value<-.03 or value>1.6):raise RuntimeError('unexpected wheel velocity '+name+' '+str(value))
try:
 deadline=time.monotonic()+20
 while time.monotonic()<deadline:
  spin(.05)
  if process.poll() is not None:raise RuntimeError('native launch exited before readiness')
  if node.count_subscribers('/base_controller/cmd_vel')>0 and health():break
 else:raise RuntimeError('native zero readiness timeout; no motion')
 wheel_safe()
 if any(abs(v)>.03 for n,v in zip(latest['joints'].name,latest['joints'].velocity) if n in ('left_wheel_joint','right_wheel_joint')):raise RuntimeError('nonzero initial wheel feedback')
 if 'description' not in latest:raise RuntimeError('public robot_description unavailable')
 hardware=ET.fromstring(latest['description'].data).find('ros2_control/hardware')
 actual={p.attrib['name']:p.text for p in hardware.findall('param')}
 if any(float(actual[k])!=300.0 for k in ('left_max_motor_rpm','right_max_motor_rpm')):raise RuntimeError('actual public hardware caps not300')
 check=subprocess.run(['ros2','param','get','/base_controller','linear.x.max_velocity'],capture_output=True,text=True,timeout=8)
 events.append({'native_max_velocity_check':check.stdout+check.stderr,'returncode':check.returncode,'hardware_caps':{k:actual[k] for k in ('left_max_motor_rpm','right_max_motor_rpm')}})
 if check.returncode or float(check.stdout.strip().split(':')[-1])!=.1:raise RuntimeError('native max velocity is not0.1')
 spin(.1)
 if not health():raise RuntimeError('fresh health lost before READY')
 print('READY_TO_PUBLISH',flush=True)
 deadline=time.monotonic()+180
 while not (root/'finish-m1-observation').exists():
  spin(.05)
  if not health():raise RuntimeError('native health/freshness lost')
  wheel_safe()
  if time.monotonic()>deadline:raise RuntimeError('observation deadline')
 spin(.7)
 if any(abs(v)>.03 for n,v in zip(latest['joints'].name,latest['joints'].velocity) if n in ('left_wheel_joint','right_wheel_joint')):raise RuntimeError('nonzero feedback after publisher stop')
 outcome='NATIVE_OBSERVATION_COMPLETED'
except Exception as error:
 events.append({'failure':str(error)});(root/'m1-observation-abort').write_text(str(error))
finally:
 try:
  result=subprocess.run(['ros2','control','set_hardware_component_state','M1','inactive'],capture_output=True,text=True,timeout=8)
  events.append({'deactivate_returncode':result.returncode,'deactivate_output':result.stdout+result.stderr})
  if result.returncode:outcome='FAILED'
 except Exception as error:events.append({'deactivate_error':str(error)});outcome='FAILED'
 if process.poll() is None:os.killpg(process.pid,signal.SIGINT)
 try:process.wait(timeout=8)
 except subprocess.TimeoutExpired:
  os.killpg(process.pid,signal.SIGTERM);process.wait(timeout=5);outcome='FAILED'
 with open(root/'m1-native-gate.json','w') as stream:json.dump({'outcome':outcome,'observations':events},stream,indent=2,default=lambda v:list(v) if isinstance(v,bytes) else str(v))
 node.destroy_node();rclpy.shutdown();log.close()
print(outcome,flush=True)
raise SystemExit(0 if outcome=='NATIVE_OBSERVATION_COMPLETED' else 1)
