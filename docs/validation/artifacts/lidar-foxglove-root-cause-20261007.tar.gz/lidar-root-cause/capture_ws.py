import socket,base64,os,struct,json,time,math
from rclpy.serialization import deserialize_message
from sensor_msgs.msg import LaserScan
from tf2_msgs.msg import TFMessage
s=socket.create_connection(('127.0.0.1',int(os.environ.get('FOXGLOVE_TEST_PORT','8765'))),timeout=5);f=s.makefile('rb');key=base64.b64encode(os.urandom(16)).decode()
s.sendall(('GET / HTTP/1.1\r\nHost: localhost:8765\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: '+key+'\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Protocol: foxglove.sdk.v1\r\n\r\n').encode())
status=f.readline().decode().strip()
while f.readline()!=b'\r\n':pass
assert '101' in status,status

def exact(n):
 data=f.read(n)
 if len(data)!=n:raise EOFError()
 return data

def send(op,payload):
 mask=os.urandom(4);n=len(payload);header=bytes([128|op])
 header+=bytes([128|n]) if n<126 else bytes([254])+struct.pack('>H',n)
 s.sendall(header+mask+bytes(v^mask[i%4] for i,v in enumerate(payload)))

def receive():
 a,b=exact(2);n=b&127
 if n==126:n=struct.unpack('>H',exact(2))[0]
 elif n==127:n=struct.unpack('>Q',exact(8))[0]
 assert n<2000000
 mask=exact(4) if b&128 else None;data=exact(n)
 if mask:data=bytes(v^mask[i%4] for i,v in enumerate(data))
 return a&15,data
records=[];ids={};counts={};tf=[];advertised=[];deadline=time.monotonic()+8
while time.monotonic()<deadline:
 op,data=receive()
 if op==9:send(10,data);continue
 if op==1:
  msg=json.loads(data)
  if msg.get('op')=='advertise':
   subscriptions=[]
   for channel in msg['channels']:
    topic=channel['topic']
    if topic in ('/lidar/br/scan','/lidar/fl/scan','/tf_static') and topic not in ids:
     ident=len(ids)+1;ids[topic]=ident;subscriptions.append({'id':ident,'channelId':channel['id']})
     advertised.append({k:channel[k] for k in ('topic','encoding','schemaName')})
   if subscriptions:send(1,json.dumps({'op':'subscribe','subscriptions':subscriptions}).encode())
 elif op==2 and data[0]==1:
  ident=struct.unpack_from('<I',data,1)[0]
  if ident in (ids.get('/lidar/br/scan'),ids.get('/lidar/fl/scan')):
   msg=deserialize_message(data[13:],LaserScan);frame=msg.header.frame_id
   records.append({'topic':next(k for k,v in ids.items() if v==ident),'schemaName':'sensor_msgs/msg/LaserScan','receiveNs':time.time_ns(),'stampNs':msg.header.stamp.sec*1000000000+msg.header.stamp.nanosec,'frame':frame,'range_min':msg.range_min,'range_max':msg.range_max,'ranges':[r if math.isfinite(r) else None for r in msg.ranges]});counts[frame]={'messages':counts.get(frame,{}).get('messages',0)+1,'valid_points':sum(math.isfinite(r) and msg.range_min<=r<=msg.range_max for r in msg.ranges),'stamp_age_s':time.time()-msg.header.stamp.sec-msg.header.stamp.nanosec/1e9}
  elif ident==ids.get('/tf_static'):
   msg=deserialize_message(data[13:],TFMessage);tf.extend([(t.header.frame_id,t.child_frame_id) for t in msg.transforms])
 if records and records[-1]['receiveNs']-records[0]['receiveNs']>5_000_000_000:break
send(8,struct.pack('>H',1000));f.close();s.close()
result={'websocket_status':status,'advertised':advertised,'scan_frames':counts,'static_transforms':tf}
open('/tmp/ws-scans.json','w').write(json.dumps(records));print(json.dumps(result,indent=2));assert counts.get('base_lidar_link_BR_1_0',{}).get('valid_points',0)>100,'dense first echo absent at WebSocket boundary'
