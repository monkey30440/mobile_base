import rclpy,time,json,math
from sensor_msgs.msg import LaserScan
from rclpy.qos import qos_profile_sensor_data
rclpy.init();n=rclpy.create_node('lidar_boundary_evidence');records=[]
def cb(topic,m):
 records.append({'topic':topic,'stampNs':m.header.stamp.sec*10**9+m.header.stamp.nanosec,'frame':m.header.frame_id,'range_min':m.range_min,'range_max':m.range_max,'ranges':[r if math.isfinite(r) else None for r in m.ranges]})
subs=[n.create_subscription(LaserScan,t,lambda m,t=t:cb(t,m),qos_profile_sensor_data)for t in ['/lidar/fl/scan','/lidar/br/scan']]
end=time.monotonic()+8
while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
open('/tmp/ros-scans.json','w').write(json.dumps(records));n.destroy_node();rclpy.shutdown()
