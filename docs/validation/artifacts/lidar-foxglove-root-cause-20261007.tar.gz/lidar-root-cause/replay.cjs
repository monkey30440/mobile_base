const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={console,Fp:new Set(),Pa:{decayTime:0},jn:{A:(xs,key)=>Object.groupBy(xs,key)},ae:{C:p=>`${p.topic}::${p.schemaName}::${p.comparisonSlot}`},Ie:{iI:(a,b)=>a.push(...b)},K:{CO:class{constructor(_,renderer){this.renderer=renderer} dispatchMessagesBySchema(messages,handlers){this.filtered=handlers[0].batchFilter(messages)}}}};
let source=fs.readFileSync('/tmp/lidar-root-cause/installed-lasercan-classes.js','utf8');
source=source.slice(source.indexOf('class Oa extends'))+';globalThis.TestLaserScans=Oa';vm.createContext(ctx);vm.runInContext(source,ctx);
const data=JSON.parse(fs.readFileSync(process.argv[2]||'/tmp/lidar-root-cause/ws-scans.json','utf8'));
const policy=Number(process.argv[3]||0),ext=new ctx.TestLaserScans({getTopicTarget:topic=>({settingsPath:topic}),settingsAtPath:()=>({decayTime:policy})});
// Actual installed batchFilter; trace arrival windows stand in for render batches.
const start=data[0].receiveNs,windows=new Map();for(const m of data){const k=Math.floor((m.receiveNs-start)/16666667);if(!windows.has(k))windows.set(k,[]);windows.get(k).push(m)}
const byTopic={};for(const batch of windows.values()){ext.processMessages(batch);for(const m of ext.filtered){const valid=m.ranges.filter(r=>r!==null&&r>=m.range_min&&r<=m.range_max).length;(byTopic[m.topic]??=[]).push({frame:m.frame,valid,time:m.receiveNs})}}
const result={decayTime:policy,topics:{}};for(const [topic,ms] of Object.entries(byTopic)){result.topics[topic]={processed:ms.length,empty:ms.filter(m=>m.valid===0).length,dense:ms.filter(m=>m.valid>1000).length,frames:Object.groupBy(ms,m=>m.frame)};for(const[k,v]of Object.entries(result.topics[topic].frames))result.topics[topic].frames[k]=v.length}
if(policy>0){ // native history allocation retains preceding entries for decay period
 const br=data.filter(m=>m.topic==='/lidar/br/scan');let empty=0,checked=0;for(const m of br){if(m.receiveNs-start<policy*1e9)continue;const history=br.filter(p=>p.receiveNs<=m.receiveNs&&m.receiveNs-p.receiveNs<policy*1e9);checked++;if(!history.some(p=>p.ranges.some(r=>r!==null&&r>=p.range_min&&r<=p.range_max)))empty++}result.history={checked,empty};assert.equal(empty,0)
}
console.log(JSON.stringify(result,null,2));if(policy===0)assert.equal(result.topics['/lidar/br/scan'].empty,0,'BR displayed latest scan becomes empty');
