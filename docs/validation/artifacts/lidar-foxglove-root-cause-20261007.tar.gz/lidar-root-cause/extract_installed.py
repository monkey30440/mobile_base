"""Extract locally installed runtime code for a diagnostic replay; not vendored."""
import json,struct,hashlib
from pathlib import Path
f=open('/opt/Foxglove/resources/app.asar','rb');n=struct.unpack('<4I',f.read(16));header=json.loads(f.read(n[3]));root=8+n[1]
out=Path('/tmp/foxglove-installed/renderer');out.mkdir(parents=True,exist_ok=True)
for name,entry in header['files']['renderer']['files'].items():
 if not name.endswith('.js') or entry.get('unpacked'):continue
 f.seek(root+int(entry['offset']));raw=f.read(entry['size'])
 if b'class MC extends' not in raw or b'foxglove.LaserScans' not in raw:continue
 (out/name).write_bytes(raw);s=raw.decode();a=s.index('class MC extends');b=s.index('class Na extends',a)
 Path('/tmp/lidar-root-cause/installed-lasercan-classes.js').write_text(s[a:b])
 print(json.dumps({'bundle':name,'sha256':hashlib.sha256(raw).hexdigest()}));break
else:raise RuntimeError('Installed renderer layout differs; inspect before adapting replay')
