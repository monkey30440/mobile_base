## Parent

[V1 Specification — Mapping、Localization、路網 Navigation、Diagnostics 與 Bringup](https://github.com/monkey30440/mobile_base/issues/32)

## What to build

Operator 在Teleop移動時可取得連續融合里程與一致底座/sensor transforms；原生robot_state_publisher與robot_localization各自擁有唯一TF責任。

本 ticket 依新 V1 spec 與 confirmed decisions 執行；忽略舊 spec/map 及未授權 project runtime 設計。每項 custom runtime 必須追溯 confirmed gap。測試優先公開 ROS／Operator workflow seam與既有Docker/package機制；軟體與實體evidence分開，先判斷可重用證據。硬體或target facts缺失需明記，不能猜測或用software替代；本ticket發布不是自動授權實作。

## Acceptance criteria

- [ ] 原始URDF為幾何authority；保留底座幾何並適配footprint→base_link→底座sensor/model links，避免多重父節點；最終footprint大小寫命名明確統一。
- [ ] 啟動原生robot_state_publisher發布model TF；兩台LiDAR與IMU transform可取得，sensor frames與driver資料一致；所需底座joint state來自適用原生feedback，不合成上半身joint state。
- [ ] 原生robot_localization融合有效wheel odometry與IMU，唯一發布odom→footprint；controller不重複發布odom TF，不新增TF publisher/fusion engine。
- [ ] 以公開TF/odom及受控輸入驗證tree、owner及融合資料鏈，並有實機Teleop方向/尺度與標定evidence；source/topic evidence不冒稱實際估測精度。
- [ ] Mapping/Navigation情境可重用此模型及本地估測配置；不承擔上半身控制/姿態/joint-state ownership或全機碰撞安全。

## Blocked by

- [V1 Implementation — Teleop 驅動底座與輪端回授](https://github.com/monkey30440/mobile_base/issues/35)
- [V1 Implementation — USB IMU 標準資料與異常回報](https://github.com/monkey30440/mobile_base/issues/36)

## Reconciled progress — 2026-10-07

已保留並提交 Operator-confirmed model：FL roll pi/yaw +pi/4；BR roll pi/yaw −3pi/4；IMU yaw +pi/2；pitch 0。姿態在既有模型 joints 表達；native `_1` children identity，沒有額外 CAD links。Operator 已確認所有座標系與雙點雲正確。固定模型／sensor TF 靜止驗收 evidence 可復用，source/hash/revision 見 parent spec reconciliation。

本 ticket 是 model＋estimation 整合 slice，仍由 wheel 與 IMU tickets blocking。已完成 static-model 部分不解除這些 dependencies，也不代表實際 wheel/IMU fusion、dynamic-joint feedback、落地方向／尺度、標定或 Mapping／Navigation reusable composition 已驗收。本輪恢復原計畫，不新增拆票、不更換 TF owners；先完成 open frontier 的 device acceptance，再銜接本 ticket 的完整 integration。

## Confirmed phased verification correction — 2026-10-07

仍按既有 blockers35/36進行完整模型與本地估測整合，保留之前 scoped static/nominal model evidence。先完成裝置能力 acceptance，再銜接完整38；撤回dc3f6ee提前新增 local_base/base composition，不將其67項 software result當作前置裝置／完整38驗收已完成。原已存在native local-estimation partial保留歷史scope，非完整產品Bringup。

Authority: [spec32 phased verification](https://github.com/monkey30440/mobile_base/issues/32)。此修訂取代「核心驗收現在一律從 Bringup 啟動」的先前解讀；保留 Perception／Control 套件命名與現有未完成 acceptance/dependencies。
