## Parent

[V1 Specification — Mapping、Localization、路網 Navigation、Diagnostics 與 Bringup](https://github.com/monkey30440/mobile_base/issues/32)

## What to build

Operator在未定位甚至地圖外完成Navigation Bringup並使用Teleop，提供Initial Pose、確認定位後人工啟用導航。

本 ticket 依新 V1 spec 與 confirmed decisions 執行；忽略舊 spec/map 及未授權 project runtime 設計。每項 custom runtime 必須追溯 confirmed gap。測試優先公開 ROS／Operator workflow seam與既有Docker/package機制；軟體與實體evidence分開，先判斷可重用證據。硬體或target facts缺失需明記，不能猜測或用software替代；本ticket發布不是自動授權實作。

## Acceptance criteria

- [ ] base/sensors/local odom/model TF/Diagnostics/Teleop可用且dataset必要native load成功；map_server與AMCL active，導航所需native nodes configure成功保持inactive。
- [ ] 每次等待Operator Initial Pose，不使用default/cached pose，不偽造identity map→odom；AMCL唯一map→odom owner，無同時Mapping owner。
- [ ] 在未定位狀態能完成Bringup且Teleop可用，不以缺global map TF誤判此合法狀態或autostart timeout冒充readiness。
- [ ] Operator使用RViz確認scan/map對齊與位姿合理性，結束Teleop後原生lifecycle activation/resume；啟用失敗可排查/重試且不視為可導航。
- [ ] 驗證公開lifecycle/InitialPose/TF流程及實機地圖外→入圖→定位→啟用，分清AMCL active、InitialPose、定位可用、導航active；不新增quality/readiness/mode manager。

## Blocked by

- [V1 Implementation — 雙 picoScan 原生接入與來源辨識](https://github.com/monkey30440/mobile_base/issues/37)
- [V1 Implementation — 移動底座模型發布與融合里程 TF](https://github.com/monkey30440/mobile_base/issues/38)
- [V1 Implementation — Navigation dataset 選擇與載入錯誤](https://github.com/monkey30440/mobile_base/issues/40)

## Confirmed phased verification correction — 2026-10-07

此 ticket 才交付 Navigation產品情境Bringup。按原依賴37/38/40完成前置責任，再進行具體composition/native配置/gap研究與正式入口實作；合法未定位／人工啟用/readiness語意保持原decision。

Authority: [spec32 phased verification](https://github.com/monkey30440/mobile_base/issues/32)。此修訂取代「核心驗收現在一律從 Bringup 啟動」的先前解讀；保留 Perception／Control 套件命名與現有未完成 acceptance/dependencies。
