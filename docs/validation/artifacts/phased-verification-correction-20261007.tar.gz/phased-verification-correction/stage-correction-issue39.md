## Parent

[V1 Specification — Mapping、Localization、路網 Navigation、Diagnostics 與 Bringup](https://github.com/monkey30440/mobile_base/issues/32)

## What to build

Operator可啟動Mapping情境、Teleop使用前左scan建圖、以原生能力保存map.pgm與map.yaml，保存成功後結束。

本 ticket 依新 V1 spec 與 confirmed decisions 執行；忽略舊 spec/map 及未授權 project runtime 設計。每項 custom runtime 必須追溯 confirmed gap。測試優先公開 ROS／Operator workflow seam與既有Docker/package機制；軟體與實體evidence分開，先判斷可重用證據。硬體或target facts缺失需明記，不能猜測或用software替代；本ticket發布不是自動授權實作。

## Acceptance criteria

- [ ] 底座/IMU/前左scan、本地odom/model TF、來源診斷與slam_toolbox可使用才算Mapping Bringup完成；不要求地圖已建成。
- [ ] slam_toolbox僅用前左scan且唯一發布map→odom；不啟動AMCL/navigation，後右非必要Mapping input。
- [ ] 原生保存固定map.pgm/map.yaml，保留result/error/log；保存成功即流程結束，不等待graph或增加map preflight/readback/quality runtime/operator checks。
- [ ] 軟體验收可對保存產物做native loading/round-trip；這不是每次保存的操作要求。實機建圖品質與後續定位/導航重用需硬體evidence。
- [ ] 提供建圖、保存及結束情境操作文件；不增加pose-graph persistence/custom map catalog/save wrapper。

## Blocked by

- [V1 Implementation — 雙 picoScan 原生接入與來源辨識](https://github.com/monkey30440/mobile_base/issues/37)
- [V1 Implementation — 移動底座模型發布與融合里程 TF](https://github.com/monkey30440/mobile_base/issues/38)

## Confirmed phased verification correction — 2026-10-07

此 ticket 才交付 Mapping產品情境Bringup。按原依賴37/38完成相關前置驗收後，進行具體composition/native配置/gap研究與正式入口實作；既有Wayfinder已確認責任保留，不從零重做。

Authority: [spec32 phased verification](https://github.com/monkey30440/mobile_base/issues/32)。此修訂取代「核心驗收現在一律從 Bringup 啟動」的先前解讀；保留 Perception／Control 套件命名與現有未完成 acceptance/dependencies。
