## Parent

[V1 Specification — Mapping、Localization、路網 Navigation、Diagnostics 與 Bringup](https://github.com/monkey30440/mobile_base/issues/32)

## What to build

Operator用既有裝置診斷、原生rqt/logs/action/lifecycle/topic/TF資訊辨識Mapping、Localization、Navigation的重要異常與來源。

本 ticket 依新 V1 spec 與 confirmed decisions 執行；忽略舊 spec/map 及未授權 project runtime 設計。每項 custom runtime 必須追溯 confirmed gap。測試優先公開 ROS／Operator workflow seam與既有Docker/package機制；軟體與實體evidence分開，先判斷可重用證據。硬體或target facts缺失需明記，不能猜測或用software替代；本ticket發布不是自動授權實作。

## Acceptance criteria

- [ ] 原生diagnostic_msgs/updater/aggregator/rqt呈現真實producers並配置expected/stale，M1/IMU來源檢查沿其adapter責任，不另建全域watchdog。
- [ ] 建立可操作的fault→component/basic cause/必要context排查流程，覆蓋save/load/AMCL/route/planner/controller/lifecycle及兩台LiDAR native錯誤；不要求所有錯誤轉DiagnosticStatus。
- [ ] 缺diagnostic producer與sensor stale不同；活躍/heartbeat/TF存在不代表資料有效；未定位不自動定義fault，未監控不宣稱健康。
- [ ] 用可重現注入/原生結果展示Operator辨識，真實失聯/device alarms另需hardware evidence。後續避障/取消新增context可重用此native排查流程，不將其未完成部分當已驗收。
- [ ] Compute診斷、自訂UI/history backend/health FSM/readiness或motion gate/常駐統一scan observer不納入。

## Blocked by

- [V1 Implementation — Mapping Bringup、建圖與原生保存](https://github.com/monkey30440/mobile_base/issues/39)
- [V1 Implementation — 未定位 Navigation Bringup 與人工啟用](https://github.com/monkey30440/mobile_base/issues/41)
- [V1 Implementation — 正常路網 NavigateToPose](https://github.com/monkey30440/mobile_base/issues/42)

## Confirmed phased verification correction — 2026-10-07

目前先使用核心套件 own native diagnostics/logs/public ROS入口處理其驗收；完整情境diagnostics排查依本ticket原dependencies於後續Bringup階段交付。不因先有臨時聚合入口宣稱端到端已驗收。

Authority: [spec32 phased verification](https://github.com/monkey30440/mobile_base/issues/32)。此修訂取代「核心驗收現在一律從 Bringup 啟動」的先前解讀；保留 Perception／Control 套件命名與現有未完成 acceptance/dependencies。
