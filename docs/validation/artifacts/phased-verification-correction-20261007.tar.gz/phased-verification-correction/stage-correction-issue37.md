## Parent

[V1 Specification — Mapping、Localization、路網 Navigation、Diagnostics 與 Bringup](https://github.com/monkey30440/mobile_base/issues/32)

## What to build

Operator 以原生 sick_scan_xd 啟動前左／右後 picoScan150，取得兩份獨立scan與可辨識的裝置輸出及錯誤。

本 ticket 依新 V1 spec 與 confirmed decisions 執行；忽略舊 spec/map 及未授權 project runtime 設計。每項 custom runtime 必須追溯 confirmed gap。測試優先公開 ROS／Operator workflow seam與既有Docker/package機制；軟體與實體evidence分開，先判斷可重用證據。硬體或target facts缺失需明記，不能猜測或用software替代；本ticket發布不是自動授權實作。

## Acceptance criteria

- [ ] 兩台Ethernet picoScan150各自scan topic/device identity；mounting frame 分別 base_lidar_link_FL／base_lidar_link_BR；LaserScan 保留原生 layer／echo 後綴，由 robot_state_publisher 的模型 child frames 對應。依 2026-10-07 使用者修訂，兩台均使用原生 LAST echo；正式 `/lidar/fl/scan` frame 為 `base_lidar_link_FL_1`，`/lidar/br/scan` frame 為 `base_lidar_link_BR_1`。不新增 decoder、header rewrite 或 scan merger。實際 transform geometry 仍須 evidence／驗證。
- [ ] IP、UDP ports/sender association、namespace/remapping与QoS依target facts配置並記錄；公开輸出保留來源、timestamp及sensor frame。
- [ ] 原生SOPAS／UDP timeout/reconnect、CRC/parse logs可讓Operator辨識是哪台異常；不冒稱picoScan具有generic diagnosed-publisher frequency/timestamp coverage。
- [ ] 提供獨立來源啟動／辨識／失聯排查與適用software/hardware evidence；sensor frame ID 的輸出不冒稱model TF已發布，model TF由後續模型ticket交付。

## Blocked by

- [V1 Implementation — 最小開發容器與 build/test workflow](https://github.com/monkey30440/mobile_base/issues/47)


## Confirmed revision — 2026-10-07

使用者要求正式單 scan/frame＋mobile_base_description 整合驗證，取代先前 BR ALL。兩台原生 LAST、獨立 topics 與原生 `_1` frames 保留。模型原生 RSP 是唯一固定 TF owner；最新 Operator-confirmed mounting facts 是 FL roll 180°/yaw +45°、BR roll 180°/yaw −135°，pitch 0。安裝旋轉在模型 joints 表達，native scan children identity；不新增 CAD links、不重寫 scan。此版本已通過 Operator 靜止模型／座標系／點雲確認，精確 calibration 與 native shutdown/reconnect/power-cycle/long-run 等驗收仍未完成。舊 +45°/+135° nominal yaw 與中間 CAD/optical-child designs 只保留為被取代的歷史 evidence。

## Confirmed phased verification correction — 2026-10-07

雙原生 LiDAR 接入在 mobile_base_perception。當前使用本套件 dual_picoscan 及原先既有 sensor-model component 驗證入口、正式独立 scan／frame／native錯誤；public LiDAR workflow tests 回到 Perception。不先依賴新的 Bringup 元件入口。

Authority: [spec32 phased verification](https://github.com/monkey30440/mobile_base/issues/32)。此修訂取代「核心驗收現在一律從 Bringup 啟動」的先前解讀；保留 Perception／Control 套件命名與現有未完成 acceptance/dependencies。
