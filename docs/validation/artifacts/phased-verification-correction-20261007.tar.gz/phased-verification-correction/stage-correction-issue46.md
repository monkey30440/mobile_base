## Parent

[V1 Specification — Mapping、Localization、路網 Navigation、Diagnostics 與 Bringup](https://github.com/monkey30440/mobile_base/issues/32)

## What to build

Operator在目標實體底座完成建圖→人工graph dataset→未定位啟動→定位→正常路網/避障/失敗與取消的整體流程，交付可追溯驗收evidence。

本 ticket 依新 V1 spec 與 confirmed decisions 執行；忽略舊 spec/map 及未授權 project runtime 設計。每項 custom runtime 必須追溯 confirmed gap。測試優先公開 ROS／Operator workflow seam與既有Docker/package機制；軟體與實體evidence分開，先判斷可重用證據。硬體或target facts缺失需明記，不能猜測或用software替代；本ticket發布不是自動授權實作。

## Acceptance criteria

- [ ] 先盤點適用approved evidence，記錄target versions/firmware/config、實際dataset內容與conditions；僅補受影響或缺失驗證，不另建平行infra。
- [ ] 以實際硬體完成前左建圖保存、人工graph固定三檔dataset載入、地圖外未定位Bringup與Teleop、InitialPose/Operator確認、結束Teleop/原生啟用。
- [ ] 實體normal route/connectors/final xy+yaw、必要detour/return/合法alternate route、不可完成時failure、cancel/stop/Teleop與異常辨識均有相應evidence，不以軟體mock/topic結果替代。
- [ ] 補齊相關wheel/extrinsics/IMU/time/model/controller/localization calibration與驗收容差定義，採實際測量，不捏造threshold。
- [ ] 清楚區分implemented/software-validated/hardware-validated與未驗項；未完成硬體條件不close為fully verified或Feature Freeze。硬體未可用時完成可做的準備與記錄待驗，不冒稱完成。

## Blocked by

- [V1 Implementation — Mapping Bringup、建圖與原生保存](https://github.com/monkey30440/mobile_base/issues/39)
- [V1 Implementation — 必要避障、合法改路與回網](https://github.com/monkey30440/mobile_base/issues/43)
- [V1 Implementation — 導航失敗、取消與 Teleop 交接](https://github.com/monkey30440/mobile_base/issues/44)
- [V1 Implementation — 核心 Diagnostics 的操作排查流程](https://github.com/monkey30440/mobile_base/issues/45)

## Confirmed phased verification correction — 2026-10-07

完成各核心套件及38整合驗收後，再使用後续正式Mapping／Navigation Bringup做整體實機流程驗收。dc3f6ee提前整合軟體結果保留歷史scope，不當成當前正式入口或physical/calibration/complete V1 evidence。

Authority: [spec32 phased verification](https://github.com/monkey30440/mobile_base/issues/32)。此修訂取代「核心驗收現在一律從 Bringup 啟動」的先前解讀；保留 Perception／Control 套件命名與現有未完成 acceptance/dependencies。
