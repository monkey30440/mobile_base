## Problem Statement

Operator 需要在指定移動底座上建立並重用地圖、從地圖外啟動後人工建立定位，以及將 AMR 導航至指定 x／y／yaw。正常導航必須依既定路網行駛，障礙阻擋時允許必要局部偏離並回網；不能完成符合要求的導航時必須回報失敗。系統亦須提供可使用的情境 Bringup 與可辨識來源、原因及必要排查資訊的 Diagnostics。

本 spec 從 [Cleared V1 Wayfinder Map](https://github.com/monkey30440/mobile_base/issues/18) 與其已確認 decisions 合成，完全忽略舊 spec／舊 map。目標是在保留產品要求與驗證責任的前提下，以最少 project-owned runtime code 完成 V1。

## Solution

提供 Mapping Bringup 與 Navigation Bringup。Operator 在 Mapping 情境使用 Teleop 建圖，保存 map.pgm 與 map.yaml。在 Navigation 情境，即使 AMR 尚未定位，底座與 Teleop 仍可用；Operator 入圖、提供 Initial Pose 並確認定位，結束 Teleop 後人工啟用導航，透過原生 NavigateToPose 執行任務。

採成熟原生 ROS 2／Nav2 能力組合：slam_toolbox 建圖、map_server／AMCL 定位、Route Server／NavFn／原生 BT／MPPI 導航、原生 diagnostics 與操作工具排查。自訂 runtime 限定必要 M1 與 USB IMU 裝置 adapters；其餘 project responsibility 為模型、配置、BT 與情境 launch 組合及操作文件。

## User Stories

1. As an Operator, I want 啟動 Mapping Bringup, so that 我能直接開始人工建圖流程。
2. As an Operator, I want Bringup 完成代表所需能力可使用, so that 我不會把 process 已啟動誤認為功能正常。
3. As an Operator, I want 在尚未建立地圖時完成 Mapping Bringup, so that 我能開始建立新地圖。
4. As an Operator, I want 使用 Teleop 控制底座, so that 我能人工巡覽建圖區域。
5. As an Operator, I want 使用前左 LiDAR 建圖, so that V1 採已確認的原生單 scan 流程。
6. As an Operator, I want SLAM 使用有效本地里程與 sensor TF, so that 建圖資料有正確空間關係。
7. As an Operator, I want 保存 map.pgm 與 map.yaml 且原生保存成功後結束，不增加額外檢查, so that 地圖能在之後重用。
8. As an Operator, I want 看到保存操作結果及失敗資訊, so that 我能判斷是否需要重試或排查。
9. As an Operator, I want 保存的配對地圖能由原生 loader 載入, so that Localization 與 Navigation 使用同一份地圖。
10. As an Operator, I want 結束 Mapping 後切換至 Navigation 情境, so that 不會有兩個 map→odom owners 競爭。
11. As an Operator, I want 啟動 Navigation Bringup 並載入已存地圖, so that 定位與導航基礎能力準備完成。
12. As an Operator, I want AMR 可在地圖外啟動, so that 初始實體位置不限制底座啟動。
13. As an Operator, I want 尚未定位時 Teleop 仍可用, so that 我能將 AMR 移入已建圖區域。
14. As an Operator, I want 每次啟動定位等待我提供 Initial Pose, so that 系統不誤用預設或上次位置。
15. As an Operator, I want 使用原生 Initial Pose 操作, so that 我能提供目前的近似地圖位姿。
16. As an Operator, I want 在 RViz 檢查 scan／地圖對齊與位置合理性, so that 我能確認定位可供導航使用。
17. As an Operator, I want 分辨 AMCL active、收到 Initial Pose 與定位可用, so that 我不會將初始化事件當作定位正確證據。
18. As an Operator, I want 分辨 Bringup 完成與導航啟用, so that 未定位的合法狀態不被誤報成 Bringup 故障。
19. As an Operator, I want 定位確認後人工啟用原生導航 lifecycle group, so that 不需要額外自動 readiness runtime。
20. As an Operator, I want 啟用失敗時看到 transition result 與元件原因, so that 我能修正後重試。
21. As an Operator, I want 使用 NavigateToPose 指定 x／y／yaw, so that AMR 能抵達完整目標位姿。
22. As an Operator, I want 人工準備對應該 occupancy map 的合法路網，放入同 dataset 的 route_graph.geojson, so that 正常任務遵循既定行駛路線。
23. As an Operator, I want AMR 從目前位置安全進入路網, so that 起點不必剛好在路網上。
24. As an Operator, I want 正常移動沿合法路網, so that AMR 不任意以路網外捷徑完成任務。
25. As an Operator, I want 接近目標時離網完成終點銜接, so that 目標不必剛好是路網節點。
26. As an Operator, I want 相同 x／y 但不同 yaw 的目標仍完成姿態調整, so that 任務不忽略最終朝向。
27. As an Operator, I want 左前與右後 LiDAR 分別供導航感知使用, so that 來源身分與量測位置保留。
28. As an Operator, I want 障礙阻擋時進行必要局部避障, so that 可行的局部繞行不被直接放棄。
29. As an Operator, I want 避障後回到目前選定的合法路線, so that 暫時偏離不變成任意路網外行駛。
30. As an Operator, I want 原路受阻時可改選另一條合法路網路線, so that 任務可使用合法替代路線。
31. As an Operator, I want 無法符合導航要求時得到 failure, so that 系統不以無限重試或任意 freespace fallback 掩蓋失敗。
32. As an Operator, I want 任務結果保留可用的 native error context, so that 我能排查 route／planning／control 等問題。
33. As an Operator, I want 開始導航前結束 Teleop, so that 我能依操作程序管理速度命令互斥。
34. As an Operator, I want 取消導航並等待任務 terminal 後才開始 Teleop, so that 我不把取消請求當成任務已結束。
35. As an Operator, I want 分辨零速度、timeout、任務結束與實體停止, so that 每個操作判斷依據正確 evidence。
36. As an Operator, I want 看見 M1 通訊、裝置 alarms 與有效回授异常, so that 我能定位輪控問題。
37. As an Operator, I want 看見 USB IMU 通訊、packet／資料有效性及逾時異常, so that 我能辨識估測輸入問題。
38. As an Operator, I want 分辨左前與右後 LiDAR 的連線／接收／解析異常, so that 我能找到實際異常來源。
39. As an Operator, I want 看見影響建圖、定位與導航的核心軟體異常, so that 我能取得元件、基本原因與必要排查資訊。
40. As an Operator, I want 使用原生 rqt、logs、操作結果與 topic／TF 工具, so that 排查不依賴新自訂 UI。
41. As an Operator, I want 未監控或缺少診斷的項目不被宣稱正常, so that 診斷呈現不超出 evidence。
42. As a verification engineer, I want 軟體、硬體及 calibration evidence 分開記錄, so that 原生 source 能力或測試替身不被當成實機驗收。
43. As a maintainer, I want 每項 custom runtime 責任可追溯至 confirmed gap, so that V1 維持 MVP／YAGNI 與 native-first。

44. As an Operator, I want Navigation 只指定一個包含固定 map.pgm、map.yaml、route_graph.geojson 的 dataset 資料夾, so that 我以一組配對資料啟動導航。
45. As an Operator, I want 缺少任一必要檔案直接報錯並指出來源, so that 不完整資料不會被當成 Navigation Bringup 完成。
46. As an Operator, I want 原生 map／graph 載入失敗保留原因且不使用另一份資料 fallback, so that 啟動結果反映實際輸入。

## Implementation Decisions

1. **平台與硬體 authority**：AGX Orin、Ubuntu 24.04／ROS 2 Jazzy；已確認平台選擇為 JetPack 7.2.1／Jetson Linux 39.2.1。其他套件採適用 Jazzy 的穩定版本，實際部署版本需可重現並記錄；研究 snapshot 不等於已安裝。原始 RWF_V2.0_QA_release.urdf 與硬體文件為 geometry authority；原始供應版本 SHA256 b49ef5cc66217ff5fb527a4d10a1d63b5f941dbd024bb30bb6704442c39e08fc 保留為歷史輸入。實機安裝 facts 可由 Operator 明確確認後修訂 deployment model，必須區分原始 authority revision、修訂 model revision/hash 與其驗證範圍，不把原始 hash 當成修訂模型的身分。
2. **輪控 boundary**：原生 ros2_control／diff_drive_controller 擁有通用差速控制、輪端里程、限制與命令 timeout。M1 hardware adapter 僅補 USB→RS485、Modbus Multi-drive 2.0 裝置協定、命令／有效回授轉換與來源診斷。不得重作差速運動學／輪里程引擎；若找到完整相容的成熟 upstream adapter，優先重用。
3. **感測 boundary**：雙 picoScan150 採原生 sick_scan_xd，保留獨立 scan topics、device identity 與時間／frame。實體 mounting frames 為 base_lidar_link_FL／base_lidar_link_BR；兩台採原生 LAST echo，正式獨立 topics 為 /lidar/fl/scan／/lidar/br/scan，LaserScan frames 為 base_lidar_link_FL_1／base_lidar_link_BR_1，由 mobile_base_description／原生 robot_state_publisher 提供模型與 mounting→scan child transforms。已確認的安裝旋轉由模型 joints 單一來源表達；若 native scan 與 mounting 軸相同，child 使用 identity，不重複旋轉，也不以新增 CAD links 或 header rewrite 修正資料。實際 extrinsics 需驗證／標定；本機姿態數值是已確認 deployment facts，不是所有平台共用的 V1 固定數值。USB IIM-42652 frame 為 base_imu_link；重新設計的 adapter 僅負責 bridge 通訊、packet 驗證、標準 ROS IMU 資料轉換及裝置異常。既有已驗證 IMU implementation 僅作允許的經驗 reference，不直接沿用設計或驗證宣稱。
4. **本地估測與 model TF**：原生 robot_localization 融合輪端里程與 IMU，唯一發布 odom→logical footprint；關閉 diff_drive_controller 重複 odom TF。原生 robot_state_publisher 擁有 model TF，整合情境只啟動一個 model owner；不得把獨立裝置驗證入口的 RSP 與整合模型 RSP 同時啟動。模型保留原始幾何並適配成 footprint→base_link→底座 sensor/model links，避免多重父節點。BASE_FOOTPRINT／base_footprint 的確切命名依已批准決策留實作選定，所有配置必須一致；不引入 custom TF publisher。
5. **Mapping**：原生 slam_toolbox 僅使用前左 scan 並唯一發布 map→odom；原生地圖保存輸出 map.pgm／map.yaml。保存結果必須可由原生 loader 解析並在後續定位／導航重用；不以檔案存在判定地圖可用。Mapping 在原生保存成功後結束，不等待 graph，也不增加 image／YAML 額外 preflight、readback、quality／semantic checks。正常 native loading 的解析與錯誤回報仍適用；無 custom map store／save wrapper／quality checker 的 confirmed requirement。
6. **Localization**：原生 map_server 載入地圖，AMCL 使用前左 scan 與本地 odometry／TF，唯一發布 Navigation 情境 map→odom。每次初始化等待 Operator Initial Pose，不配置預設／cached 自動位置；AMCL active 未初始化可存在，不能補造 identity transform。Operator 透過原生 RViz 確認定位可用；不建立定位 quality FSM 或自動 admission gate。
7. **Navigation 對外 contract**：使用原生 NavigateToPose，goal 表達地圖中的 x／y／yaw，原生 action feedback／success／failure／canceled 與可用 error context 對外可觀測。native pose header/frame/time 的合法使用須於配置與操作文件說明；不新增 action wrapper 或 NavigateToStation。
8. **Navigation 責任分工**：Route Server 選擇人工準備的合法 graph 路線及必要改選；NavFn 負責起終點 connectors；原生 BT Navigator／BT nodes 組合任務與 FollowPath 等能力；MPPI 負責局部控制／必要避障。project-owned BT/configuration 補 application composition，不新增 runtime planner／route supervisor。
9. **路網行為 contract**：正常行驶沿選定合法 graph 路線；允許必要進網／離網 connectors。障礙阻擋才允許必要 local detour，之後回到目前合法路線；允許改選合法 graph route。沒有 connector 必要時可省略該段，但不得忽略 final yaw。不得將整趟 unrestricted freespace fallback 當作成功方案。
10. **完成與失敗 contract**：native goal checker 檢查完整目標 pose；progress checks、有限 recovery/retry、route/planner/controller/TF/costmap errors 及 BT/action propagation 提供 failure。不得吞掉真正錯誤、無限重試或在 terminal 後遺留子任務。抵達 goal 不足以證明路網／必要偏離／回網合規；MPPI soft critics 也不是正式保證。若驗證揭露原生組合不足，明確重新確認 gap，不能靜默放寬 requirement。
11. **導航感知**：costmap 以原生 observation_sources 分別使用兩份 LaserScan，不合併 scan。各來源 TF、時間、marking/clearing、invalid/no-return 語意需一致配置；使用適當非零 expected_update_rate 提供 consumer freshness 檢查，不能以 default 0 宣稱已監控。
12. **Diagnostics**：採 diagnostic_msgs／diagnostic_updater／diagnostic_aggregator／rqt，配合 native logs、service/action results、lifecycle 與 topic/TF 工具。M1／IMU adapter 擁有裝置特有診斷；其他 native outputs 保留可辨識的元件與必要 context，不強制全部轉成 DiagnosticStatus。
13. **Diagnostics 限制**：aggregator expected/stale 只針對真實 diagnostic producers；producer heartbeat 與 sensor sample freshness 不同。picoScan 路徑沒有 generic diagnosed-publisher 的 scan frequency/timestamp coverage，使用已查證的 SOPAS／UDP／CRC／parse 原生資訊與操作工具。costmap freshness 不等於 Mapping／AMCL 全面自動監測；不新增常駐統一 scan observer，也不宣称所有異常皆自動檢出。未定位是合法狀態，診斷不取得 motion/readiness authority。
14. **Mapping Bringup contract**：底座控制、必要感測、本地估測／TF、Diagnostics、Teleop 與前左 SLAM／保存能力可使用即完成；不要求已建成地圖、不啟動 AMCL／導航。後右 LiDAR 可否隨共用 hardware launch 啟動屬配置，不能把它當成單 scan Mapping 的必要完成條件。
15. **Navigation Bringup contract**：底座控制、雙 LiDAR、IMU、本地估測／TF、Diagnostics／Teleop 可用，選定 dataset 的固定三檔都存在且必要 native map／graph 載入/configure 成功、map_server／AMCL active 可接受 Initial Pose，所需導航 lifecycle nodes configure 成功並保持 inactive，即為完成。不得為等待 map TF 直接 autostart 全部導航 nodes 或延長 timeout 來冒充此合法狀態。
16. **導航啟用 ownership**：分離 localization 與 navigation 的原生 lifecycle 管理。navigation manager 管理已選 Route Server、Planner Server、Controller Server、BT Navigator，以及實際 BT 所需的其他原生 managed capabilities；costmaps 依所屬 server 管理。所有必要 capabilities configure 成功後，Operator 完成定位確認、結束 Teleop，使用原生 lifecycle activation/resume。啟用成功才送 goal；啟用失敗依 native result/log 排查與重試。精確 native node names／服務名稱／BT ports 是整合配置，不另外發明 public runtime interface。
17. **狀態語意**：Bringup 完成、AMCL active、Initial Pose 已提供、定位可用、導航已啟用、任務執行／terminal 與物理停止各有不同判斷。readiness 由情境條件與 Operator 判读，無新統一 readiness boolean／FSM。各 native 元件擁有自身 lifecycle／操作結果。
18. **操作互斥與情境切換**：Operator 開始導航前結束 Teleop；Teleop 前取消導航並等待 terminal。此為程序互斥，系統不強制 admission。零速度／timeout 不等同操作結束；cancel accepted 不等同 terminal／physical stopped。Mapping／Navigation 為替代情境，結束原情境後再啟動另一種，避免競爭 map→odom owners。
19. **配置與操作交付**：提供兩種情境的 launch/configuration、所需模型與 native BT 組合，以及人工地圖／路網準備、Initial Pose、activation、cancel／Teleop、保存與排查的操作說明。裝置 IDs／IP／UDP、firmware／scales、frame consistency、QoS／topics、map／graph 輸入與診斷 producer 配置須可追溯。操作文件不得將未驗證 target facts 當成預設事實。

20. **Navigation dataset contract**：Navigation 對外選一個 dataset directory，固定包含 map.pgm、map.yaml、route_graph.geojson；缺一直接報錯並指出 dataset／缺失檔案，不能宣稱 Bringup 完成，不 fallback 至其他 map／graph。map.yaml image 指向同 dataset 的 map.pgm；graph 描述該 occupancy map 下的合法路網，座標與 metric map frame 一致。這是一次輸入的明確配對，非全域嚴格一對一。
21. **Dataset preparation／native loading**：Mapping 原生保存兩檔後結束；Operator／工程人員另行人工建立 graph，依已選 Route Server 原生 GeoJSON schema 與合法路網需求準備並置於同資料夾。此責任不新增保存後檢查或強制審查 checklist，也不承諾 native 可檢出可解析的語意誤配。launch/configuration 將 directory 解為 native map input 與明確非空 graph_filepath，原生 graph/map loading 擁有其 parsing/TF/I/O errors。空 graph configure success 不滿足 V1；任何必要 loading/configure failure 都不得冒充 ready。
22. **Dataset implementation boundary**：固定三檔與資料夾選擇是產品 contract；root、timestamp/folder naming、mkdir、launch argument 名稱、directory path resolution／permission／存在性處理的具体機制與 graph authoring tool 留實作。此最小 application integration gap 用 launch/configuration 補足，不要求 dataset manager／額外 map或graph validator／manifest runtime。
23. **Dataset traceability／change**：選定 directory 與實際 native 載入三檔可辨識；驗證 evidence 記錄實際內容，不能用可變路徑宣稱永久 revision。變更資料沿既有情境結束／重新 Bringup，無 live map＋graph switch、atomic rollback 或版本庫要求。資料變更依既有 evidence applicability 規則重判必要驗證；不新增 Operator revision-management 系統。


### Reconciled model responsibility — nominal drive suspension / measured wheel position

Operator confirmed on2026-10-07: the two drive-seat slide joints use their original URDF design origins at nominal zero displacement in the V1 deployment model. This is nominal suspension geometry, not live measured suspension state. Source URDF geometry remains authority; the source file is preserved, and only the two corresponding deployment joints become fixed for native robot_state_publisher. Actual wheel rotation continues to come from M1 position feedback through native ros2_control/joint_state_broadcaster; no fabricated wheel angle, passive-joint publisher or replacement TF runtime is added. Other unmeasured passive joints are not implicitly declared fixed or accepted.

Evidence chain: V1 required base/sensor/model TF → native RSP requires state for movable joints → measured wheel position removed the NaN defect, but the actual source's two prismatic driving-slide joints had no confirmed feedback and disconnected base-to-wheel paths → Operator adopted nominal design posture → minimal build-time adaptation plus native fixed TF. This contract does not establish physical suspension measurement, mechanical wheel phase, displacement calibration or full passive-model acceptance. Position adapter verifies actual mode0/encoder configuration and treats invalid/reset/jump feedback as invalid until deliberate recovery; native controller retains velocity-based odometry and EKF retains sole odom→base_footprint ownership.

### Confirmed package responsibilities and phased verification — 2026-10-07

使用者保留套件調整：USB IMU 與雙 LiDAR 接入整合至 **mobile_base_perception**；M1 adapter／原生 controller integration 套件改名 **mobile_base_control**。**mobile_base_description** 保留模型 responsibility，**mobile_base_bringup** 最終擁有 Mapping／Navigation 情境組合責任。Driver、協定、正式 topics／frames、來源診斷、量測輪角／名義輪座語意與 native owners 不因套件組織改變。

使用者澄清並確認開發順序：先完成 Control／IMU／LiDAR 核心套件各自的驗證與既有35/36/37 acceptance，再依38完成模型／輪端／IMU／native EKF 整合；之後才依39/41進行產品 Bringup 的具體組合研究與交付。Wayfinder 已確認的 Bringup responsibility／readiness／lifecycle decisions 保留，不需從零重做；具體配置或 confirmed gap 在適當階段處理。

「之後測試使用 mobile_base_bringup」是產品情境交付後的整體流程驗收目標，不是現在要求核心套件先依賴 Bringup 才能驗證。核心階段使用所屬套件已安裝的 executable／launch 與公開 ROS／Operator workflow seam；Control／Perception 的必要 bounded protocol／adapter tests 留在各套件。模型可用既有 Description／sensor-model 驗證入口；它們不是完整產品 Bringup，也不得重複啟動 RSP。

撤回dc3f6ee提前新增的 Bringup component/local_base/base composition 入口與其當期強制依賴；保留 Perception 整併、Control 改名及其裝置能力。公開 Control／LiDAR workflow tests 回到所屬套件，原本就已交付的 dataset／native local-estimation partial 不因此被刪除或宣稱整體 Bringup 已完成。先前提前整合的 source、軟體結果與 raw evidence 保留為歷史／研究證據，不當成目前正式驗證入口或解除未完成 hardware/calibration gates。

套件名稱、manifest／plugin/module identity、安裝入口及操作文件一致更新；新套件可发现／建置與公開資料／diagnostics／TF 等受影響責任需驗證，避免舊 install overlay 誤判。正式情境驗收從 Bringup 的公開入口進行，是後續階段的交付；不以 process startup、既有 partial code 或提前 software PASS 宣稱產品 readiness。此階段修訂不關閉任何 open ticket 或解除 dependencies。

## Testing Decisions

使用者已確認 testing seams 按階段使用：**核心套件各自已安裝入口的公開 ROS／Operator workflow**，之後38的模型／估測整合，再到**兩種產品 Bringup 啟動後的公開 ROS 介面與 Operator workflow**。在最高可行邊界驗證外部行為；避免以函式呼叫順序、private states、文件字串或配置存在替代功能驗收。只在 M1／IMU 的協定轉換與有效性無法在主邊界充分驗證時補 adapter 層測試，不新增平行驗證框架。

| 驗證範圍 | 可觀測 acceptance | Evidence class |
| --- | --- | --- |
| 模型／感測／輪控／本地估測整合 | 每來源可辨識、標準資料有效；TF tree 幾何與唯一 owners 一致；有效輪端 feedback 可用於 odometry／IMU 融合；timeout／取消語意正確 | 軟體介面／受控輸入可驗證整合；實際回授、物理方向／位移／停止須硬體；尺度與外參須 calibration |
| Mapping workflow | Bringup 後 Teleop／SLAM 可使用；前左 scan 建圖；原生保存 success；原生重新載入可解讀配對產物並供後續定位／導航使用。保存／載入 failure 可辨識 | 產物 round-trip／原生結果可 software-test；實際地圖品質、實機重用須 hardware |
| Navigation dataset | 一個 directory 對應固定三檔與同組 map image；分別缺 map.pgm、map.yaml 或 route_graph.geojson 均直接錯誤；native load/configure failure 不宣稱 ready、不換資料 fallback；明確非空 graph 輸入 | software 可驗證 public launch／native介面結果；graph-map 真實語意與可行路線仍須 hardware acceptance；不是新增日常 map validator |
| 未定位啟動及 Localization | 地圖外啟動無預設／cached pose，底座／Teleop 可用且 Bringup 可完成；導航 configured/inactive；入圖提供 Initial Pose，Operator 可確認估測；啟用成功後使用导航 | 受控資料可驗證 initialization／lifecycle；真實入圖、定位精度與對齊／操作可用性須 hardware |
| 正常導航／connectors／final pose | 從路網外進網，正常經合法路線、近目標離網；on-route／零 connector／同 XY 不同 yaw 均不丟失目標責任 | 軟體場景驗證 action／BT／path 整合；真實軌跡與 final pose 須 hardware |
| 避障／改路／回網 | 障礙使正常路線受阻時有必要 local detour 並實際返回目前合法路線；可改選另一合法 graph route；交叉路口／loops 不以任意捷徑成功 | software 場景可檢查整合行為；實體障礙、雙 sensor 視野及實際回網須 hardware；goal success 單獨不足 |
| failure／cancel | 無合法可行任務、缺必要 map／graph／TF、planning/control failure 時傳播結果；有限 recovery，不以整趟自由規劃替代要求；cancel 後終止 child actions 並觀察 terminal | software 驗證 result propagation／bounded behavior；cancel→Teleop 與實體停止須 hardware |
| Diagnostics／啟動失敗 | 注入相關通訊／裝置／資料／元件／transition／save-load／任務異常，Operator 能取得来源、基本原因及排查 context；合法未定位不被當 Bringup fault，未監控不等於正常 | 注入只證明該輸入下軟體觀測；真实失聯／device alarms／physical-feedback 與操作辨識須 hardware；Compute 排除 |
| M1／USB IMU 最小補充 seam | 協定輸入／輸出轉換、packet／回授 invalidity、timeout 與來源診斷符合已確認責任，不將 invalid data 當有效 measurement | bounded adapter software tests；實體協定／firmware／有效數據仍需 hardware |

Prior art：repository 已具 Docker/Compose 開發環境與 colcon/package 測試機制，測試 inventory 包含 launch、地圖 round-trip、TF authority、feedback odometry chain、命令停止链與 BT runtime 類型。僅採其驗證層次作參考；未讀取或承襲禁止的舊 project-owned 實作／spec，也不宣稱既有測試已符合新 V1。後續選用適用的既有 package-level tools；若沒有符合本 spec 的 scenario test，再於同一 ROS workflow seam 補充。

Mapping 保存後不增加 Operator map檢查；上述 round-trip／loading 是開發驗收 evidence，不是每次保存時執行的新 runtime／操作流程。

先檢查可重用的 approved evidence：實作／配置、目標環境、scope、acceptance criterion 與 evidence class 必須仍適用；只重跑受影響或缺 evidence 項目。source/tests 查讀不等於執行，軟體／topic evidence 不替代 controller／hardware feedback／physical observation。

數值 acceptance 不捏造：輪參數、外參、IMU covariance／noise、目標 xy/yaw 容差、正常路網追蹤／回網界限及 freshness／timeout 等需按裝置 facts、標定與實際 operating evidence 決定，於相關硬體驗收前記錄測試条件与適用數值。未完成這些定義與實體驗證前，不宣稱該行為 fully validated 或 Feature Freeze。

**已確認靜止 evidence 的復用**：Operator 已確認整合模型、座標系與雙正式 scan 正確；這是所記錄 model revision 下的靜止視覺驗收。後續可復用仍適用的 evidence，但不能取代 wheel／IMU 的動態方向、尺度、bias／noise、精確 calibration、真實 EKF integration、重新連線／長時間等未完成驗收。模型／安裝修改後重新判定受影響 evidence，不用僅保留同名 frame 宣稱證據仍有效。

## Out of Scope

- NavigateToStation、Docking 與其他未確認的未來能力。
- 上半身控制、姿態／joint-state ownership、完整上半身碰撞形狀管理；其他團隊負責。不宣稱全機器人碰撞安全。
- Compute 診斷，包括 CPU／memory／disk／Orin temperature／throttling／其他 host monitoring；未監控不可宣稱健康。導航 workload 的實際可用性仍需驗證，但不因此新增 host diagnostics capability。
- 雙 LiDAR Mapping／AMCL、scan merger、續接建圖／pose-graph persistence、custom 地圖格式／catalog／quality checker。
- 系統強制 Navigation／Teleop 互斥、mode/admission manager、自動 readiness／定位 quality FSM、自動 global relocalization／情境 hot-switch。
- 自動 graph generation、dataset manager／manifest／revision database、額外 map／graph validators、固定 /maps/YYYYMMDD_HHMMSS/ 目錄、live dataset switching／atomic rollback。
- 自訂診斷 UI、全域 health manager、強制 native errors 全轉 DiagnosticStatus、歷史／遠端 observability backend、常駐統一 scan observer。
- 尚無 confirmed gap 的 custom Navigation runtime、無限制 freespace fallback、無限 recovery。
- 本次 specification 交付不包含 implementation tickets、實作、production baseline 遷移或執行硬體驗證／calibration。

## Further Notes

**Authority／traceability**：本 issue 是新 V1 spec 的合成輸出；詳細架構 rationale 與原生 evidence 保留於以下決策，舊文件不是輸入或新 baseline。新 spec issue 的 ready-for-agent label 按 skill 套用，**不代表已授權跳過 spec 審閱直接實作**。

- [平台、硬體接入與本地運動責任](https://github.com/monkey30440/mobile_base/issues/22#issuecomment-5943788571)
- [Mapping 與地圖儲存重用責任](https://github.com/monkey30440/mobile_base/issues/23#issuecomment-5943908909)
- [Initial Pose 定位與導航使用邊界](https://github.com/monkey30440/mobile_base/issues/24#issuecomment-5943964561)
- [路網 NavigateToPose 與必要避障責任](https://github.com/monkey30440/mobile_base/issues/25#issuecomment-5944111772)
- [核心 Diagnostics 覆蓋與狀態 ownership](https://github.com/monkey30440/mobile_base/issues/26#issuecomment-5944271743)
- [兩種 Bringup 與定位分離的 readiness 語意](https://github.com/monkey30440/mobile_base/issues/27#issuecomment-5944312692)

- [Navigation map dataset 配對與人工準備流程](https://github.com/monkey30440/mobile_base/issues/34#issuecomment-5944616227)

**版本 evidence**：Wayfinder snapshot 採 Nav2 1.3.13、slam_toolbox 2.8.5、sick_scan_xd 3.9.0、robot_localization 3.8.3、diagnostics 4.2.7、ros2_control 4.48.1、ros2_controllers 4.42.1、robot_state_publisher 3.3.4。版本可查閱各 linked research；部署解析出的版本須另記錄，升版不得假定接口／能力與證據不變。

**Evidence 狀態**：CONFIRMED 為使用者已確認 requirement／architecture 及 source 支持的 native capability；UNRESOLVED 為實際 carrier／BSP、device firmware／IDs／scales、最終命名與具體配置 target facts，實作不得猜測；REQUIRES HARDWARE VALIDATION 與 REQUIRES CALIBRATION 依上述測試及決策保留。若 facts 或能力證據推翻已選架構，先明確修正相應 decision／spec，再修改方案。

**階段交接**：本次完成 specification synthesis 與發布；沒有 runtime 修改、software runtime tests 或硬體驗證。經使用者確認 spec 後，才依後續 `/to-tickets` 流程規劃，再進入明確授權的 implementation。

## Reconciliation — 2026-10-07

已確認修訂 deployment facts 與正式 topics／frames、native owners 未改變；未新增 V1 功能或 custom runtime responsibility，既有 Wayfinder decisions 不需重做。

Operator 確認 FL roll 180°/yaw +45°、BR roll 180°/yaw −135°、IMU yaw +90°，pitch 0；兩個 native scan children identity。Operator 已確認所有座標系與點雲正確。修訂 deployment URDF SHA256 f6447d72716a11f4e5ee9d447b58d81256746af91604acb85b6ab56540e0f425，commit 8377380；原始供應 URDF 可由其之前的 git revision 追溯。這些值不等於精確 extrinsic calibration。

[Canonical recovery evidence](https://github.com/monkey30440/mobile_base/issues/38#issuecomment-6030624541) 記錄 scope 與歷史 superseded approaches；published commit 將原本未提交的修正固定。受影響交付仍沿既有雙 LiDAR 接入／模型與融合里程 tickets，保留 wheel／IMU 的真實 dependencies；不以已完成 static model 部分冒充整張 estimation ticket 完成。

## Confirmed Perception component entries — 2026-10-07

Operator confirms separate IMU/LiDAR launch and config within mobile_base_perception. Add imu.launch.py with explicit imu_config ROS parameter file; dual_picoscan.launch.py accepts explicit lidar_config while preserving individual CLI arguments/overrides. Install config/imu.yaml and config/lidar.yaml with known target/commissioning evidence and explicit uncertainty notes; no implicit hardware-profile selection, guessed calibration, new decoder/fusion or product Bringup. Verify through installed component launch/public ROS seams, without physical devices.
