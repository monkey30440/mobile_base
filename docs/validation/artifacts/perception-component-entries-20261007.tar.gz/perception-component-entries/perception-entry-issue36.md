## Parent

[V1 Specification — Mapping、Localization、路網 Navigation、Diagnostics 與 Bringup](https://github.com/monkey30440/mobile_base/issues/32)

## What to build

Operator 可啟動重新設計的 USB IIM-42652 adapter，取得標準 ROS IMU 資料，辨識通訊／packet／有效性異常，供後續本地估測使用。

本 ticket 依新 V1 spec 與 confirmed decisions 執行；忽略舊 spec/map 及未授權 project runtime 設計。每項 custom runtime 必須追溯 confirmed gap。測試優先公開 ROS／Operator workflow seam與既有Docker/package機制；軟體與實體evidence分開，先判斷可重用證據。硬體或target facts缺失需明記，不能猜測或用software替代；本ticket發布不是自動授權實作。

## Acceptance criteria

- [ ] 僅使用已允許 IMU reference 的經驗與驗證結果獨立推導；不直接沿用設計或把reference evidence 當成新實作已驗證。
- [ ] USB bridge通訊／packet驗證、單位與座標轉換輸出標準 IMU，frame為base_imu_link；有效性與covariance依實際device evidence，不虛構測量。
- [ ] 來源診斷使用native updater，識別通訊失聯、packet/資料無效及無有效samples逾時；invalid data 不當有效measurement。
- [ ] 公開資料/diagnostics介面與必要 bounded protocol測試可展示轉換及異常行為；實際device/time/axes/bias需硬體與標定evidence，無自訂fusion或map定位。

## Blocked by

- [V1 Implementation — 最小開發容器與 build/test workflow](https://github.com/monkey30440/mobile_base/issues/47)

## Confirmed phased verification correction — 2026-10-07

IMU 與 LiDAR 同屬 mobile_base_perception；當前從本套件 usb_imu 與公開 IMU/diagnostics 邊界及必要 bounded protocol tests 驗收，無須先有 Bringup composition。device axes/scale/covariance 等未驗責任不因整併解除。

Authority: [spec32 phased verification](https://github.com/monkey30440/mobile_base/issues/32)。此修訂取代「核心驗收現在一律從 Bringup 啟動」的先前解讀；保留 Perception／Control 套件命名與現有未完成 acceptance/dependencies。

## Confirmed Perception component entries — 2026-10-07

Operator confirms separate IMU/LiDAR launch and config within mobile_base_perception. Add imu.launch.py with explicit imu_config ROS parameter file; dual_picoscan.launch.py accepts explicit lidar_config while preserving individual CLI arguments/overrides. Install config/imu.yaml and config/lidar.yaml with known target/commissioning evidence and explicit uncertainty notes; no implicit hardware-profile selection, guessed calibration, new decoder/fusion or product Bringup. Verify through installed component launch/public ROS seams, without physical devices.
