"""Bounded independent native launches; no motor/device access or scan rewriting."""
import json,math,os,signal,subprocess,time
from pathlib import Path
import rclpy
from rclpy.qos import qos_profile_sensor_data
from rclpy.time import Time
from sensor_msgs.msg import LaserScan
from tf2_ros import Buffer,TransformListener
from ament_index_python.packages import get_package_share_directory

out=Path('/tmp/lidar-verify/evidence');out.mkdir(parents=True,exist_ok=True)
logs=[];processes=[]
commands=[['ros2','launch','mobile_base_description','description.launch.py'],
 ['ros2','launch','mobile_base_perception','dual_picoscan.launch.py',
  'lidar_config:='+str(Path(get_package_share_directory('mobile_base_perception'))/'config/lidar.yaml')]]
result={'commands':commands,'duration_s':25,'sources':{},'shutdown':{},'devices_mapped':False}
rclpy.init();node=rclpy.create_node('dual_lidar_verification');buffer=Buffer();listener=TransformListener(buffer,node)
records={s:[] for s in ('fl','br')};last={};latest_msgs={}
def receive(source,msg):
 now=node.get_clock().now().nanoseconds/1e9
 stamp=msg.header.stamp.sec+msg.header.stamp.nanosec/1e9
 ranges=msg.ranges
 valid=sum(math.isfinite(v) and msg.range_min<=v<=msg.range_max for v in ranges)
 records[source].append({'arrival_monotonic':time.monotonic(),'stamp':stamp,'age_s':now-stamp,
  'frame':msg.header.frame_id,'ranges':len(ranges),'valid_ranges':valid,
  'finite_ranges':sum(math.isfinite(v) for v in ranges),
  'tf_at_stamp':buffer.can_transform('base_footprint',msg.header.frame_id,Time.from_msg(msg.header.stamp))})
 last[source]={'frame':msg.header.frame_id,'stamp':stamp,'range_min':msg.range_min,
 'range_max':msg.range_max,'angle_min':msg.angle_min,'angle_max':msg.angle_max,
 'angle_increment':msg.angle_increment,'ranges':list(ranges)}
 latest_msgs[source]=msg
for s in records:node.create_subscription(LaserScan,'/lidar/'+s+'/scan',lambda msg,s=s:receive(s,msg),qos_profile_sensor_data)
try:
 for i,cmd in enumerate(commands):
  log=open(out/('description.log' if i==0 else 'lidar.log'),'w');logs.append(log)
  processes.append(subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True))
 start=time.monotonic()
 while time.monotonic()-start<25:rclpy.spin_once(node,timeout_sec=.05)
 for s,data in records.items():
  topic='/lidar/'+s+'/scan';infos=node.get_publishers_info_by_topic(topic)
  steady=[d for d in data if d['arrival_monotonic']-start>=5]
  rate=(len(steady)-1)/(steady[-1]['arrival_monotonic']-steady[0]['arrival_monotonic']) if len(steady)>1 else None
  summary={'messages':len(data),'steady_messages':len(steady),'arrival_hz':rate,
   'frames':sorted(set(d['frame'] for d in data)),
   'publishers':[{'name':p.node_name,'namespace':p.node_namespace,'reliability':p.qos_profile.reliability.name} for p in infos]}
  if steady:
   summary.update({'steady_age_min_s':min(d['age_s'] for d in steady),'steady_age_max_s':max(d['age_s'] for d in steady),
    'steady_valid_ranges_min':min(d['valid_ranges'] for d in steady),'steady_valid_ranges_max':max(d['valid_ranges'] for d in steady),
    'steady_ranges_lengths':sorted(set(d['ranges'] for d in steady)),
    'steady_tf_at_stamp_ok':sum(d['tf_at_stamp'] for d in steady),'steady_stamp_backsteps':sum(b['stamp']<=a['stamp'] for a,b in zip(steady,steady[1:]))})
  if s in latest_msgs:
   msg=latest_msgs[s]
   t=buffer.lookup_transform('base_footprint',msg.header.frame_id,Time.from_msg(msg.header.stamp)).transform
   summary['base_transform']={'xyz':[t.translation.x,t.translation.y,t.translation.z],
     'quaternion':[t.rotation.x,t.rotation.y,t.rotation.z,t.rotation.w]}
  result['sources'][s]=summary
 result['tf_static_publishers']=len(node.get_publishers_info_by_topic('/tf_static'))
 result['unexpected_motor_nodes']=[name for name,_ in node.get_node_names_and_namespaces() if 'controller_manager' in name]
finally:
 for i,proc in reversed(list(enumerate(processes))):
  if proc.poll() is None:os.killpg(proc.pid,signal.SIGINT)
  try:status=proc.wait(timeout=15)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGKILL);status=proc.wait()
  result['shutdown']['description' if i==0 else 'lidar_parent']=status
 for log in logs:log.close()
 node.destroy_node();rclpy.shutdown()
 (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
 (out/'messages.json').write_text(json.dumps(records,indent=2)+'\n')
 (out/'last_scans.json').write_text(json.dumps(last,indent=2)+'\n')
 print(json.dumps(result,indent=2))
