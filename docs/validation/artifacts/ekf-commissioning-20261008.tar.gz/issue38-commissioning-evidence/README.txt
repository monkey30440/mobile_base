#38 evidence, 2026-10-08, pre-commit f447874 + commissioning working changes.
Image sha256:566d8ff74d6b82a2d112451298c45bcb19b41d5e72bdc62cf3f21fc2273dc552, AGX Thor, native Fast DDS.
installed-static: actual installed component launch + installed EKF YAML, 15s stationary observation, zero initialization only. m1-static.launch.py/ekf.yaml/imu.yaml are historical unused copies; executed installed config provenance is package-config below.
pty-attempt1-failed: test harness key flood and parent SIGINT caused stop/exit deadline; lifecycle cleanup succeeded. No PASS claim.
raised-keyboard-pass: native teleop keyboard, 10Hz key input, forward/reverse0.03m/s2s each, actual PTY Ctrl-C; all components cleaned up. observations count repeated observer checks, not independent message count. Wheel-derived virtual displacement does not prove chassis travel while raised.
Full-suite initially 78/79 due cross-package synthetic IMU topic sharing domain96. Perception rerun isolated domain94 =>79total,zeroerrors/failures. No source change to bypass test.
No ground dynamic fusion, calibrated covariance, bias correction or physical pose accuracy acceptance. Native pal_statistics shutdown invalid-context ERROR lines occur; ros2_control process exits cleanly, M1 deactivation/readback pass.
