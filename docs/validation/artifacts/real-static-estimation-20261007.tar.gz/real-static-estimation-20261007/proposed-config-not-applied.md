# Proposed bounded commissioning uncertainty (not applied)

Wheel twist/pose covariance diagonal: native diff_drive_controller 4.42.1
parameter descriptor suggests [0.001,0.001,0.001,0.001,0.001,0.01] as an initial
configuration, explicitly requiring robot tuning. The runtime default is zeros.
Use only X/Y wheel twist for the initial planar EKF data-chain check; no wheel
pose fusion. Controller odom TF stays false.

IMU published-axis stationary sample variances (rad/s)^2:
[1.8985888085587782e-08,2.3452000408526082e-08,1.6929480098987364e-08].
Stationary means (rad/s):
[0.0006622907874288073,-0.00025919855639001076,-0.0005068743554234622].
Noise variance alone excludes the observed nonzero stationary mean. One explicit
commissioning engineering input is the observed second moment about zero (mean square,
not a calibrated covariance):
[4.576113064280129e-07,9.063136025567312e-08,2.7384782088781707e-07].
No bias correction is introduced. This records why small measured noise is not
claimed to describe total error; unmeasured drift/scale/time/synchronization effects
remain outside these observations. No acceleration/orientation fusion selected.

Operator adoption is pending. No EKF, motor hardware activation or positive
covariance adapter configuration has been started for this preflight.
