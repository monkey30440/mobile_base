import time,json,math,statistics,importlib.util
from pathlib import Path
import serial
spec=importlib.util.spec_from_file_location('packet','/workspace/src/mobile_base_imu/mobile_base_imu/packet.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
root=Path('/evidence');buffer=bytearray();samples=[];chunks=[];invalid=0
with serial.Serial('/dev/fihRobotBaseIMU',115200,timeout=.05,exclusive=True) as bus:
 start=time.monotonic()
 while time.monotonic()-start<30:
  data=bus.read(4096);now=time.monotonic()
  if not data:continue
  chunks.append({'mono':now,'hex':data.hex()});buffer.extend(data)
  while len(buffer)>=59:
   pos=buffer.find(b'\xaa\x55')
   if pos<0:buffer[:]=buffer[-1:] if buffer[-1]==0xaa else b'';break
   if pos:del buffer[:pos]
   if len(buffer)<59:break
   try:a,g=mod.decode(bytes(buffer[:59]),9.81,math.pi/180,[1,2,3])
   except ValueError:invalid+=1;del buffer[0];continue
   samples.append({'mono':now,'acceleration':a,'gyro':g});del buffer[:59]
def stats(ss):
 return {'count':len(ss),'gyro_mean':[statistics.mean(s['gyro'][i] for s in ss) for i in range(3)],'gyro_variance':[statistics.variance(s['gyro'][i] for s in ss) for i in range(3)],'acceleration_mean':[statistics.mean(s['acceleration'][i] for s in ss) for i in range(3)]}
report={'duration_seconds':time.monotonic()-start,'invalid_candidates':invalid,'full':stats(samples),'halves':[stats([s for s in samples if (s['mono']-start<15)==first]) for first in (True,False)],'limits':'Stationary receipt-time sample variance only; no bias correction, timing/production calibration or angle acceptance.'}
(root/'imu-capture.json').write_text(json.dumps({'chunks':chunks,'samples':samples},indent=2)+'\n');(root/'imu-statistics.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
