import importlib.util,time,subprocess,os,signal,yaml,json
from pathlib import Path
import rclpy
root=Path('/evidence');spec=importlib.util.spec_from_file_location('workflow','/workspace/src/mobile_base_m1/test/test_workflow.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);peer=mod.Peer(require_enable=True)
config=yaml.safe_load((root/'rwf.commissioning.yaml').read_text());config['hardware']['serial_port']=peer.path;(root/'softwaregraph.target.yaml').write_text(yaml.safe_dump(config))
rclpy.init();node=rclpy.create_node('native_tf_graph_probe');p=None
try:
 p=subprocess.Popen(['ros2','launch',str(root/'m1-static.launch.py'),'hardware_config:=/evidence/softwaregraph.target.yaml','model_file:=/evidence/model.urdf'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
 end=time.monotonic()+15
 while time.monotonic()<end:
  rclpy.spin_once(node,timeout_sec=.05);names=sorted(i.node_name for i in node.get_publishers_info_by_topic('/tf'))
  if names==['base_controller','robot_state_publisher']:break
 else:raise RuntimeError('native expected TF endpoint graph missing')
 (root/'native-controller-tf-graph.json').write_text(json.dumps({'publishers':names,'hardware':'PTY only; no physical devices'},indent=2));print(names)
finally:
 if p is not None and p.poll() is None:os.killpg(p.pid,signal.SIGINT);p.wait(timeout=8)
 peer.close();node.destroy_node();rclpy.shutdown()
