"""Retain the exact second-moment derivation after passive capture."""
import json
from pathlib import Path
p=Path('/evidence/imu-statistics.json')
d=json.loads(p.read_text());full=d['full']
d['observed_gyro_second_moment_about_zero']=[(full['count']-1)/full['count']*v+m*m for v,m in zip(full['gyro_variance'],full['gyro_mean'])]
p.write_text(json.dumps(d,indent=2)+'\n')
