import json,os,signal,subprocess,time,math,sys
from pathlib import Path
import rclpy,yaml
from sensor_msgs.msg import JointState
from tf2_msgs.msg import TFMessage
from rosidl_runtime_py.set_message import set_message_fields
root=Path('/evidence');data=json.loads((root/'replay-joints.json').read_text())
if len(sys.argv)>1 and sys.argv[1]=='finite-fixture':data['position']=[0.0]*len(data['name'])
params=root/'repro-rsp.yaml';params.write_text(yaml.safe_dump({'robot_state_publisher':{'ros__parameters':{'robot_description':(root/'model.urdf').read_text()}}}))
rclpy.init();node=rclpy.create_node('recorded_joint_replay');pub=node.create_publisher(JointState,'/joint_states',10);transforms=[]
def callback(msg,info):
 transforms.extend(msg.transforms)
 (root/'jazzy-message-info.json').write_text(json.dumps({'type':str(type(info)),'keys':list(info.keys())},indent=2))
node.create_subscription(TFMessage,'/tf',callback,20)
process=None
try:
 process=subprocess.Popen(['ros2','run','robot_state_publisher','robot_state_publisher','--ros-args','--params-file',str(params)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
 end=time.monotonic()+5
 while pub.get_subscription_count()==0 and time.monotonic()<end:rclpy.spin_once(node,timeout_sec=.02)
 if pub.get_subscription_count()==0:raise RuntimeError('RSP subscriber missing')
 msg=JointState();set_message_fields(msg,data)
 end=time.monotonic()+.8
 while time.monotonic()<end:
  msg.header.stamp=node.get_clock().now().to_msg();pub.publish(msg);rclpy.spin_once(node,timeout_sec=.05)
 wheel=[t for t in transforms if t.child_frame_id in ('driving_wheel_link_L','driving_wheel_link_R')]
 bad=[t.child_frame_id for t in wheel if not all(math.isfinite(v) for v in (t.transform.translation.x,t.transform.translation.y,t.transform.translation.z,t.transform.rotation.x,t.transform.rotation.y,t.transform.rotation.z,t.transform.rotation.w))]
 print(json.dumps({'wheel_transforms':len(wheel),'invalid_frames':sorted(set(bad))}));assert wheel and not bad,'invalid wheel TF from recorded JointState'
finally:
 if process is not None and process.poll() is None:os.killpg(process.pid,signal.SIGINT);process.wait(timeout=5)
 node.destroy_node();rclpy.shutdown()
