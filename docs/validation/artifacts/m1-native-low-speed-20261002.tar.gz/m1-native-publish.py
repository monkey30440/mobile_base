import json,time
from pathlib import Path
import rclpy
from geometry_msgs.msg import TwistStamped
root=Path('/evidence');commands=[]
rclpy.init();node=rclpy.create_node('m1_bounded_forward_publisher');pub=node.create_publisher(TwistStamped,'/base_controller/cmd_vel',10)
def emit(value):
 msg=TwistStamped();msg.header.stamp=node.get_clock().now().to_msg();msg.twist.linear.x=value
 pub.publish(msg);commands.append({'time_monotonic':time.monotonic(),'linear_x':value,'angular_z':0.0})
try:
 deadline=time.monotonic()+3
 while pub.get_subscription_count()==0:
  rclpy.spin_once(node,timeout_sec=.02)
  if time.monotonic()>deadline:raise RuntimeError('no native subscriber; no motion')
 start=time.monotonic()
 for i in range(20):
  if (root/'m1-observation-abort').exists():raise RuntimeError('observer aborted')
  if time.monotonic()-start>=2:break
  emit(.03)
  end=start+(i+1)*.1
  while time.monotonic()<end:rclpy.spin_once(node,timeout_sec=min(.02,end-time.monotonic()))
finally:
 emit(0.0)
 end=time.monotonic()+.7
 while time.monotonic()<end:rclpy.spin_once(node,timeout_sec=.02)
 (root/'m1-native-commands.json').write_text(json.dumps(commands,indent=2))
 (root/'finish-m1-observation').write_text('publisher stopped; explicitzero+.7s timeout wait')
 node.destroy_node();rclpy.shutdown()
