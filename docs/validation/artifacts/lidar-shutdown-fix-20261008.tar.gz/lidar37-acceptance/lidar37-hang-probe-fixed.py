import subprocess,time,signal,os,re,json
from pathlib import Path
root=Path('/tmp/lidar37-hang-fixed');root.mkdir(exist_ok=True);results=[]
for cycle in range(12):
 log=(root/f'{cycle}.log').open('w')
 p=subprocess.Popen(['ros2','launch','mobile_base_perception','dual_picoscan.launch.py','fl_hostname:=127.0.0.2','br_hostname:=127.0.0.3','udp_receiver_ip:=127.0.0.1','fl_udp_port:=33115','br_udp_port:=33116','fl_check_udp_port:=33117','br_check_udp_port:=33118','listen_only_mode:=True'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'ROS_DOMAIN_ID':str(190+cycle)})
 time.sleep(.8)
 rows=subprocess.check_output(['ps','-eo','pid=,args='],text=True).splitlines()
 children=[int(row.split()[0]) for row in rows if '/sick_generic_caller ' in row and 'hostname:=127.0.0.' in row]
 p.send_signal(signal.SIGINT)
 try:p.wait(timeout=3);hung=False
 except subprocess.TimeoutExpired:
  hung=True
  for child in children:
   with (root/f'{cycle}-{child}.gdb').open('w') as trace:
    subprocess.run(['gdb','-batch','-ex','set pagination off','-ex','thread apply all bt','-p',str(child)],stdout=trace,stderr=subprocess.STDOUT,timeout=10)
  for child in children:
   try:os.kill(child,signal.SIGKILL)
   except ProcessLookupError:pass
  p.wait(timeout=8)
 log.close();text=(root/f'{cycle}.log').read_text();results.append({'cycle':cycle,'hung':hung,'parent':p.returncode,'clean_children':text.count('process has finished cleanly'),'crashed_children':text.count('process has died')});print(results[-1],flush=True)
 if hung:break
(root/'results.json').write_text(json.dumps(results,indent=2))

assert len(results)==12 and all(not x['hung'] and x['parent']==0 and x['clean_children']==2 and x['crashed_children']==0 for x in results),results
