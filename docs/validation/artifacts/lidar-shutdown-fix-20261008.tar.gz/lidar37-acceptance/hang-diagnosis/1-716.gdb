[New LWP 747]
[New LWP 746]
[New LWP 744]
[New LWP 743]
[New LWP 741]
[New LWP 738]
[New LWP 736]
[New LWP 735]
[New LWP 732]
[New LWP 731]
[New LWP 728]
[New LWP 726]
[New LWP 721]
[New LWP 720]
[New LWP 718]
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/aarch64-linux-gnu/libthread_db.so.1".
0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 16 (Thread 0xffff974ee040 (LWP 718) "sick_generi-ust"):
#0  0x0000ffff980e97a4 in syscall () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff97a4992c in ?? () from /lib/aarch64-linux-gnu/liblttng-ust.so.1
#2  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#3  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 15 (Thread 0xffff96cde040 (LWP 720) "sick_generi-ust"):
#0  0x0000ffff980e97a4 in syscall () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff97a4992c in ?? () from /lib/aarch64-linux-gnu/liblttng-ust.so.1
#2  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#3  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 14 (Thread 0xffff952ee040 (LWP 721) "sick_generic_ca"):
#0  0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98085140 in pthread_cond_clockwait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff97b841cc in ?? () from /opt/ros/jazzy/lib/librcl_logging_spdlog.so
#3  0x0000ffff98391ae0 [PAC] in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#4  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 13 (Thread 0xffff94ade040 (LWP 726) "dds.shm.wdog"):
#0  0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98085140 in pthread_cond_clockwait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff95eb4e18 in void* eprosima::thread::ThreadProxy<eprosima::create_thread<eprosima::fastdds::rtps::SharedMemWatchdog::SharedMemWatchdog()::{lambda()#1}>(eprosima::fastdds::rtps::SharedMemWatchdog::SharedMemWatchdog()::{lambda()#1}, eprosima::fastdds::rtps::ThreadSettings const&, char const*)::{lambda()#1}>(void*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#4  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 12 (Thread 0xffff8fffe040 (LWP 728) "dds.ev.0"):
#0  0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98085140 in pthread_cond_clockwait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff95b8650c in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95b87704 [PAC] in eprosima::fastrtps::rtps::ResourceEvent::event_service() () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff95b8c5a4 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#5  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#6  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 11 (Thread 0xffff8f7ee040 (LWP 731) "dds.udp.55162"):
#0  0x0000ffff980ee518 in recvfrom () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff95cbea54 in eprosima::fastdds::rtps::UDPChannelResource::Receive(unsigned char*, unsigned int, unsigned int&, eprosima::fastrtps::rtps::Locator_t&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#2  0x0000ffff95cbef28 [PAC] in eprosima::fastdds::rtps::UDPChannelResource::perform_listen_operation(eprosima::fastrtps::rtps::Locator_t) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95cc1334 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 10 (Thread 0xffff8efde040 (LWP 732) "dds.udp.55150"):
#0  0x0000ffff980ee518 in recvfrom () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff95cbea54 in eprosima::fastdds::rtps::UDPChannelResource::Receive(unsigned char*, unsigned int, unsigned int&, eprosima::fastrtps::rtps::Locator_t&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#2  0x0000ffff95cbef28 [PAC] in eprosima::fastdds::rtps::UDPChannelResource::perform_listen_operation(eprosima::fastrtps::rtps::Locator_t) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95cc1334 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 9 (Thread 0xffff8e7ce040 (LWP 735) "dds.shm.55163"):
#0  0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff9808e028 in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff95bc5b04 in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95eaef38 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff95eafbd0 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#5  0x0000ffff95eabffc [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#6  0x0000ffff95eb4fe4 [PAC] in void* eprosima::thread::ThreadProxy<eprosima::create_thread<eprosima::fastdds::rtps::SharedMemChannelResource::init_thread(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastdds::rtps::ThreadSettings const&)::{lambda()#1}, unsigned int>(eprosima::fastdds::rtps::SharedMemChannelResource::init_thread(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastdds::rtps::ThreadSettings const&)::{lambda()#1}, eprosima::fastdds::rtps::ThreadSettings const&, char const*, unsigned int)::{lambda()#1}>(void*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#7  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#8  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 8 (Thread 0xffff8dfbe040 (LWP 736) "dds.udp.55163"):
#0  0x0000ffff980ee518 in recvfrom () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff95cbea54 in eprosima::fastdds::rtps::UDPChannelResource::Receive(unsigned char*, unsigned int, unsigned int&, eprosima::fastrtps::rtps::Locator_t&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#2  0x0000ffff95cbef28 [PAC] in eprosima::fastdds::rtps::UDPChannelResource::perform_listen_operation(eprosima::fastrtps::rtps::Locator_t) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95cc1334 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 7 (Thread 0xffff8d7ae040 (LWP 738) "dds.asyn.0.0"):
#0  0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98084b20 in pthread_cond_wait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff95b8687c in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95de6790 [PAC] in void* eprosima::thread::ThreadProxy<eprosima::create_thread<eprosima::fastdds::rtps::FlowControllerImpl<eprosima::fastdds::rtps::FlowControllerSyncPublishMode, eprosima::fastdds::rtps::FlowControllerFifoSchedule>::initialize_async_thread<eprosima::fastdds::rtps::FlowControllerSyncPublishMode>()::{lambda()#1}, unsigned int, unsigned int>(eprosima::fastdds::rtps::FlowControllerImpl<eprosima::fastdds::rtps::FlowControllerSyncPublishMode, eprosima::fastdds::rtps::FlowControllerFifoSchedule>::initialize_async_thread<eprosima::fastdds::rtps::FlowControllerSyncPublishMode>()::{lambda()#1}, eprosima::fastdds::rtps::ThreadSettings const&, char const*, unsigned int, unsigned int)::{lambda()#1}>(void*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 6 (Thread 0xffff8cf9e040 (LWP 741) "dds.shm.7001"):
#0  0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff9808e028 in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff95bc5b04 in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95eaef38 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff95eafbd0 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#5  0x0000ffff95eabffc [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#6  0x0000ffff95eb4fe4 [PAC] in void* eprosima::thread::ThreadProxy<eprosima::create_thread<eprosima::fastdds::rtps::SharedMemChannelResource::init_thread(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastdds::rtps::ThreadSettings const&)::{lambda()#1}, unsigned int>(eprosima::fastdds::rtps::SharedMemChannelResource::init_thread(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastdds::rtps::ThreadSettings const&)::{lambda()#1}, eprosima::fastdds::rtps::ThreadSettings const&, char const*, unsigned int)::{lambda()#1}>(void*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#7  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#8  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 5 (Thread 0xffff8c78e040 (LWP 743) "dds.udp.7002"):
#0  0x0000ffff980ee518 in recvfrom () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff95cbea54 in eprosima::fastdds::rtps::UDPChannelResource::Receive(unsigned char*, unsigned int, unsigned int&, eprosima::fastrtps::rtps::Locator_t&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#2  0x0000ffff95cbef28 [PAC] in eprosima::fastdds::rtps::UDPChannelResource::perform_listen_operation(eprosima::fastrtps::rtps::Locator_t) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95cc1334 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 4 (Thread 0xffff8bf7e040 (LWP 744) "sick_generic_ca"):
#0  0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98084b20 in pthread_cond_wait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff95d88c78 in eprosima::fastdds::dds::detail::WaitSetImpl::wait(std::vector<eprosima::fastdds::dds::Condition*, std::allocator<eprosima::fastdds::dds::Condition*> >&, eprosima::fastrtps::Time_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95d88d6c [PAC] in eprosima::fastdds::dds::WaitSet::wait(std::vector<eprosima::fastdds::dds::Condition*, std::allocator<eprosima::fastdds::dds::Condition*> >&, eprosima::fastrtps::Time_t) const () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff963d09d4 [PAC] in rmw_fastrtps_shared_cpp::__rmw_wait(char const*, rmw_subscriptions_s*, rmw_guard_conditions_s*, rmw_services_s*, rmw_clients_s*, rmw_events_s*, rmw_wait_set_s*, rmw_time_s const*) () from /opt/ros/jazzy/lib/librmw_fastrtps_shared_cpp.so
#5  0x0000ffff963b8cb0 [PAC] in ?? () from /opt/ros/jazzy/lib/librmw_fastrtps_shared_cpp.so
#6  0x0000ffff98391ae0 [PAC] in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#7  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#8  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 3 (Thread 0xffff8b54e040 (LWP 746) "sick_generic_ca"):
#0  0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98087348 in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff98391bc4 in std::thread::join() () from /lib/aarch64-linux-gnu/libstdc++.so.6
#3  0x0000aaaab86d1e44 [PAC] in sick_scansegment_xd::MsgPackThreads::join() ()
#4  0x0000aaaab86d29f4 in sick_scansegment_xd::run(std::shared_ptr<rclcpp::Node>, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) ()
#5  0x0000aaaab84dc31c in mainGenericLaserInternal(int, char**, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<rclcpp::Node>, bool, int&) ()
#6  0x0000aaaab84f3cb8 in GenericLaserCallable::mainGenericLaserCb() ()
#7  0x0000ffff98391ae0 in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#8  0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#9  0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 2 (Thread 0xffff8ad3e040 (LWP 747) "sick_generic_ca"):
#0  0x0000ffff9808216c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98088c74 in pthread_mutex_lock () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff964480cc in rmw_create_service () from /opt/ros/jazzy/lib/librmw_fastrtps_cpp.so
#3  0x0000ffff986fc0bc [PAC] in rcl_service_init () from /opt/ros/jazzy/lib/librcl.so
#4  0x0000ffff986f0780 [PAC] in rcl_node_type_description_service_init () from /opt/ros/jazzy/lib/librcl.so
#5  0x0000ffff988e3944 [PAC] in ?? () from /opt/ros/jazzy/lib/librclcpp.so
#6  0x0000ffff988e4730 [PAC] in rclcpp::node_interfaces::NodeTypeDescriptions::NodeTypeDescriptions(std::shared_ptr<rclcpp::node_interfaces::NodeBaseInterface>, std::shared_ptr<rclcpp::node_interfaces::NodeLoggingInterface>, std::shared_ptr<rclcpp::node_interfaces::NodeParametersInterface>, std::shared_ptr<rclcpp::node_interfaces::NodeServicesInterface>) () from /opt/ros/jazzy/lib/librclcpp.so
#7  0x0000ffff988bc578 [PAC] in rclcpp::Node::Node(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::NodeOptions const&) () from /opt/ros/jazzy/lib/librclcpp.so
#8  0x0000ffff988bd1d4 [PAC] in rclcpp::Node::Node(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::NodeOptions const&) () from /opt/ros/jazzy/lib/librclcpp.so
#9  0x0000aaaab87b2b48 [PAC] in sick_scansegment_xd::RosMsgpackPublisher::RosMsgpackPublisher(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, sick_scansegment_xd::Config const&) ()
#10 0x0000aaaab86d3c50 in sick_scansegment_xd::MsgPackThreads::runThreadCb() ()
#11 0x0000ffff98391ae0 in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#12 0x0000ffff9808595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#13 0x0000ffff980ebb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 1 (Thread 0xffff98b2b020 (LWP 716) "sick_generic_ca"):
#0  0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98087348 in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff98391bc4 in std::thread::join() () from /lib/aarch64-linux-gnu/libstdc++.so.6
#3  0x0000aaaab84d5c5c [PAC] in stopScannerAndExit(bool) ()
#4  0x0000aaaab84d6a44 in rosSignalHandler(int) ()
#5  <signal handler called>
#6  0x0000ffff98081e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#7  0x0000ffff98084b20 in pthread_cond_wait () from /lib/aarch64-linux-gnu/libc.so.6
#8  0x0000ffff95be3f9c in eprosima::fastrtps::rtps::MessageReceiver::removeEndpoint(eprosima::fastrtps::rtps::Endpoint*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#9  0x0000ffff95c02da8 [PAC] in eprosima::fastrtps::rtps::RTPSParticipantImpl::deleteUserEndpoint(eprosima::fastrtps::rtps::GUID_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#10 0x0000ffff95c10b98 [PAC] in eprosima::fastrtps::rtps::RTPSDomainImpl::removeRTPSWriter(eprosima::fastrtps::rtps::RTPSWriter*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#11 0x0000ffff95c2f6ec [PAC] in eprosima::fastdds::dds::DataWriterImpl::~DataWriterImpl() () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#12 0x0000ffff95e74808 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#13 0x0000ffff95c45d00 [PAC] in eprosima::fastdds::dds::PublisherImpl::delete_datawriter(eprosima::fastdds::dds::DataWriter const*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#14 0x0000ffff963cf414 [PAC] in rmw_fastrtps_shared_cpp::__rmw_destroy_service(char const*, rmw_node_s*, rmw_service_s*) () from /opt/ros/jazzy/lib/librmw_fastrtps_shared_cpp.so
#15 0x0000ffff986fde3c [PAC] in rcl_service_fini () from /opt/ros/jazzy/lib/librcl.so
#16 0x0000aaaab8659150 [PAC] in rclcpp::Service<sick_scan_xd::srv::LIDoutputstateSrv>::Service(std::shared_ptr<rcl_node_s>, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::AnyServiceCallback<sick_scan_xd::srv::LIDoutputstateSrv>, rcl_service_options_s&)::{lambda(rcl_service_s*)#1}::operator()(rcl_service_s*) const ()
#17 0x0000aaaab8659468 in std::_Sp_counted_deleter<rcl_service_s*, rclcpp::Service<sick_scan_xd::srv::LIDoutputstateSrv>::Service(std::shared_ptr<rcl_node_s>, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::AnyServiceCallback<sick_scan_xd::srv::LIDoutputstateSrv>, rcl_service_options_s&)::{lambda(rcl_service_s*)#1}, std::allocator<void>, (__gnu_cxx::_Lock_policy)2>::_M_dispose() ()
#18 0x0000aaaab8656310 in std::_Sp_counted_ptr_inplace<rclcpp::Service<sick_scan_xd::srv::LIDoutputstateSrv>, std::allocator<void>, (__gnu_cxx::_Lock_policy)2>::_M_dispose() ()
#19 0x0000ffff98860e90 in ?? () from /opt/ros/jazzy/lib/librclcpp.so
#20 0x0000ffff9887b378 [PAC] in ?? () from /opt/ros/jazzy/lib/librclcpp.so
#21 0x0000ffff9887e99c [PAC] in rclcpp::Executor::wait_for_work(std::chrono::duration<long, std::ratio<1l, 1000000000l> >) () from /opt/ros/jazzy/lib/librclcpp.so
#22 0x0000ffff9887f460 [PAC] in rclcpp::Executor::get_next_executable(rclcpp::AnyExecutable&, std::chrono::duration<long, std::ratio<1l, 1000000000l> >) () from /opt/ros/jazzy/lib/librclcpp.so
#23 0x0000ffff9889163c [PAC] in rclcpp::executors::SingleThreadedExecutor::spin() () from /opt/ros/jazzy/lib/librclcpp.so
#24 0x0000ffff98889c9c [PAC] in rclcpp::spin(std::shared_ptr<rclcpp::node_interfaces::NodeBaseInterface>) () from /opt/ros/jazzy/lib/librclcpp.so
#25 0x0000ffff98889e20 [PAC] in rclcpp::spin(std::shared_ptr<rclcpp::Node>) () from /opt/ros/jazzy/lib/librclcpp.so
#26 0x0000aaaab84d0580 [PAC] in main ()
[Inferior 1 (process 716) detached]
