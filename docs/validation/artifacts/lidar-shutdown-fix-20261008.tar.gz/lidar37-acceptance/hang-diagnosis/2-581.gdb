[New LWP 843]
[New LWP 842]
[New LWP 841]
[New LWP 613]
[New LWP 611]
[New LWP 608]
[New LWP 606]
[New LWP 605]
[New LWP 604]
[New LWP 602]
[New LWP 601]
[New LWP 598]
[New LWP 597]
[New LWP 594]
[New LWP 592]
[New LWP 588]
[New LWP 586]
[New LWP 585]
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/aarch64-linux-gnu/libthread_db.so.1".
0x0000ffff98431e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 19 (Thread 0xffff9789e040 (LWP 585) "sick_generi-ust"):
#0  0x0000ffff984997a4 in syscall () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff97df992c in ?? () from /lib/aarch64-linux-gnu/liblttng-ust.so.1
#2  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#3  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 18 (Thread 0xffff9708e040 (LWP 586) "sick_generi-ust"):
#0  0x0000ffff984997a4 in syscall () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff97df992c in ?? () from /lib/aarch64-linux-gnu/liblttng-ust.so.1
#2  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#3  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 17 (Thread 0xffff9569e040 (LWP 588) "sick_generic_ca"):
#0  0x0000ffff98431e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98435140 in pthread_cond_clockwait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff97f341cc in ?? () from /opt/ros/jazzy/lib/librcl_logging_spdlog.so
#3  0x0000ffff98741ae0 [PAC] in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#4  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 16 (Thread 0xffff94e8e040 (LWP 592) "dds.shm.wdog"):
#0  0x0000ffff98431e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98435140 in pthread_cond_clockwait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff96264e18 in void* eprosima::thread::ThreadProxy<eprosima::create_thread<eprosima::fastdds::rtps::SharedMemWatchdog::SharedMemWatchdog()::{lambda()#1}>(eprosima::fastdds::rtps::SharedMemWatchdog::SharedMemWatchdog()::{lambda()#1}, eprosima::fastdds::rtps::ThreadSettings const&, char const*)::{lambda()#1}>(void*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#4  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 15 (Thread 0xffff8fffe040 (LWP 594) "dds.ev.0"):
#0  0x0000ffff98431e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98435140 in pthread_cond_clockwait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff95f3650c in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95f37704 [PAC] in eprosima::fastrtps::rtps::ResourceEvent::event_service() () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff95f3c5a4 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#5  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#6  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 14 (Thread 0xffff8f7ee040 (LWP 597) "dds.udp.55412"):
#0  0x0000ffff9843216c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98438cd8 in pthread_mutex_lock () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff96146680 in eprosima::fastrtps::rtps::PDP::removeReaderProxyData(eprosima::fastrtps::rtps::GUID_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff96165f34 [PAC] in eprosima::fastrtps::rtps::EDPSimpleSUBListener::onNewCacheChangeAdded(eprosima::fastrtps::rtps::RTPSReader*, eprosima::fastrtps::rtps::CacheChange_t const*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff95f7c370 [PAC] in eprosima::fastrtps::rtps::StatefulReader::NotifyChanges(eprosima::fastrtps::rtps::WriterProxy*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#5  0x0000ffff95f7cd14 [PAC] in eprosima::fastrtps::rtps::StatefulReader::change_received(eprosima::fastrtps::rtps::CacheChange_t*, eprosima::fastrtps::rtps::WriterProxy*, unsigned long) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#6  0x0000ffff95f7d30c [PAC] in eprosima::fastrtps::rtps::StatefulReader::processDataMsg(eprosima::fastrtps::rtps::CacheChange_t*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#7  0x0000ffff95f91ba4 [PAC] in eprosima::fastrtps::rtps::MessageReceiver::process_data_message_without_security(eprosima::fastrtps::rtps::EntityId_t const&, eprosima::fastrtps::rtps::CacheChange_t&, bool) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#8  0x0000ffff95f97c48 [PAC] in eprosima::fastrtps::rtps::MessageReceiver::proc_Submsg_Data(eprosima::fastrtps::rtps::CDRMessage_t*, eprosima::fastrtps::rtps::SubmessageHeader_t*, eprosima::fastrtps::rtps::EntityId_t&, bool) const () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#9  0x0000ffff95f98d9c [PAC] in eprosima::fastrtps::rtps::MessageReceiver::processCDRMsg(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::CDRMessage_t*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#10 0x0000ffff95fa0148 [PAC] in eprosima::fastrtps::rtps::ReceiverResource::OnDataReceived(unsigned char const*, unsigned int, eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::Locator_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#11 0x0000ffff9606ef50 [PAC] in eprosima::fastdds::rtps::UDPChannelResource::perform_listen_operation(eprosima::fastrtps::rtps::Locator_t) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#12 0x0000ffff96071334 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#13 0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#14 0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 13 (Thread 0xffff8efde040 (LWP 598) "dds.udp.55400"):
#0  0x0000ffff9843216c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98438cd8 in pthread_mutex_lock () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff96147c94 in eprosima::fastrtps::rtps::PDP::remove_remote_participant(eprosima::fastrtps::rtps::GUID_t const&, eprosima::fastrtps::rtps::ParticipantDiscoveryInfo::DISCOVERY_STATUS) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff961547bc [PAC] in eprosima::fastrtps::rtps::PDPListener::onNewCacheChangeAdded(eprosima::fastrtps::rtps::RTPSReader*, eprosima::fastrtps::rtps::CacheChange_t const*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff95f84354 [PAC] in eprosima::fastrtps::rtps::StatelessReader::change_received(eprosima::fastrtps::rtps::CacheChange_t*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#5  0x0000ffff95f84f64 [PAC] in eprosima::fastrtps::rtps::StatelessReader::processDataMsg(eprosima::fastrtps::rtps::CacheChange_t*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#6  0x0000ffff95f91ba4 [PAC] in eprosima::fastrtps::rtps::MessageReceiver::process_data_message_without_security(eprosima::fastrtps::rtps::EntityId_t const&, eprosima::fastrtps::rtps::CacheChange_t&, bool) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#7  0x0000ffff95f97c48 [PAC] in eprosima::fastrtps::rtps::MessageReceiver::proc_Submsg_Data(eprosima::fastrtps::rtps::CDRMessage_t*, eprosima::fastrtps::rtps::SubmessageHeader_t*, eprosima::fastrtps::rtps::EntityId_t&, bool) const () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#8  0x0000ffff95f98d9c [PAC] in eprosima::fastrtps::rtps::MessageReceiver::processCDRMsg(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::CDRMessage_t*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#9  0x0000ffff95fa0148 [PAC] in eprosima::fastrtps::rtps::ReceiverResource::OnDataReceived(unsigned char const*, unsigned int, eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::Locator_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#10 0x0000ffff9606ef50 [PAC] in eprosima::fastdds::rtps::UDPChannelResource::perform_listen_operation(eprosima::fastrtps::rtps::Locator_t) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#11 0x0000ffff96071334 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#12 0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#13 0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 12 (Thread 0xffff8e7ce040 (LWP 601) "dds.shm.55413"):
#0  0x0000ffff9843216c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98438cd8 in pthread_mutex_lock () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff96147e28 in eprosima::fastrtps::rtps::PDP::assert_remote_participant_liveliness(eprosima::fastrtps::rtps::GuidPrefix_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95f98d34 [PAC] in eprosima::fastrtps::rtps::MessageReceiver::processCDRMsg(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::CDRMessage_t*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff95fa0148 [PAC] in eprosima::fastrtps::rtps::ReceiverResource::OnDataReceived(unsigned char const*, unsigned int, eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::Locator_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#5  0x0000ffff9625c108 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#6  0x0000ffff96264fe4 [PAC] in void* eprosima::thread::ThreadProxy<eprosima::create_thread<eprosima::fastdds::rtps::SharedMemChannelResource::init_thread(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastdds::rtps::ThreadSettings const&)::{lambda()#1}, unsigned int>(eprosima::fastdds::rtps::SharedMemChannelResource::init_thread(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastdds::rtps::ThreadSettings const&)::{lambda()#1}, eprosima::fastdds::rtps::ThreadSettings const&, char const*, unsigned int)::{lambda()#1}>(void*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#7  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#8  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 11 (Thread 0xffff8dfbe040 (LWP 602) "dds.udp.55413"):
#0  0x0000ffff9849e518 in recvfrom () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff9606ea54 in eprosima::fastdds::rtps::UDPChannelResource::Receive(unsigned char*, unsigned int, unsigned int&, eprosima::fastrtps::rtps::Locator_t&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#2  0x0000ffff9606ef28 [PAC] in eprosima::fastdds::rtps::UDPChannelResource::perform_listen_operation(eprosima::fastrtps::rtps::Locator_t) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff96071334 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 10 (Thread 0xffff8d7ae040 (LWP 604) "dds.asyn.0.0"):
#0  0x0000ffff98431e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98434b20 in pthread_cond_wait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff95f3687c in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff96196790 [PAC] in void* eprosima::thread::ThreadProxy<eprosima::create_thread<eprosima::fastdds::rtps::FlowControllerImpl<eprosima::fastdds::rtps::FlowControllerSyncPublishMode, eprosima::fastdds::rtps::FlowControllerFifoSchedule>::initialize_async_thread<eprosima::fastdds::rtps::FlowControllerSyncPublishMode>()::{lambda()#1}, unsigned int, unsigned int>(eprosima::fastdds::rtps::FlowControllerImpl<eprosima::fastdds::rtps::FlowControllerSyncPublishMode, eprosima::fastdds::rtps::FlowControllerFifoSchedule>::initialize_async_thread<eprosima::fastdds::rtps::FlowControllerSyncPublishMode>()::{lambda()#1}, eprosima::fastdds::rtps::ThreadSettings const&, char const*, unsigned int, unsigned int)::{lambda()#1}>(void*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 9 (Thread 0xffff8cf9e040 (LWP 605) "dds.shm.7000"):
#0  0x0000ffff9843216c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98438cd8 in pthread_mutex_lock () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff96147e28 in eprosima::fastrtps::rtps::PDP::assert_remote_participant_liveliness(eprosima::fastrtps::rtps::GuidPrefix_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff95f98d34 [PAC] in eprosima::fastrtps::rtps::MessageReceiver::processCDRMsg(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::CDRMessage_t*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff95fa0148 [PAC] in eprosima::fastrtps::rtps::ReceiverResource::OnDataReceived(unsigned char const*, unsigned int, eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastrtps::rtps::Locator_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#5  0x0000ffff9625c108 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#6  0x0000ffff96264fe4 [PAC] in void* eprosima::thread::ThreadProxy<eprosima::create_thread<eprosima::fastdds::rtps::SharedMemChannelResource::init_thread(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastdds::rtps::ThreadSettings const&)::{lambda()#1}, unsigned int>(eprosima::fastdds::rtps::SharedMemChannelResource::init_thread(eprosima::fastrtps::rtps::Locator_t const&, eprosima::fastdds::rtps::ThreadSettings const&)::{lambda()#1}, eprosima::fastdds::rtps::ThreadSettings const&, char const*, unsigned int)::{lambda()#1}>(void*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#7  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#8  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 8 (Thread 0xffff87ffe040 (LWP 606) "dds.udp.7000"):
#0  0x0000ffff9849e518 in recvfrom () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff9606ea54 in eprosima::fastdds::rtps::UDPChannelResource::Receive(unsigned char*, unsigned int, unsigned int&, eprosima::fastrtps::rtps::Locator_t&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#2  0x0000ffff9606ef28 [PAC] in eprosima::fastdds::rtps::UDPChannelResource::perform_listen_operation(eprosima::fastrtps::rtps::Locator_t) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff96071334 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 7 (Thread 0xffff877ee040 (LWP 608) "sick_generic_ca"):
#0  0x0000ffff98431e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98434b20 in pthread_cond_wait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff96138c78 in eprosima::fastdds::dds::detail::WaitSetImpl::wait(std::vector<eprosima::fastdds::dds::Condition*, std::allocator<eprosima::fastdds::dds::Condition*> >&, eprosima::fastrtps::Time_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#3  0x0000ffff96138d6c [PAC] in eprosima::fastdds::dds::WaitSet::wait(std::vector<eprosima::fastdds::dds::Condition*, std::allocator<eprosima::fastdds::dds::Condition*> >&, eprosima::fastrtps::Time_t) const () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#4  0x0000ffff967809d4 [PAC] in rmw_fastrtps_shared_cpp::__rmw_wait(char const*, rmw_subscriptions_s*, rmw_guard_conditions_s*, rmw_services_s*, rmw_clients_s*, rmw_events_s*, rmw_wait_set_s*, rmw_time_s const*) () from /opt/ros/jazzy/lib/librmw_fastrtps_shared_cpp.so
#5  0x0000ffff96768cb0 [PAC] in ?? () from /opt/ros/jazzy/lib/librmw_fastrtps_shared_cpp.so
#6  0x0000ffff98741ae0 [PAC] in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#7  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#8  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 6 (Thread 0xffff86fde040 (LWP 611) "sick_generic_ca"):
#0  0x0000ffff98431e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98437348 in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff98741bc4 in std::thread::join() () from /lib/aarch64-linux-gnu/libstdc++.so.6
#3  0x0000aaaac6641e44 [PAC] in sick_scansegment_xd::MsgPackThreads::join() ()
#4  0x0000aaaac66429f4 in sick_scansegment_xd::run(std::shared_ptr<rclcpp::Node>, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) ()
#5  0x0000aaaac644c31c in mainGenericLaserInternal(int, char**, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<rclcpp::Node>, bool, int&) ()
#6  0x0000aaaac6463cb8 in GenericLaserCallable::mainGenericLaserCb() ()
#7  0x0000ffff98741ae0 in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#8  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#9  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 5 (Thread 0xffff867ce040 (LWP 613) "sick_generic_ca"):
#0  0x0000ffff9843216c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98438c74 in pthread_mutex_lock () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff967f80cc in rmw_create_service () from /opt/ros/jazzy/lib/librmw_fastrtps_cpp.so
#3  0x0000ffff98aac0bc [PAC] in rcl_service_init () from /opt/ros/jazzy/lib/librcl.so
#4  0x0000aaaac65d44e4 [PAC] in rclcpp::Service<sick_scan_xd::srv::SCdevicestateSrv>::Service(std::shared_ptr<rcl_node_s>, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::AnyServiceCallback<sick_scan_xd::srv::SCdevicestateSrv>, rcl_service_options_s&) ()
#5  0x0000aaaac65d4e04 in rclcpp::Service<sick_scan_xd::srv::SCdevicestateSrv>::SharedPtr rclcpp::create_service<sick_scan_xd::srv::SCdevicestateSrv, std::_Bind<bool (sick_scan_xd::SickScanServices::*(sick_scan_xd::SickScanServices*, std::_Placeholder<1>, std::_Placeholder<2>))(std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Request_<std::allocator<void> > >, std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Response_<std::allocator<void> > >)> >(std::shared_ptr<rclcpp::node_interfaces::NodeBaseInterface>, std::shared_ptr<rclcpp::node_interfaces::NodeServicesInterface>, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, std::_Bind<bool (sick_scan_xd::SickScanServices::*(sick_scan_xd::SickScanServices*, std::_Placeholder<1>, std::_Placeholder<2>))(std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Request_<std::allocator<void> > >, std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Response_<std::allocator<void> > >)>&&, rmw_qos_profile_s const&, std::shared_ptr<rclcpp::CallbackGroup>) ()
#6  0x0000aaaac65d53b8 in rclcpp::Service<sick_scan_xd::srv::SCdevicestateSrv>::SharedPtr rclcpp::create_service<sick_scan_xd::srv::SCdevicestateSrv, std::_Bind<bool (sick_scan_xd::SickScanServices::*(sick_scan_xd::SickScanServices*, std::_Placeholder<1>, std::_Placeholder<2>))(std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Request_<std::allocator<void> > >, std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Response_<std::allocator<void> > >)> >(std::shared_ptr<rclcpp::node_interfaces::NodeBaseInterface>, std::shared_ptr<rclcpp::node_interfaces::NodeServicesInterface>, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, std::_Bind<bool (sick_scan_xd::SickScanServices::*(sick_scan_xd::SickScanServices*, std::_Placeholder<1>, std::_Placeholder<2>))(std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Request_<std::allocator<void> > >, std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Response_<std::allocator<void> > >)>&&, rclcpp::QoS const&, std::shared_ptr<rclcpp::CallbackGroup>) ()
#7  0x0000aaaac65d56b0 in rclcpp::Service<sick_scan_xd::srv::SCdevicestateSrv>::SharedPtr rclcpp::Node::create_service<sick_scan_xd::srv::SCdevicestateSrv, std::_Bind<bool (sick_scan_xd::SickScanServices::*(sick_scan_xd::SickScanServices*, std::_Placeholder<1>, std::_Placeholder<2>))(std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Request_<std::allocator<void> > >, std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Response_<std::allocator<void> > >)> >(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, std::_Bind<bool (sick_scan_xd::SickScanServices::*(sick_scan_xd::SickScanServices*, std::_Placeholder<1>, std::_Placeholder<2>))(std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Request_<std::allocator<void> > >, std::shared_ptr<sick_scan_xd::srv::SCdevicestateSrv_Response_<std::allocator<void> > >)>&&, rclcpp::QoS const&, std::shared_ptr<rclcpp::CallbackGroup>) ()
#8  0x0000aaaac65b7628 in sick_scan_xd::SickScanServices::SickScanServices(std::shared_ptr<rclcpp::Node>, sick_scan_xd::SickScanCommonTcp*, sick_scan_xd::ScannerBasicParam*) ()
#9  0x0000aaaac6644c48 in sick_scansegment_xd::MsgPackThreads::runThreadCb() ()
#10 0x0000ffff98741ae0 in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#11 0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#12 0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 4 (Thread 0xffff85fbe040 (LWP 841) "sick_generic_ca"):
#0  0x0000ffff98431e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98434b20 in pthread_cond_wait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000aaaac66f2868 in sick_scansegment_xd::MsgPackConverter::Run() ()
#3  0x0000ffff98741ae0 in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#4  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#5  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 3 (Thread 0xffff84f9e040 (LWP 842) "sick_generic_ca"):
#0  0x0000ffff9846bed0 in clock_nanosleep () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff984761fc in nanosleep () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000aaaac666097c in sick_scansegment_xd::UdpReceiverSocketImpl::Receive(std::vector<unsigned char, std::allocator<unsigned char> >&, double, std::vector<unsigned char, std::allocator<unsigned char> > const&) ()
#3  0x0000aaaac6659ac0 in sick_scansegment_xd::UdpReceiver::Run() ()
#4  0x0000ffff98741ae0 in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#5  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#6  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 2 (Thread 0xffff857ae040 (LWP 843) "sick_generic_ca"):
#0  0x0000ffff98431e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98434b20 in pthread_cond_wait () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000aaaac66f8024 in sick_scansegment_xd::Fifo<sick_scansegment_xd::ScanSegmentParserOutput>::Pop(sick_scansegment_xd::ScanSegmentParserOutput&, std::chrono::time_point<std::chrono::_V2::system_clock, std::chrono::duration<long, std::ratio<1l, 1000000000l> > >&, unsigned long&) ()
#3  0x0000aaaac66f8e2c in sick_scansegment_xd::MsgPackExporter::RunCb() ()
#4  0x0000ffff98741ae0 in ?? () from /lib/aarch64-linux-gnu/libstdc++.so.6
#5  0x0000ffff9843595c [PAC] in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#6  0x0000ffff9849bb4c in ?? () from /lib/aarch64-linux-gnu/libc.so.6

Thread 1 (Thread 0xffff98ed3020 (LWP 581) "sick_generic_ca"):
#0  0x0000ffff98431e9c in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#1  0x0000ffff98437348 in ?? () from /lib/aarch64-linux-gnu/libc.so.6
#2  0x0000ffff98741bc4 in std::thread::join() () from /lib/aarch64-linux-gnu/libstdc++.so.6
#3  0x0000aaaac6445c5c [PAC] in stopScannerAndExit(bool) ()
#4  0x0000aaaac6446a44 in rosSignalHandler(int) ()
#5  <signal handler called>
#6  0x0000ffff98438b74 in pthread_mutex_lock () from /lib/aarch64-linux-gnu/libc.so.6
#7  0x0000ffff95f7bc24 in eprosima::fastrtps::rtps::StatefulReader::matched_writer_remove(eprosima::fastrtps::rtps::GUID_t const&, bool) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#8  0x0000ffff9615995c [PAC] in eprosima::fastrtps::rtps::EDP::unpairWriterProxy(eprosima::fastrtps::rtps::GUID_t const&, eprosima::fastrtps::rtps::GUID_t const&, bool) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#9  0x0000ffff96146a94 [PAC] in eprosima::fastrtps::rtps::PDP::removeWriterProxyData(eprosima::fastrtps::rtps::GUID_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#10 0x0000ffff96145a50 [PAC] in eprosima::fastrtps::rtps::BuiltinProtocols::removeLocalWriter(eprosima::fastrtps::rtps::RTPSWriter*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#11 0x0000ffff95fb2fb8 [PAC] in eprosima::fastrtps::rtps::RTPSParticipantImpl::deleteUserEndpoint(eprosima::fastrtps::rtps::GUID_t const&) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#12 0x0000ffff95fc0b98 [PAC] in eprosima::fastrtps::rtps::RTPSDomainImpl::removeRTPSWriter(eprosima::fastrtps::rtps::RTPSWriter*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#13 0x0000ffff95fdf6ec [PAC] in eprosima::fastdds::dds::DataWriterImpl::~DataWriterImpl() () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#14 0x0000ffff96224808 [PAC] in ?? () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#15 0x0000ffff95ff5d00 [PAC] in eprosima::fastdds::dds::PublisherImpl::delete_datawriter(eprosima::fastdds::dds::DataWriter const*) () from /opt/ros/jazzy/lib/libfastrtps.so.2.14
#16 0x0000ffff9677f414 [PAC] in rmw_fastrtps_shared_cpp::__rmw_destroy_service(char const*, rmw_node_s*, rmw_service_s*) () from /opt/ros/jazzy/lib/librmw_fastrtps_shared_cpp.so
#17 0x0000ffff98aade3c [PAC] in rcl_service_fini () from /opt/ros/jazzy/lib/librcl.so
#18 0x0000aaaac65ca210 [PAC] in rclcpp::Service<sick_scan_xd::srv::SickScanExitSrv>::Service(std::shared_ptr<rcl_node_s>, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::AnyServiceCallback<sick_scan_xd::srv::SickScanExitSrv>, rcl_service_options_s&)::{lambda(rcl_service_s*)#1}::operator()(rcl_service_s*) const ()
#19 0x0000aaaac65ca528 in std::_Sp_counted_deleter<rcl_service_s*, rclcpp::Service<sick_scan_xd::srv::SickScanExitSrv>::Service(std::shared_ptr<rcl_node_s>, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::AnyServiceCallback<sick_scan_xd::srv::SickScanExitSrv>, rcl_service_options_s&)::{lambda(rcl_service_s*)#1}, std::allocator<void>, (__gnu_cxx::_Lock_policy)2>::_M_dispose() ()
#20 0x0000aaaac6442b00 in std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release() ()
#21 0x0000aaaac65be418 in std::_Sp_counted_ptr_inplace<rclcpp::Service<sick_scan_xd::srv::SickScanExitSrv>, std::allocator<void>, (__gnu_cxx::_Lock_policy)2>::_M_dispose() ()
#22 0x0000ffff98c10e90 in ?? () from /opt/ros/jazzy/lib/librclcpp.so
#23 0x0000ffff98c2b378 [PAC] in ?? () from /opt/ros/jazzy/lib/librclcpp.so
#24 0x0000ffff98c2e99c [PAC] in rclcpp::Executor::wait_for_work(std::chrono::duration<long, std::ratio<1l, 1000000000l> >) () from /opt/ros/jazzy/lib/librclcpp.so
#25 0x0000ffff98c2f460 [PAC] in rclcpp::Executor::get_next_executable(rclcpp::AnyExecutable&, std::chrono::duration<long, std::ratio<1l, 1000000000l> >) () from /opt/ros/jazzy/lib/librclcpp.so
#26 0x0000ffff98c4163c [PAC] in rclcpp::executors::SingleThreadedExecutor::spin() () from /opt/ros/jazzy/lib/librclcpp.so
#27 0x0000ffff98c39c9c [PAC] in rclcpp::spin(std::shared_ptr<rclcpp::node_interfaces::NodeBaseInterface>) () from /opt/ros/jazzy/lib/librclcpp.so
#28 0x0000ffff98c39e20 [PAC] in rclcpp::spin(std::shared_ptr<rclcpp::Node>) () from /opt/ros/jazzy/lib/librclcpp.so
#29 0x0000aaaac6440580 [PAC] in main ()
[Inferior 1 (process 581) detached]
