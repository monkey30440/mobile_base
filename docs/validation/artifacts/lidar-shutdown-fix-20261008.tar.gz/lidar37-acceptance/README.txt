Final image verification: live-complete/cycle-{1,2,3}, live-complete/sigterm-streaming-final, reconnect, final-suite log + isolated Bringup rerun.
Preserved failed SIGTERM probes: sigterm-streaming and sigterm-streaming-retry; these are harness failures, not PASS evidence.
hang-diagnosis: native async handler deadlock; hang-fixed: raw source candidate with same final patch, 12 early SIGINT cycles; not final-image physical streaming evidence.
First fullsuite has1map_server service timeout; isolated Bringup rerun passes. Timeout cause not established.
No motor/IMU devices mapped in verification container.
SOPAS access tokens in logs redacted. Initial static ownership diagnosis is a separate artifact.
