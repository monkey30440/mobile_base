import rclpy,time,json,signal,subprocess,re
from pathlib import Path
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
from sick_scan_xd.srv import ColaMsgSrv
root=Path('/tmp/lidar37-reconnect-corrected');root.mkdir(exist_ok=True)
rclpy.init();node=rclpy.create_node('lidar_reconnect_acceptance');times={'fl':[],'br':[]}
for s in times:node.create_subscription(LaserScan,'/lidar/'+s+'/scan',lambda m,s=s:times[s].append(time.monotonic()),qos_profile_sensor_data)
log=(root/'launch.log').open('w');p=subprocess.Popen(['ros2','launch','mobile_base_perception','dual_picoscan.launch.py'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
result={}
try:
 deadline=time.monotonic()+15
 while time.monotonic()<deadline and not all(len(x)>25 for x in times.values()):rclpy.spin_once(node,timeout_sec=.05)
 assert all(len(x)>25 for x in times.values()),times
 client=node.create_client(ColaMsgSrv,'/lidar/fl/ColaMsg');assert client.wait_for_service(timeout_sec=3)
 def command(selected,text):
  req=ColaMsgSrv.Request();req.request=text
  future=selected.call_async(req);rclpy.spin_until_future_complete(node,future,timeout_sec=3)
  assert future.done() and future.result() is not None
  return future.result().response
 result['fl_serial']=command(client,'sRN SerialNumber')
 br=node.create_client(ColaMsgSrv,'/lidar/br/ColaMsg');assert br.wait_for_service(timeout_sec=3)
 result['br_serial']=command(br,'sRN SerialNumber')
 import xml.etree.ElementTree as ET
 from ament_index_python.packages import get_package_share_directory
 xml=ET.parse(Path(get_package_share_directory('sick_scan_xd'))/'launch/sick_picoscan.launch')
 params={element.get('name'):element.get('value') for element in xml.iter('param')}
 auth=command(client,'sMN SetAccessMode '+params['user_level']+' '+params['user_level_password'])
 assert 'sAN SetAccessMode 1' in auth
 trigger=time.monotonic()
 result['disable_response']=command(client,'sWN ScanDataEnable 0')
 assert 'sWA ScanDataEnable' in result['disable_response'],result
 result['run_response']=command(client,'sMN Run');assert 'sAN Run' in result['run_response'],result
 deadline=time.monotonic()+25
 while time.monotonic()<deadline:rclpy.spin_once(node,timeout_sec=.05)
 result['trigger']=trigger
 for s,data in times.items():
  post=[t for t in data if t>=trigger]
  result[s]={'messages_after_trigger':len(post),'largest_gap_s':max(b-a for a,b in zip(data,data[1:])), 'final_age_s':time.monotonic()-data[-1]}
 assert result['fl']['largest_gap_s']>9,result
 assert result['fl']['final_age_s']<1,result
 assert result['br']['largest_gap_s']<.5,result
finally:
 p.send_signal(signal.SIGINT)
 try:p.wait(timeout=15)
 except subprocess.TimeoutExpired:p.kill();p.wait()
 log.close();node.destroy_node();rclpy.shutdown()
 result['parent_exit']=p.returncode
 (root/'summary.json').write_text(json.dumps(result,indent=2));(root/'timestamps.json').write_text(json.dumps(times))
text=(root/'launch.log').read_text()
assert p.returncode==0 and 'process has died' not in text
assert len(re.findall('process has finished cleanly',text))==2
assert 'udp receive timeout, stop and reconnect' in text
print(json.dumps(result,indent=2));print('PASS: native FL timeout/reconnect; BR uninterrupted; clean shutdown')
