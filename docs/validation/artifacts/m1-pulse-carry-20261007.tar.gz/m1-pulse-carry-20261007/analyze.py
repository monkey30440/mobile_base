import json,math
from pathlib import Path
r=Path(__file__).parent;d=json.loads((r/'m1-native-gate.json').read_text());s=[x for x in d['observations'] if x.get('topic')=='joints'];out={}
for name,slave,sign in [('left_wheel_joint',2,1),('right_wheel_joint',1,-1)]:
 vals=[(x['time_monotonic'],x['message']['velocity'][x['message']['name'].index(name)]) for x in s]
 turns=sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(vals,vals[1:]))*20/(2*math.pi)*sign
 before=json.loads((r/'before.json').read_text())['raw_position_words'];after=json.loads((r/'after.json').read_text())['raw_position_words'];i=(slave-1)*3
 def signed(x):return x-65536 if x>=32768 else x
 index_delta=signed(after[i])-signed(before[i]);pulse_delta=after[i+1]-before[i+1]
 out[name]={'slave':slave,'motor_turns_from_native_velocity_integral':turns,'index_delta':index_delta,'pulse_delta':pulse_delta,'documented_10000_steps_delta_turns':index_delta+pulse_delta/10000,'estimated_steps_per_index_from_velocity':pulse_delta/(turns-index_delta),'carry_observed':index_delta!=0 and index_delta*pulse_delta<0,'limits':'endpoint carry evidence and quantized native velocity consistency; not independent physical calibration'}
commands=json.loads((r/'m1-native-commands.json').read_text());out['command_duration_seconds']=commands[-1]['time_monotonic']-commands[0]['time_monotonic'];out['nonzero_command_count']=sum(c['linear_x']!=0 for c in commands)
(r/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
