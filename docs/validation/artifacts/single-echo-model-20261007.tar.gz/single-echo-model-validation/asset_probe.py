import socket,base64,os,struct,json,time,math
from rclpy.serialization import deserialize_message
from sensor_msgs.msg import LaserScan
from tf2_msgs.msg import TFMessage
s=socket.create_connection(('127.0.0.1',int(os.environ.get('FOXGLOVE_TEST_PORT','8765'))),timeout=5);f=s.makefile('rb');key=base64.b64encode(os.urandom(16)).decode()
s.sendall(('GET / HTTP/1.1\r\nHost: localhost:8765\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: '+key+'\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Protocol: foxglove.sdk.v1\r\n\r\n').encode())
status=f.readline().decode().strip()
while f.readline()!=b'\r\n':pass
assert '101' in status,status

def exact(n):
 data=f.read(n)
 if len(data)!=n:raise EOFError()
 return data

def send(op,payload):
 mask=os.urandom(4);n=len(payload);header=bytes([128|op])
 header+=bytes([128|n]) if n<126 else bytes([254])+struct.pack('>H',n)
 s.sendall(header+mask+bytes(v^mask[i%4] for i,v in enumerate(payload)))

def receive():
 a,b=exact(2);n=b&127
 if n==126:n=struct.unpack('>H',exact(2))[0]
 elif n==127:n=struct.unpack('>Q',exact(8))[0]
 assert n<30000000
 mask=exact(4) if b&128 else None;data=exact(n)
 if mask:data=bytes(v^mask[i%4] for i,v in enumerate(data))
 return a&15,data

import hashlib
uri='package://mobile_base_description/meshes/base_link.STL'
send(1,json.dumps({'op':'fetchAsset','uri':uri,'requestId':7}).encode())
end=time.monotonic()+10
while time.monotonic()<end:
 op,data=receive()
 if op==9:send(10,data);continue
 if op==2 and data[0]==4:
  request,status=struct.unpack_from('<IB',data,1);length=struct.unpack_from('<I',data,6)[0];error=data[10:10+length].decode();payload=data[10+length:]
  result={'request_id':request,'status':status,'error':error,'asset_bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}
  print(json.dumps(result,indent=2));assert status==0,error
  expected=open('/tmp/base-model-install/mobile_base_description/share/mobile_base_description/meshes/base_link.STL','rb').read();assert payload==expected
  break
else:raise AssertionError('no fetchAsset response')
send(8,struct.pack('>H',1000));s.close()
