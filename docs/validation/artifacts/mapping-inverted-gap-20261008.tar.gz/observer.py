"""Temporary acceptance harness: run installed entries, observe, no motion publisher."""
import json
import os
from pathlib import Path
import signal
import subprocess
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy, qos_profile_sensor_data
from nav_msgs.msg import OccupancyGrid, Odometry
from sensor_msgs.msg import LaserScan, Imu
from diagnostic_msgs.msg import DiagnosticArray
from tf2_ros import Buffer, TransformListener
from tf2_msgs.msg import TFMessage

out = Path('/tmp/mapping39-live')
out.mkdir(exist_ok=True)
(out/'pid').write_text(str(os.getpid()))
os.environ['ROS_DOMAIN_ID'] = '0'
processes, logs = [], []
stopping = False

def stop(_sig, _frame):
    global stopping
    stopping = True

signal.signal(signal.SIGINT, stop)
signal.signal(signal.SIGTERM, stop)
rclpy.init()
node = Node('mapping_acceptance_observer')
buffer = Buffer()
listener = TransformListener(buffer, node)
counts, received, latest = {}, {}, {}
edges = {}

def observe(topic):
    def callback(message):
        counts[topic] = counts.get(topic, 0) + 1
        received[topic] = time.monotonic()
        latest[topic] = message
    return callback

for topic, kind in [('/lidar/fl/scan', LaserScan), ('/lidar/br/scan', LaserScan),
                    ('/imu/data_raw', Imu), ('/base_controller/odom', Odometry),
                    ('/odometry/filtered', Odometry)]:
    node.create_subscription(kind, topic, observe(topic), qos_profile_sensor_data)
qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)
node.create_subscription(OccupancyGrid, '/map', observe('/map'), qos)
node.create_subscription(OccupancyGrid, '/saved_map', observe('/saved_map'), qos)

def tf_callback(message):
    for transform in message.transforms:
        edge = transform.header.frame_id + ' -> ' + transform.child_frame_id
        edges[edge] = {'stamp': transform.header.stamp.sec + transform.header.stamp.nanosec / 1e9,
                       'received': time.monotonic()}
node.create_subscription(TFMessage, '/tf', tf_callback, 100)
node.create_subscription(DiagnosticArray, '/diagnostics', observe('/diagnostics'), 100)
start = time.monotonic()
last_report = start
try:
    entries = [('description', ['ros2','launch','mobile_base_description','description.launch.py']),
               ('lidar', ['ros2','launch','mobile_base_perception','dual_picoscan.launch.py']),
               ('imu', ['ros2','launch','mobile_base_perception','imu.launch.py']),
               ('control', ['ros2','launch','mobile_base_control','m1.launch.py']),
               ('odometry', ['ros2','launch','mobile_base_odometry','odometry.launch.py']),
               ('mapping', ['ros2','launch','mobile_base_mapping','mapping.launch.py']),
               ('foxglove', ['ros2','launch','foxglove_bridge','foxglove_bridge_launch.xml'])]
    for name, command in entries:
        log = open(out / (name + '.log'), 'w')
        logs.append(log)
        processes.append((name, subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)))
    print('Installed components started; NO velocity publisher. Waiting for Operator zero initialization.', flush=True)
    while not stopping and time.monotonic() - start < 1800:
        rclpy.spin_once(node, timeout_sec=0.05)
        now = time.monotonic()
        if now - last_report < 5:
            continue
        last_report = now
        state = {'elapsed_s': round(now-start,2), 'counts': dict(counts),
                 'age_s': {t: round(now-v,3) for t,v in received.items()},
                 'process_exit': {name: p.poll() for name,p in processes},
                 'dynamic_edges': {e: round(now-v['received'],3) for e,v in edges.items()
                                   if e in ['map -> odom', 'odom -> base_footprint']}}
        for topic in ['/lidar/fl/scan','/lidar/br/scan']:
            if topic in latest:
                m=latest[topic]
                state[topic]={'frame':m.header.frame_id,'samples':len(m.ranges),'angle_min':m.angle_min,
                              'angle_max':m.angle_max,'angle_increment':m.angle_increment}
        if '/map' in latest:
            m=latest['/map']
            state['map']={'frame':m.header.frame_id,'width':m.info.width,'height':m.info.height,
                          'resolution':m.info.resolution,'occupied_cells':sum(v>=65 for v in m.data),
                          'origin':{'x':m.info.origin.position.x,'y':m.info.origin.position.y}}
            (out/'live-map.json').write_text(json.dumps({'header_frame':m.header.frame_id,
                 'width':m.info.width,'height':m.info.height,'resolution':m.info.resolution,
                 'origin_x':m.info.origin.position.x,'origin_y':m.info.origin.position.y,'data':list(m.data)}))
        state['tf_available']={target:buffer.can_transform('map',target,rclpy.time.Time())
                               for target in ['base_footprint','base_link','base_imu_link','base_lidar_link_FL_1','base_lidar_link_BR_1']}
        if '/diagnostics' in latest:
            state['latest_diagnostics']=[{'name':s.name,'level':int.from_bytes(s.level,'little') if isinstance(s.level,bytes) else s.level,'message':s.message} for s in latest['/diagnostics'].status]
        if '/saved_map' in latest and '/map' in latest:
            a,b=latest['/map'],latest['/saved_map']
            state['saved_map']={'width':b.info.width,'height':b.info.height,'resolution':b.info.resolution,
                                'occupied_cells':sum(v>=65 for v in b.data),
                                'same_geometry':a.info.width==b.info.width and a.info.height==b.info.height
                                    and abs(a.info.resolution-b.info.resolution)<1e-8
                                    and abs(a.info.origin.position.x-b.info.origin.position.x)<1e-8
                                    and abs(a.info.origin.position.y-b.info.origin.position.y)<1e-8,
                                'same_trinary':len(a.data)==len(b.data) and all(
                                     (-1 if x<0 else 100 if x>=65 else 0 if x<=25 else 50)==y
                                     for x,y in zip(a.data,b.data))}
        with open(out/'observations.jsonl','a') as stream:
            stream.write(json.dumps(state)+'\n')
        (out/'latest.json').write_text(json.dumps(state,indent=2))
        print(json.dumps(state),flush=True)
        if any(p.poll() is not None for name,p in processes):
            print('An installed component exited; operator must stop.',flush=True)
            break
finally:
    for name,process in reversed(processes):
        if process.poll() is None:
            os.killpg(process.pid,signal.SIGINT)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGTERM)
                process.wait(timeout=5)
        print(name+' exit='+str(process.poll()),flush=True)
    for log in logs: log.close()
    node.destroy_node()
    rclpy.shutdown()
