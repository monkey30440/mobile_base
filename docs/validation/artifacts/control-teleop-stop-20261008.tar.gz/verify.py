import os,pty,signal,subprocess,time,math,json
from pathlib import Path
import rclpy
from sensor_msgs.msg import JointState
from nav_msgs.msg import Odometry
from diagnostic_msgs.msg import DiagnosticArray
from geometry_msgs.msg import TwistStamped
from rosidl_runtime_py.convert import message_to_ordereddict
root=Path('/tmp/mobile-base-35-live');root.mkdir(exist_ok=True)
processes=[];latest={};received={};statuses={};events=[];outcome=False
rclpy.init();node=rclpy.create_node('m1_acceptance_observer')
def capture(key,msg):
 t=time.monotonic();latest[key]=msg;received[key]=t
 events.append({'time':t,'topic':key,'data':message_to_ordereddict(msg)})
 if key=='diagnostics':
  for s in msg.status:statuses[s.name]=(t,s)
for cls,topic,key in [(JointState,'/joint_states','joints'),(Odometry,'/base_controller/odom','odom'),(DiagnosticArray,'/diagnostics','diagnostics'),(TwistStamped,'/base_controller/cmd_vel','command')]:
 node.create_subscription(cls,topic,lambda m,k=key:capture(k,m),10)
zero_pub=node.create_publisher(TwistStamped,'/base_controller/cmd_vel',10)
def zero():
 m=TwistStamped();m.header.stamp=node.get_clock().now().to_msg();zero_pub.publish(m)
def spin(duration):
 end=time.monotonic()+duration
 while time.monotonic()<end:rclpy.spin_once(node,timeout_sec=.02)
def wheels():
 m=latest['joints'];v=[m.velocity[m.name.index(n)] for n in ['left_wheel_joint','right_wheel_joint']]
 if not all(math.isfinite(x) and abs(x)<1.0 for x in v):raise RuntimeError('invalid/excess wheel velocity')
 return v
def health():
 now=time.monotonic()
 if any(now-received.get(k,0)>.5 for k in ['joints','odom']):return False
 for name in ['m1: left_wheel_joint','m1: right_wheel_joint','controller_manager: Hardware Components Activity','controller_manager: Controller Manager Activity']:
  pair=statuses.get(name)
  if not pair or now-pair[0]>2.5 or pair[1].level not in (0,b'\x00'):return False
 return True
def wait(condition,timeout=5,check=False):
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  spin(.03)
  if check:
   if not health():raise RuntimeError('health lost')
   wheels()
  if condition():return
 raise RuntimeError('condition deadline')
def launch(args,name,**kwargs):
 log=open(root/(name+'.log'),'w');p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,**kwargs);processes.append((p,log));return p
try:
 model=launch(['ros2','launch','mobile_base_description','description.launch.py'],'description')
 control=launch(['ros2','launch','mobile_base_control','m1.launch.py'],'control')
 # Explicit zero is needed with the selected long timeout, sent only during startup.
 deadline=time.monotonic()+20
 while time.monotonic()<deadline:
  zero();spin(.1)
  if model.poll() is not None or control.poll() is not None:raise RuntimeError('launch exited')
  if health():break
 else:raise RuntimeError('zero-speed readiness failed')
 assert all(abs(v)<.03 for v in wheels())
 master,slave=pty.openpty()
 teleop=launch(['bash','/workspace/scripts/teleop.sh'],'teleop',stdin=slave)
 spin(1)
 # Native z lowers both speed and turn by 10%; all these keys preserve zero command.
 for _ in range(27):os.write(master,b'z');spin(.04)
 speed=.5*.9**27
 assert .0252<speed<.03
 os.write(master,b'k');spin(.3)
 for case in ['explicit-stop','teleop-exit']:
  start=time.monotonic();os.write(master,b'i')
  wait(lambda: all(v>.20 for v in wheels()),check=True)
  while time.monotonic()-start<2:
   spin(.03)
   if not health():raise RuntimeError('motion health lost')
   wheels()
  stop_at=time.monotonic();os.write(master,b'k' if case=='explicit-stop' else b'\x03')
  wait(lambda: received.get('command',0)>stop_at and latest['command'].twist.linear.x==0 and latest['command'].twist.angular.z==0,check=True)
  wait(lambda: received['joints']>stop_at and all(abs(v)<.03 for v in wheels()),check=True)
  events.append({'case':case,'stop_feedback_latency':time.monotonic()-stop_at,'speed':speed})
  spin(.5)
 teleop.wait(timeout=5);assert teleop.returncode==0
 os.killpg(control.pid,signal.SIGINT);control.wait(timeout=12);assert control.returncode==0
 outcome=True
except Exception as error:
 events.append({'failure':repr(error)})
finally:
 # Independent cleanup zero does not count as the stop result above.
 for _ in range(10):zero();spin(.05)
 for p,log in reversed(processes):
  if p.poll() is None:os.killpg(p.pid,signal.SIGINT)
  try:p.wait(timeout=12)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  events.append({'process':str(log.name),'exit':p.returncode});log.close()
 (root/'events.json').write_text(json.dumps(events,indent=2))
 node.destroy_node();rclpy.try_shutdown()
 print(json.dumps({'passed':outcome,'summary':[e for e in events if 'case' in e or 'failure' in e or 'process' in e]},indent=2),flush=True)
 if not outcome:raise SystemExit(1)
